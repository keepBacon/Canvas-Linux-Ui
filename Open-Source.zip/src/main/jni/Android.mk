LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := linux_ui_opt
LOCAL_SRC_FILES := NativeUiOptimizer.cpp
LOCAL_CPPFLAGS := -std=c++11 -O3 -ffast-math -fno-exceptions -fno-rtti -Wall
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
