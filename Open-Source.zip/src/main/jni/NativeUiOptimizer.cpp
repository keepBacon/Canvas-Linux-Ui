#include <jni.h>
#include <cmath>

static inline float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_bacon_linuxui_NativeUiOptimizer_nativeGradientPhase(
        JNIEnv*, jclass, jlong nowMs, jfloat speed, jfloat boost) {
    if (boost < 0.1f) boost = 0.1f;
    const long long wrapped = static_cast<long long>(nowMs % 100000LL);
    return static_cast<jfloat>(wrapped) * (0.00008f + speed * 0.00016f) * boost;
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_bacon_linuxui_NativeUiOptimizer_nativeFrameDeltaSeconds(
        JNIEnv*, jclass, jlong lastNs, jlong nowNs) {
    if (lastNs <= 0 || nowNs <= lastNs) return 1.0f / 60.0f;
    float dt = static_cast<float>(nowNs - lastNs) / 1000000000.0f;
    return clampf(dt, 1.0f / 240.0f, 1.0f / 20.0f);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_bacon_linuxui_NativeUiOptimizer_nativeSmooth01(
        JNIEnv*, jclass, jfloat value) {
    float v = clampf(value, 0.0f, 1.0f);
    return v * v * (3.0f - 2.0f * v);
}
