package com.bacon.linuxui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

/**
 * MainActivity is the standalone test host for LinuxFloatingUiView.
 *
 * Responsibilities:
 * - force landscape/fullscreen mode for UI testing;
 * - forward file-picker results to the custom View;
 * - keep Android system APIs such as MediaPlayer, fonts and document export
 *   outside the rendering code.
 */
public class MainActivity extends Activity {
    public static final int REQUEST_PICK_FONT = 7001;
    public static final int REQUEST_PICK_MUSIC = 7002;
    public static final int REQUEST_PICK_LRC = 7003;
    public static final int REQUEST_EXPORT_LOG = 7004;

    private LinuxFloatingUiView linuxUiView;

    @Override
    /**
     * Creates a lightweight FrameLayout host and attaches the self-drawn UI.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        enableFullscreenLandscape();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFF8FAFC);

        DemoBackgroundView background = new DemoBackgroundView(this);
        root.addView(background, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        linuxUiView = new LinuxFloatingUiView(this);
        linuxUiView.setStandaloneTestMode(true);
        linuxUiView.setClickable(true);
        linuxUiView.setFocusable(true);
        linuxUiView.setFocusableInTouchMode(true);
        root.addView(linuxUiView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);

        linuxUiView.postDelayed(new Runnable() {
            @Override
            public void run() {
                linuxUiView.enterStandaloneTestMode();
            }
        }, 180L);
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableFullscreenLandscape();
        if (linuxUiView != null) {
            linuxUiView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    linuxUiView.enterStandaloneTestMode();
                }
            }, 120L);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableFullscreenLandscape();
    }

    private void enableFullscreenLandscape() {
        Window window = getWindow();
        if (window == null) return;
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 19) {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    public void openFontPicker() {
        openDocument("*/*", new String[]{"font/ttf", "font/otf", "application/x-font-ttf", "application/x-font-otf", "application/octet-stream"}, REQUEST_PICK_FONT);
    }

    public void openMusicPicker() {
        openDocument("audio/*", null, REQUEST_PICK_MUSIC);
    }

    public void openLrcPicker() {
        openDocument("*/*", new String[]{"text/*", "application/octet-stream"}, REQUEST_PICK_LRC);
    }

    public void openLogExporter() {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TITLE, "linux_ui_log.txt");
            startActivityForResult(intent, REQUEST_EXPORT_LOG);
        } catch (Exception ignored) {
        }
    }

    private void openDocument(String type, String[] mimeTypes, int requestCode) {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(type == null ? "*/*" : type);
            if (mimeTypes != null) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(type == null ? "*/*" : type);
            if (mimeTypes != null) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            startActivityForResult(Intent.createChooser(intent, "Select file"), requestCode);
        }
    }

    @Override
    /**
     * File picker callback bridge. The View owns the feature logic, while the
     * Activity owns Android result delivery.
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null || linuxUiView == null) return;
        Uri uri = data.getData();
        try {
            final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (flags != 0) getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
        }
        if (requestCode == REQUEST_PICK_FONT) linuxUiView.handleImportedFont(uri);
        else if (requestCode == REQUEST_PICK_MUSIC) linuxUiView.handleImportedMusic(uri);
        else if (requestCode == REQUEST_PICK_LRC) linuxUiView.handleImportedLrc(uri);
        else if (requestCode == REQUEST_EXPORT_LOG) linuxUiView.handleExportLogUri(uri);
    }

    private static final class DemoBackgroundView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        DemoBackgroundView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFF8FAFC);
            canvas.drawRect(0, 0, w, h, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, w / 900f));
            paint.setColor(0xFFE5E7EB);
            float grid = Math.max(36f, Math.min(w, h) / 10f);
            for (float x = 0; x <= w; x += grid) canvas.drawLine(x, 0, x, h, paint);
            for (float y = 0; y <= h; y += grid) canvas.drawLine(0, y, w, y, paint);

            float cardW = Math.min(w * 0.36f, 520f);
            float cardH = Math.min(h * 0.18f, 150f);
            rect.set(w - cardW - 32f, h - cardH - 28f, w - 32f, h - 28f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xDFFFFFFF);
            canvas.drawRoundRect(rect, 28f, 28f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(0xFFE5E7EB);
            canvas.drawRoundRect(rect, 28f, 28f, paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFF111827);
            paint.setTextSize(Math.max(18f, h / 34f));
            paint.setFakeBoldText(true);
            canvas.drawText("Linux UI 普通 APK 横屏测试模式", rect.left + 24f, rect.top + cardH * 0.42f, paint);
            paint.setFakeBoldText(false);
            paint.setColor(0xFF64748B);
            paint.setTextSize(Math.max(14f, h / 46f));
            canvas.drawText("普通横屏 APK，打开即可测试 UI、悬浮快捷键、RGB/渐变调试。", rect.left + 24f, rect.top + cardH * 0.72f, paint);
        }
    }
}
