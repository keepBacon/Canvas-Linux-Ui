package com.bacon.linuxui;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.net.Uri;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.BlurMaskFilter;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.PathInterpolator;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * LinuxFloatingUiView
 *
 * This is the central self-drawn UI surface of the project.
 * The class intentionally keeps the UI in one Canvas View so it can run inside
 * a plain Android APK without external UI libraries.
 *
 * Maintainer notes for open-source contributors:
 * 1. Most visual state is stored as fields so drawing can avoid allocation.
 * 2. RectF/Paint objects are reused heavily to reduce garbage collection.
 * 3. Feature objects describe both normal buttons and their debug controls.
 * 4. ColorSpec/gradient fields are shared by shortcuts, hints and ArrayList.
 * 5. The frame pump is conservative: only animations or live effects request
 *    repeated redraws. Static UI should stay idle for better battery life.
 * 6. When adding a new debug option, give it a Role id and handle it in the
 *    central role switch methods rather than scattering logic everywhere.
 */
public class LinuxFloatingUiView extends View {

    // ---------------------------------------------------------------------
    // Control type constants
    // ---------------------------------------------------------------------
    // These values describe how a Feature row behaves in the debug list.
    // Keeping them as integers instead of separate subclasses keeps AIDE Pro
    // builds simple and avoids extra allocation when drawing hundreds of rows.
    private static final int CONTROL_NONE = 0;
    private static final int CONTROL_SWITCH = 1;
    private static final int CONTROL_SELECT = 2;
    private static final int CONTROL_SLIDER = 3;
    private static final int CONTROL_GROUP = 4;
    private static final int CONTROL_COLOR = 5;
    private static final int CONTROL_ACTION = 6;

    private static final int SECTION_COUNT = 5;
    private static final int MAIN_FEATURE_COUNT = 10;

    private static final int RESIZE_LEFT = 1;
    private static final int RESIZE_RIGHT = 2;
    private static final int RESIZE_TOP = 4;
    private static final int RESIZE_BOTTOM = 8;

    // ---------------------------------------------------------------------
    // Reused drawing objects
    // ---------------------------------------------------------------------
    // Do not create new Paint/RectF objects inside hot draw paths unless there
    // is a strong reason. Reusing these objects is one of the main FPS fixes.
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tempRect = new RectF();
    private final RectF hintBarBgRect = new RectF();
    private final RectF hintBarRect = new RectF();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final RectF glowRectCache = new RectF();
    private final Map<Integer, BlurMaskFilter> glowMaskCache = new HashMap<Integer, BlurMaskFilter>();

    private static final int TRANSITION_PARTICLE_COUNT = 160;
    private static final int TRANSITION_OPEN = 1;
    private static final int TRANSITION_CLOSE = 2;
    private final Random random = new Random(20260602L);
    private final Particle[] transitionParticles = new Particle[TRANSITION_PARTICLE_COUNT];

    private final RectF screenRect = new RectF();
    private final RectF panelRect = new RectF();
    private final RectF logoRect = new RectF();
    private final RectF footerRect = new RectF();
    private final RectF dividerRect = new RectF();
    private final RectF searchRect = new RectF();
    private final RectF closeRect = new RectF();
    private final RectF badgeRect = new RectF();
    private final RectF featureListRect = new RectF();
    private final RectF themePopupRect = new RectF();
    private final RectF welcomeCardRect = new RectF();
    private final RectF musicRect = new RectF();
    private final RectF musicPlayRect = new RectF();
    private final RectF musicPrevRect = new RectF();
    private final RectF musicNextRect = new RectF();
    private final RectF musicSearchRect = new RectF();
    private final RectF musicSearchButtonRect = new RectF();
    private final RectF musicResultsRect = new RectF();
    private final RectF musicImportMusicRect = new RectF();
    private final RectF musicImportLrcRect = new RectF();
    private final RectF musicLyricToggleRect = new RectF();
    private final RectF musicNameRect = new RectF();
    private final RectF musicLocalTabRect = new RectF();
    private final RectF musicNeteaseTabRect = new RectF();
    private final RectF musicAddLocalRect = new RectF();
    private final RectF localAddDialogRect = new RectF();
    private final RectF localAddMusicRect = new RectF();
    private final RectF localAddLrcRect = new RectF();
    private final RectF localAddNameRect = new RectF();
    private final RectF localAddSaveRect = new RectF();
    private final RectF localAddCancelRect = new RectF();
    private final RectF lyricOverlayRect = new RectF();
    private final RectF[] musicResultRects = new RectF[8];
    private final RectF[] localSongRects = new RectF[8];

    private final RectF colorPickerRect = new RectF();
    private final RectF colorPreviewRect = new RectF();
    private final RectF colorOkRect = new RectF();
    private final RectF colorCancelRect = new RectF();
    private final RectF colorModeRect = new RectF();
    private final RectF colorStyleRect = new RectF();
    private final RectF colorSpeedSliderRect = new RectF();
    private final RectF colorDelaySliderRect = new RectF();
    private final RectF colorAddRect = new RectF();
    private final RectF colorRSliderRect = new RectF();
    private final RectF colorGSliderRect = new RectF();
    private final RectF colorBSliderRect = new RectF();
    private final RectF colorRValueRect = new RectF();
    private final RectF colorGValueRect = new RectF();
    private final RectF colorBValueRect = new RectF();
    private final RectF[] colorSwatchRects = new RectF[24];
    private final RectF[] colorListRects = new RectF[8];
    private final RectF[] colorDeleteRects = new RectF[8];

    private final RectF[] sectionRects = new RectF[SECTION_COUNT];

    private final String[] sectionNames = new String[]{"section1", "section2", "section3", "section4", "UI debugging"};
    private final String[] sectionNamesCn = new String[]{"板块1", "板块2", "板块3", "板块4", "UI 调试"};

    private final Section[] sections = new Section[SECTION_COUNT];
    private final float[] sectionScrollPositions = new float[SECTION_COUNT];
    private final ThemePalette[] themes = new ThemePalette[]{
            new ThemePalette("Default", "默认主题", 0xFFFFFFFF, 0xFFF8FAFC, 0xFFF1F5F9, 0xFFE5E7EB, 0xFF111827, 0xFF6B7280, 0xFF9CA3AF, 0xFF111827),
            new ThemePalette("iOS", "iOS", 0xC8172436, 0xFF0B1220, 0x332A3A50, 0x4BFFFFFF, 0xFFFFFFFF, 0xDCE5ECF6, 0x92CBD5E1, 0xFF60A5FA),
            new ThemePalette("RGB", "RGB", 0xCC0D1220, 0xFF050814, 0x22142235, 0x66FFFFFF, 0xFFFFFFFF, 0xDCE5ECF6, 0x9ACBD5E1, 0xFFE100FF)
    };

    private final PathInterpolator ease = new PathInterpolator(0.18f, 0.82f, 0.22f, 1f);

    private boolean layoutReady = false;
    private boolean panelBoundsReady = false;
    private float uiScale = 1f;
    private boolean delayedFrameScheduled = false;
    private long lastFastFrameRequestMs = 0L;

    // FPS boost: throttle high-cost animation phases while keeping the original soft glow / gradient look.
    // Glow uses the backup BlurMaskFilter effect again, but gradient phases update at a lower FPS.
    private boolean fpsBoostMode = true;
    private long frameStartMs = 0L;
    private boolean hotInteractionFrame = false;
    private boolean expensiveEffectsAllowed = true;
    private long lastExpensiveEffectMs = 0L;
    private long gradientFrameOverrideMs = -1L;
    private static final long EXPENSIVE_EFFECT_INTERVAL_MS = 140L;
    private final Runnable delayedFrameRunnable = new Runnable() {
        @Override public void run() {
            delayedFrameScheduled = false;
            requestFrame();
        }
    };

    private int selectedSection = 4;
    private int previousSection = 4;
    private float panelProgress = 0f;
    private float sectionProgress = 1f;
    private float contentProgress = 1f;
    private boolean panelVisible = false;
    private boolean welcomeVisible = true;
    private boolean glassEffectEnabled = false;
    private boolean standaloneTestMode = false;
    private static final String PREFS_NAME = "linux_ui_test_prefs";
    private boolean draggingPanel = false;
    private float panelDragDownX, panelDragDownY, panelDragStartL, panelDragStartT, panelDragStartR, panelDragStartB;
    private boolean savedPanelBoundsLoaded = false;
    private float savedPanelL = -1f, savedPanelT = -1f, savedPanelR = -1f, savedPanelB = -1f;

    private float shortcutBgOpacity = 0.82f;
    private float shortcutBorderOpacity = 0.95f;
    private int shortcutShape = 0; // 0 = rounded rectangle, 1 = circle
    private int shortcutOnTextColor = 0xFF22C55E;
    private int shortcutOnBgColor = 0xFFFFFFFF;
    private int shortcutOffTextColor = 0xFFEF4444;
    private int shortcutOffBgColor = 0xFFFFFFFF;
    private boolean shortcutBorderGradient = false;
    private int shortcutBorderColor = 0xFF000000;
    private int[] shortcutBorderColors = new int[]{0xFF000000, 0xFF000000};
    private float shortcutBorderGradientSpeed = 1.0f;
    private int shortcutBorderGradientStyle = 0;
    private float shortcutBorderGradientDelay = 1.0f;
    private float shortcutSizeFactor = 1.0f;
    private float shortcutBorderSizeFactor = 1.0f;
    private float shortcutTextSizeFactor = 1.0f;
    private boolean shortcutGlowEnabled = true;
    private float shortcutGlowStrength = 0.72f;
    private int shortcutGlowColor = 0xFF000000;
    private boolean shortcutGlowGradient = false;
    private int[] shortcutGlowColors = new int[]{0xFF000000, 0xFF000000};
    private float shortcutGlowGradientSpeed = 1.0f;
    private int shortcutGlowGradientStyle = 0;
    private float shortcutGlowGradientDelay = 1.0f;
    private Feature shortcutDownFeature;
    private boolean shortcutDragging = false;
    private float shortcutDownX, shortcutDownY, shortcutStartX, shortcutStartY;

    private boolean colorPickerOpen = false;
    private Feature editingColorFeature;
    private int pickerR = 255, pickerG = 255, pickerB = 255;
    private int pickerGradientIndex = 0;
    private int colorInputChannel = 0; // 0 none, 1 R, 2 G, 3 B
    private String colorInputBuffer = "";
    private boolean backupShortcutBorderGradient = false;
    private int backupShortcutBorderColor = 0xFF000000;
    private int[] backupShortcutBorderColors = new int[]{0xFF000000, 0xFF000000};
    private boolean backupEditingColorGradient = false;
    private int backupEditingColor = 0xFFFFFFFF;
    private int[] backupEditingGradientColors = new int[]{0xFFFFFFFF, 0xFF22C55E};
    private float backupEditingGradientSpeed = 1.0f;
    private float backupEditingGradientDelay = 1.0f;
    private int backupEditingGradientStyle = 0;

    private int ballTransitionMode = 0; // 0 = Particle, 1 = Default
    private boolean transitionActive = false;
    private int transitionMode = 0;
    private float transitionProgress = 1f;
    private float savedBallX = 0f;
    private float savedBallY = 0f;
    private boolean savedBallPositionReady = false;

    private int themeIndex = 0;
    private boolean chineseMode = false;
    private boolean themeDropdownOpen = false;
    private float themeDropdownProgress = 0f;

    private boolean switchHintEnabled = true;
    private boolean hintShowDebugFeatures = false;
    private int hintStyle = 0; // 0 = default, 1 = 2 right-bottom style
    private float hintOpacity = 0.86f;
    private long hintDurationMs = 2600L;
    private boolean hintPositionEdit = false;
    private float hintSize = 1f;
    private float hintX, hintY;
    private boolean hintPositionReady = false;
    private String hintText = "";
    private boolean hintStateEnabled = true;
    private long hintStartMs = 0L;
    private boolean hintActive = false;
    private boolean hintGlowEnabled = true;
    private float hintGlowStrength = 0.52f;
    private int hintGlowColor = 0xFF000000;
    private boolean hintGlowGradient = false;
    private int[] hintGlowColors = new int[]{0xFF000000, 0xFF000000};
    private float hintGlowGradientSpeed = 1.0f;
    private int hintGlowGradientStyle = 0;
    private float hintGlowGradientDelay = 1.0f;
    private final ArrayList<HintToast> hintToasts = new ArrayList<HintToast>();
    // Hint toasts are intentionally unlimited; expired items are removed by duration only.
    private boolean draggingHint = false;
    private float hintDownX, hintDownY, hintStartX, hintStartY;

    private boolean logWindowEnabled = false;
    private boolean logDragging = false;
    private boolean logBodyScrolling = false;
    private float logScrollY = 0f, logMaxScrollY = 0f, logBodyDownY = 0f, logScrollStartY = 0f;
    private float logX = 0f, logY = 0f, logDownX = 0f, logDownY = 0f, logStartX = 0f, logStartY = 0f;
    private boolean logPositionReady = false;
    private long lastRealtimeLogMs = 0L;
    private long logSerial = 0L;
    private String logStatus = "Log idle";
    private final ArrayList<String> runtimeLogs = new ArrayList<String>();
    private final RectF logWindowRect = new RectF();
    private final RectF logHeaderRect = new RectF();
    private final RectF logClearRect = new RectF();
    private final RectF logExportRect = new RectF();
    private final RectF logBodyRect = new RectF();

    private boolean arrayListEnabled = false;
    private float arrayListX = 0f, arrayListY = 0f, arrayListDownX = 0f, arrayListDownY = 0f, arrayListStartX = 0f, arrayListStartY = 0f;
    private boolean arrayListPositionReady = false;
    private boolean arrayListDragging = false;
    private boolean arrayListPositionEdit = false;
    private boolean arrayListShowDebugSettings = false;
    private float arrayListBarLengthFactor = 1.0f;
    private float arrayListBarWidthFactor = 1.0f;
    private int arrayListBarColor = 0xFFFF2BD6;
    private boolean arrayListBarGradient = true;
    private int[] arrayListBarColors = new int[]{0xFFFF2BD6, 0xFF7C3AED, 0xFF06B6D4, 0xFF22C55E, 0xFFFACC15, 0xFFFF2BD6};
    private float arrayListBarGradientSpeed = 1.0f;
    private int arrayListBarGradientStyle = 0;
    private float arrayListBarGradientDelay = 0.0f;
    private float arrayListTextSizeFactor = 1.0f;
    private int arrayListTextColor = 0xFFFF2BD6;
    private boolean arrayListTextGradient = true;
    private int[] arrayListTextColors = new int[]{0xFFFF2BD6, 0xFF7C3AED, 0xFF06B6D4, 0xFF22C55E, 0xFFFACC15, 0xFFFF2BD6};
    private float arrayListTextGradientSpeed = 1.0f;
    private int arrayListTextGradientStyle = 0;
    private float arrayListTextGradientDelay = 0.0f;
    private boolean arrayListGlowEnabled = true;
    private float arrayListGlowStrength = 0.55f;
    private final RectF arrayListRect = new RectF();
    private final RectF arrayListGlowRect = new RectF();
    private final RectF arrayListBarRect = new RectF();
    private final RectF arrayListTextGradientRect = new RectF();
    private final ArrayList<Feature> arrayListFeatureCache = new ArrayList<Feature>();
    private long arrayListCacheTimeMs = 0L;
    private boolean arrayListCacheDirty = true;
    private final HashMap<String, ArrayListAnim> arrayListAnimMap = new HashMap<String, ArrayListAnim>();
    private final ArrayList<ArrayListAnim> arrayListDrawCache = new ArrayList<ArrayListAnim>();
    private long arrayListLastAnimMs = 0L;
    private boolean arrayListAnimating = false;

    private float scrollY = 0f;
    private float maxScrollY = 0f;
    private float scrollStartY = 0f;
    private float scrollDownY = 0f;
    private boolean maybeScrolling = false;
    private boolean draggingScroll = false;
    private long scrollBarVisibleUntil = 0L;
    private float scrollSpeed = 1f;
    private float scrollDamping = 0.75f;
    private float scrollBarOpacity = 0.72f;
    private float scrollBarWidth = 1f;

    private float ballX, ballY, ballSize;
    private float ballSizeFactor = 1f;
    private float ballOpacity = 1f;
    private boolean ballSnapEdge = true;
    private boolean ballPositionReady = false;

    private boolean musicWindowEnabled = false;
    private boolean musicPositionReady = false;
    private boolean musicDragging = false;
    private boolean musicLoading = false;
    private boolean musicPlaying = false;
    private float musicX, musicY, musicDownX, musicDownY, musicStartX, musicStartY;
    private long musicPlayStartMs = 0L;
    private String musicTitle = "Netease Cloud Music";
    private String musicArtist = "Tap search to find music";
    private String musicStatus = "API Enhanced Ready";
    private String musicQuery = "Linux";
    private boolean musicSearchFocused = false;
    private boolean musicPreparing = false;
    private int selectedSongIndex = -1;
    private String musicUrl = "";
    private MediaPlayer mediaPlayer;
    private MusicSong[] musicResults = new MusicSong[0];
    private Uri localMusicUri;
    private boolean localMusicMode = false;
    private boolean musicNameFocused = false;
    private String musicNameInput = "Local Music";
    private int musicPanelMode = 0; // 0 = local playlist, 1 = Netease
    private boolean localAddDialogOpen = false;
    private Uri pendingAddMusicUri;
    private Uri pendingAddLrcUri;
    private String pendingAddName = "Local Music";
    private boolean pendingAddNameFocused = false;
    private int pendingFileTarget = 0; // 0 quick import, 1 add music, 2 add lrc
    private int selectedLocalSongIndex = -1;
    private final ArrayList<LocalSong> localPlaylist = new ArrayList<LocalSong>();
    private LrcLine[] lyricLines = new LrcLine[0];
    private String lyricStatus = "No LRC";
    private boolean lyricOverlayEnabled = false;
    private int lyricDisplayedIndex = -1;
    private int lyricAnimFromIndex = -1;
    private long lyricAnimStartMs = 0L;
    private static final long LYRIC_ANIM_MS = 360L;

    private Typeface globalTypeface;
    private String fontStatus = "Default font";
    private float uiCompactScale = 0.90f;
    private float globalResolutionScale = 0.90f;
    private float performanceQuality = 0.70f;
    private boolean animationsEnabled = true;

    // Large custom debug system. These values intentionally affect broad drawing/layout
    // paths so many new UI debugging controls are useful without making AIDE Pro heavy.
    private float globalOpacityScale = 1.0f;
    private float globalCornerScale = 1.0f;
    private float globalStrokeScale = 1.0f;
    private float globalGlowScale = 1.0f;
    private float globalAnimSpeedScale = 1.0f;
    private float globalTextScale = 1.0f;
    private float globalGlassStrength = 1.0f;
    private float globalBackgroundDim = 0.0f;
    private float globalTouchFeedback = 1.0f;

    private float panelWidthScale = 1.0f;
    private float panelHeightScale = 1.0f;
    private float panelBgOpacityScale = 1.0f;
    private float panelCornerScale = 1.0f;
    private float panelStrokeScale = 1.0f;
    private float panelPaddingScale = 1.0f;
    private boolean panelGlowEnabled = true;
    private float panelGlowStrength = 0.0f;
    private float panelTitleScale = 1.0f;
    private float panelContentTextScale = 1.0f;
    private boolean panelEdgeSnap = false;

    private float sectionSizeScale = 1.0f;
    private float sectionSpacingScale = 1.0f;
    private float sectionCornerScale = 1.0f;
    private float sectionTextScale = 1.0f;
    private boolean sectionGlowEnabled = true;
    private float sectionGlowStrength = 0.0f;

    private float featureHeightScale = 1.0f;
    private float featureGapScale = 1.0f;
    private float featureCornerScale = 1.0f;
    private float featureTextScale = 1.0f;
    private float featureStrokeScale = 1.0f;
    private boolean featureGlowEnabled = true;
    private float featureGlowStrength = 0.0f;
    private float featurePressScale = 1.0f;
    private boolean featureIconsEnabled = false;
    private boolean featureHapticEnabled = false;

    private float layoutLeftWidthScale = 1.0f;
    private float layoutTopHeightScale = 1.0f;
    private float layoutRowGapScale = 1.0f;
    private float layoutControlWidthScale = 1.0f;
    private float layoutSliderHeightScale = 1.0f;
    private float layoutSafeInsetScale = 1.0f;
    private boolean layoutScrollBarVisible = true;

    private float themeRgbDirection = 0.0f;
    private float themeIosGlassOpacity = 1.0f;
    private float themeIosHighlight = 1.0f;
    private float themeNoiseStrength = 0.25f;

    private float logWindowTextScale = 1.0f;
    private float logWindowOpacity = 1.0f;
    private boolean logAutoScroll = true;
    private boolean logRecordFps = true;
    private boolean logRecordTouch = true;

    private float musicWindowScale = 1.0f;
    private float musicLyricScale = 1.0f;
    private float musicProgressHeightScale = 1.0f;
    private int musicDefaultPanel = 0;

    // NeteaseCloudMusicApiEnhanced compatible endpoints.
    // The first base is a public API Enhanced instance. The other two are useful when you self-host the GitHub project.
    private static final String[] MUSIC_API_BASES = new String[]{
            "https://api.jimsdeng.eu.org",
            "http://10.0.2.2:3000",
            "http://127.0.0.1:3000"
    };

    // Official web endpoints are used as fallback for search and outer-url playback.
    // This keeps the UI usable even when a public api-enhanced instance is down.
    private static final String NETEASE_OFFICIAL_SEARCH = "https://music.163.com/api/search/get/web";
    private static final String NETEASE_OUTER_URL = "https://music.163.com/song/media/outer/url?id=";
    private static final String DEFAULT_REAL_IP = "116.25.146.177";
    private static final String MUSIC_USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/116 Mobile Safari/537.36";

    private boolean ballDown = false;
    private boolean ballLongPressed = false;
    private boolean ballDragging = false;
    private float ballScale = 1f;
    private float ballDownX, ballDownY, ballStartX, ballStartY;

    private boolean resizingPanel = false;
    private int activeResizeMode = 0;
    private float resizeDownX, resizeDownY;
    private float resizeStartL, resizeStartT, resizeStartR, resizeStartB;

    private float downX, downY;
    private int pressedFeatureIndex = -1;
    private Feature pressedFeature;
    private Feature activeSliderFeature;
    private boolean draggingSlider = false;

    private int currentFps = 0;
    private int fpsFrames = 0;
    private long fpsLastNs = 0L;

    // Hybrid Java + C++ optimization layer. Java keeps Android system features
    // and Canvas-compatible visuals; C++ provides fast math / frame pacing helpers.
    private boolean frameScheduled = false;
    private long lastFrameNs = 0L;
    private float frameDeltaSeconds = 1f / 60f;
    private boolean themeTextGradientEnabled = true;

    private ValueAnimator panelAnimator;
    private ValueAnimator sectionAnimator;
    private ValueAnimator contentAnimator;
    private ValueAnimator pressAnimator;
    private ValueAnimator sliderAnimator;
    private ValueAnimator themeAnimator;
    private ValueAnimator ballScaleAnimator;
    private ValueAnimator ballSnapAnimator;
    private ValueAnimator transitionAnimator;

    private final Runnable ballLongPress = new Runnable() {
        @Override
        public void run() {
            if (!ballDown || isThemeLocked()) return;
            ballLongPressed = true;
            ballDragging = true;
            animateBallScale(1.08f);
        }
    };


    public void setStandaloneTestMode(boolean enabled) {
        standaloneTestMode = enabled;
        if (enabled) {
            setClickable(true);
            setFocusable(true);
            setFocusableInTouchMode(true);
        }
    }

    public void enterStandaloneTestMode() {
        standaloneTestMode = true;
        if (getWidth() > 0 && getHeight() > 0) {
            if (!panelBoundsReady) {
                float marginX = getWidth() * 0.038f;
                float marginY = getHeight() * 0.055f;
                panelRect.set(marginX, marginY, getWidth() - marginX, getHeight() - marginY);
                panelBoundsReady = true;
            }
            if (!ballPositionReady) {
                ballX = Math.max(12, panelRect.left - 40);
                ballY = panelRect.top + 42;
                ballPositionReady = true;
            }
        }
        selectedSection = 4;
        previousSection = 4;
        sectionProgress = 1f;
        contentProgress = 1f;
        welcomeVisible = true;
        closeThemeDropdown();
        cancel(panelAnimator);
        cancel(transitionAnimator);
        transitionActive = false;
        transitionMode = 0;
        panelVisible = true;
        panelProgress = 1f;
        rebuildLayoutCache();
        requestFocus();
        requestFrame();
    }

    public LinuxFloatingUiView(Context context) {
        super(context);
        NativeUiOptimizer.preload();
        // Restore the previous natural soft glow. BlurMaskFilter requires software rendering;
        // gradient animation is throttled separately to keep FPS acceptable.
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setWillNotDraw(false);
        setFocusable(true);
        setFocusableInTouchMode(true);
        textPaint.setSubpixelText(true);
        for (int i = 0; i < SECTION_COUNT; i++) sectionRects[i] = new RectF();
        for (int i = 0; i < musicResultRects.length; i++) musicResultRects[i] = new RectF();
        for (int i = 0; i < localSongRects.length; i++) localSongRects[i] = new RectF();
        for (int i = 0; i < colorSwatchRects.length; i++) colorSwatchRects[i] = new RectF();
        for (int i = 0; i < colorListRects.length; i++) {
            colorListRects[i] = new RectF();
            colorDeleteRects[i] = new RectF();
        }
        for (int i = 0; i < transitionParticles.length; i++) transitionParticles[i] = new Particle();
        buildData();
        loadPersistentState();
        loadLocalPlaylist();
    }

    private void buildData() {
        Feature section1TestSwitch = Feature.switcher("features1", "Toggle Test", false);
        section1TestSwitch.debuggable = true;
        section1TestSwitch.nameCn = "功能1";
        section1TestSwitch.titleCn = "可开关功能";
        sections[0] = new Section(new Feature[]{section1TestSwitch});
        for (int s = 1; s < 4; s++) {
            Feature f = Feature.none("null", "null", "空", "空");
            sections[s] = new Section(new Feature[]{f});
        }

        Feature chinese = Feature.switcher("Enable 01", "Chinese UI", false);
        chinese.debuggable = true;
        chinese.nameCn = "开启01";
        chinese.titleCn = "中文界面";
        chinese.role = Role.CHINESE;

        Feature theme = Feature.select("Select 01", "Theme", new String[]{"Default", "iOS", "RGB"}, 0);
        theme.nameCn = "选择01";
        theme.titleCn = "UI 主题";
        theme.optionsCn = new String[]{"默认主题", "iOS", "RGB"};
        theme.role = Role.THEME;

        Feature switchHint = Feature.switcher("Enable 02", "Switch Hint", false);
        switchHint.nameCn = "开启02";
        switchHint.titleCn = "功能开关提示";
        switchHint.role = Role.SWITCH_HINT;
        switchHint.debuggable = true;
        Feature hintStyleSelect = Feature.select("Hint Debug 01", "Hint Style", new String[]{"Default", "2"}, 0);
        hintStyleSelect.nameCn = "提示调试01";
        hintStyleSelect.titleCn = "提示样式";
        hintStyleSelect.optionsCn = new String[]{"默认", "2"};
        hintStyleSelect.role = Role.HINT_STYLE;
        hintStyleSelect.isSettingOnlyForNoToast = true;
        Feature hintDebugToasts = Feature.switcher("Hint Debug 06", "Show Debug Toggles", false, "提示调试06", "调试功能也显示", Role.HINT_DEBUG_TOASTS);
        hintDebugToasts.isSettingOnlyForNoToast = true;
        Feature hintGlowColorFeature = Feature.color("Hint Debug 09", "Glow Color", "提示调试09", "辉光颜色", Role.HINT_GLOW_COLOR, hintGlowColor);
        hintGlowColorFeature.colorGradient = false;
        hintGlowColorFeature.gradientColors = copyColors(hintGlowColors);
        hintGlowColorFeature.gradientSpeed = hintGlowGradientSpeed;
        hintGlowColorFeature.gradientStyle = hintGlowGradientStyle;
        hintGlowColorFeature.gradientDelay = hintGlowGradientDelay;
        switchHint.settings = new Feature[]{
                hintStyleSelect,
                Feature.slider("Hint Debug 02", "Hint Opacity", "提示调试02", "提示透明度", Role.HINT_OPACITY, 0.86f),
                Feature.slider("Hint Debug 03", "Hint Duration", "提示调试03", "提示存在时间", Role.HINT_DURATION, 0.519f),
                Feature.switcher("Hint Debug 04", "Hint Position Edit", false, "提示调试04", "显示位置修改", Role.HINT_POSITION),
                Feature.slider("Hint Debug 05", "Hint Size", "提示调试05", "提示大小", Role.HINT_SIZE, 0.50f),
                hintDebugToasts,
                Feature.switcher("Hint Debug 07", "Glow", true, "提示调试07", "辉光开关", Role.HINT_GLOW_ENABLED),
                Feature.slider("Hint Debug 08", "Glow Strength", "提示调试08", "辉光强度", Role.HINT_GLOW_STRENGTH, 0.52f),
                hintGlowColorFeature
        };

        Feature scrollSettings = Feature.group("Debug 01", "Scroll Debug", "调试01", "滚动调试", Role.SCROLL_GROUP);
        scrollSettings.settings = new Feature[]{
                Feature.slider("Scroll Debug 01", "Scroll Speed", "滚动调试01", "滚动速度", Role.SCROLL_SPEED, 0.50f),
                Feature.slider("Scroll Debug 02", "Scroll Damping", "滚动调试02", "滚动阻尼", Role.SCROLL_DAMPING, 0.50f),
                Feature.slider("Scroll Debug 03", "Scrollbar Opacity", "滚动调试03", "滚动条透明度", Role.SCROLLBAR_OPACITY, 0.72f),
                Feature.slider("Scroll Debug 04", "Scrollbar Width", "滚动调试04", "滚动条宽度", Role.SCROLLBAR_WIDTH, 0.45f)
        };

        Feature ballSettings = Feature.group("Debug 02", "Floating Ball Debug", "调试02", "悬浮球调试", Role.BALL_GROUP);
        ballSettings.settings = new Feature[]{
                Feature.slider("Ball Debug 01", "Ball Size", "悬浮球调试01", "悬浮球大小", Role.BALL_SIZE, 0.50f),
                Feature.slider("Ball Debug 02", "Ball Opacity", "悬浮球调试02", "悬浮球透明度", Role.BALL_OPACITY, 1.00f),
                Feature.switcher("Ball Debug 03", "Snap Edge", true, "悬浮球调试03", "吸附边缘开关", Role.BALL_SNAP)
        };

        Feature animationSettings = Feature.group("Debug 03", "Animation Debug", "调试03", "动画调试", Role.ANIMATION_GROUP);
        Feature ballTransition = Feature.select("Animation Debug 04", "Open/Close Ball Animation", new String[]{"Particle", "Default"}, 0);
        ballTransition.nameCn = "动画调试04";
        ballTransition.titleCn = "开启关闭悬浮球动画";
        ballTransition.optionsCn = new String[]{"粒子", "初始动画"};
        ballTransition.role = Role.ANIM_BALL_TRANSITION;
        ballTransition.isSettingOnlyForNoToast = true;

        animationSettings.settings = new Feature[]{
                Feature.switcher("Animation Debug 00", "Animation Enabled", true, "动画调试00", "动画开关", Role.ANIM_ENABLED),
                Feature.slider("Animation Debug 01", "Open/Close Speed", "动画调试01", "打开/关闭动画速度", Role.ANIM_PANEL, 0.50f),
                Feature.slider("Animation Debug 02", "Section Speed", "动画调试02", "板块切换动画速度", Role.ANIM_SECTION, 0.50f),
                Feature.slider("Animation Debug 03", "Debug Expand Speed", "动画调试03", "调试展开动画速度", Role.ANIM_DEBUG, 0.50f),
                ballTransition
        };

        Feature musicWindow = Feature.switcher("Enable 03", "Music Window", false);
        musicWindow.debuggable = true;
        musicWindow.nameCn = "开启03";
        musicWindow.titleCn = "音乐悬浮窗";
        musicWindow.role = Role.MUSIC_WINDOW;
        Feature defaultMusicPanel = Feature.select("Music Debug 04", "Default Panel", new String[]{"Local", "Netease"}, 0);
        defaultMusicPanel.nameCn = "音乐窗调试04"; defaultMusicPanel.titleCn = "默认面板"; defaultMusicPanel.optionsCn = new String[]{"本地音乐", "网易云"}; defaultMusicPanel.role = Role.MUSIC_DEFAULT_PANEL; defaultMusicPanel.isSettingOnlyForNoToast = true;
        musicWindow.settings = new Feature[]{
                Feature.slider("Music Debug 01", "Window Size", "音乐窗调试01", "音乐窗大小", Role.MUSIC_SCALE, 0.50f),
                Feature.slider("Music Debug 02", "Lyric Size", "音乐窗调试02", "歌词字体大小", Role.MUSIC_LYRIC_SCALE, 0.50f),
                Feature.slider("Music Debug 03", "Progress Height", "音乐窗调试03", "进度条高度", Role.MUSIC_PROGRESS_HEIGHT, 0.50f),
                defaultMusicPanel
        };

        Feature logWindow = Feature.switcher("Enable 04", "Runtime Log", false);
        logWindow.debuggable = true;
        logWindow.nameCn = "开启04";
        logWindow.titleCn = "实时日志";
        logWindow.role = Role.LOG_WINDOW;
        // 清除和导出按钮只显示在日志悬浮窗内部；日志窗口参数放在实时日志调试内。
        logWindow.settings = new Feature[]{
                Feature.slider("Log Debug 01", "Log Text Size", "日志调试01", "日志字体大小", Role.LOG_TEXT_SIZE, 0.50f),
                Feature.slider("Log Debug 02", "Log Opacity", "日志调试02", "日志透明度", Role.LOG_OPACITY, 1.00f),
                Feature.switcher("Log Debug 03", "Auto Scroll", true, "日志调试03", "自动滚动", Role.LOG_AUTO_SCROLL),
                Feature.switcher("Log Debug 04", "Record FPS", true, "日志调试04", "记录 FPS", Role.LOG_RECORD_FPS),
                Feature.switcher("Log Debug 05", "Record Touch", true, "日志调试05", "记录点击事件", Role.LOG_RECORD_TOUCH)
        };

        Feature arrayList = Feature.switcher("Enable 05", "ArrayList", false);
        arrayList.debuggable = true;
        arrayList.nameCn = "开启05";
        arrayList.titleCn = "功能列表";
        arrayList.role = Role.ARRAYLIST_WINDOW;
        Feature arrayBarColorFeature = Feature.color("ArrayList Debug 03", "Bar Color", "功能列表调试03", "边条颜色", Role.ARRAYLIST_BAR_COLOR, arrayListBarColor);
        arrayBarColorFeature.colorGradient = arrayListBarGradient;
        arrayBarColorFeature.gradientColors = copyColors(arrayListBarColors);
        arrayBarColorFeature.gradientSpeed = arrayListBarGradientSpeed;
        arrayBarColorFeature.gradientStyle = arrayListBarGradientStyle;
        arrayBarColorFeature.gradientDelay = arrayListBarGradientDelay;
        Feature arrayTextColorFeature = Feature.color("ArrayList Debug 05", "Text Color", "功能列表调试05", "文字颜色", Role.ARRAYLIST_TEXT_COLOR, arrayListTextColor);
        arrayTextColorFeature.colorGradient = arrayListTextGradient;
        arrayTextColorFeature.gradientColors = copyColors(arrayListTextColors);
        arrayTextColorFeature.gradientSpeed = arrayListTextGradientSpeed;
        arrayTextColorFeature.gradientStyle = arrayListTextGradientStyle;
        arrayTextColorFeature.gradientDelay = arrayListTextGradientDelay;
        arrayList.settings = new Feature[]{
                Feature.slider("ArrayList Debug 01", "Bar Length", "功能列表调试01", "边条长度", Role.ARRAYLIST_BAR_LENGTH, 0.50f),
                Feature.slider("ArrayList Debug 02", "Bar Width", "功能列表调试02", "边条宽度", Role.ARRAYLIST_BAR_WIDTH, 0.50f),
                arrayBarColorFeature,
                Feature.slider("ArrayList Debug 04", "List Size", "功能列表调试04", "功能列表大小", Role.ARRAYLIST_TEXT_SIZE, 0.50f),
                arrayTextColorFeature,
                Feature.switcher("ArrayList Debug 06", "Glow", true, "功能列表调试06", "辉光开关", Role.ARRAYLIST_GLOW_ENABLED),
                Feature.slider("ArrayList Debug 07", "Glow Strength", "功能列表调试07", "光辉强度", Role.ARRAYLIST_GLOW_STRENGTH, 0.55f),
                Feature.switcher("ArrayList Debug 08", "Drag Position", false, "功能列表调试08", "拖动调试位置", Role.ARRAYLIST_POSITION),
                Feature.switcher("ArrayList Debug 09", "Show Debug Settings", false, "功能列表调试09", "展示功能调试设置", Role.ARRAYLIST_SHOW_DEBUG)
        };

        Feature shortcutSettings = Feature.group("Debug 04", "Shortcut Debug", "调试04", "快捷键调试", Role.SHORTCUT_GROUP);
        Feature shortcutShapeSelect = Feature.select("Shortcut Debug 03", "Shortcut Shape", new String[]{"Rounded", "Circle"}, 0);
        shortcutShapeSelect.nameCn = "快捷键调试03";
        shortcutShapeSelect.titleCn = "快捷键方案";
        shortcutShapeSelect.optionsCn = new String[]{"圆角长方形", "圆形"};
        shortcutShapeSelect.role = Role.SHORTCUT_SHAPE;
        shortcutShapeSelect.isSettingOnlyForNoToast = true;
        Feature shortcutBorderColorFeature = Feature.color("Shortcut Debug 08", "Border Color", "快捷键调试08", "描边颜色", Role.SHORTCUT_BORDER_COLOR, shortcutBorderColor);
        shortcutBorderColorFeature.colorGradient = shortcutBorderGradient;
        shortcutBorderColorFeature.gradientColors = copyColors(shortcutBorderColors);
        shortcutBorderColorFeature.gradientSpeed = shortcutBorderGradientSpeed;
        shortcutBorderColorFeature.gradientStyle = shortcutBorderGradientStyle;
        shortcutBorderColorFeature.gradientDelay = shortcutBorderGradientDelay;
        Feature shortcutGlowColorFeature = Feature.color("Shortcut Debug 14", "Glow Color", "快捷键调试14", "辉光颜色", Role.SHORTCUT_GLOW_COLOR, shortcutGlowColor);
        shortcutGlowColorFeature.colorGradient = false;
        shortcutGlowColorFeature.gradientColors = copyColors(shortcutGlowColors);
        shortcutGlowColorFeature.gradientSpeed = shortcutGlowGradientSpeed;
        shortcutGlowColorFeature.gradientStyle = shortcutGlowGradientStyle;
        shortcutGlowColorFeature.gradientDelay = shortcutGlowGradientDelay;
        shortcutSettings.settings = new Feature[]{
                Feature.slider("Shortcut Debug 01", "Key Background Opacity", "快捷键调试01", "快捷键背景透明度", Role.SHORTCUT_BG_OPACITY, 0.82f),
                Feature.slider("Shortcut Debug 02", "Key Border Opacity", "快捷键调试02", "快捷键描边透明度", Role.SHORTCUT_BORDER_OPACITY, 0.95f),
                shortcutShapeSelect,
                Feature.color("Shortcut Debug 04", "On Text Color", "快捷键调试04", "开启时文本颜色", Role.SHORTCUT_ON_TEXT_COLOR, shortcutOnTextColor),
                Feature.color("Shortcut Debug 05", "On Background Color", "快捷键调试05", "开启时背景颜色", Role.SHORTCUT_ON_BG_COLOR, shortcutOnBgColor),
                Feature.color("Shortcut Debug 06", "Off Text Color", "快捷键调试06", "关闭时文本颜色", Role.SHORTCUT_OFF_TEXT_COLOR, shortcutOffTextColor),
                Feature.color("Shortcut Debug 07", "Off Background Color", "快捷键调试07", "关闭时背景颜色", Role.SHORTCUT_OFF_BG_COLOR, shortcutOffBgColor),
                shortcutBorderColorFeature,
                Feature.slider("Shortcut Debug 09", "Background Size", "快捷键调试09", "背景大小", Role.SHORTCUT_BG_SIZE, 0.50f),
                Feature.slider("Shortcut Debug 10", "Border Size", "快捷键调试10", "描边大小", Role.SHORTCUT_BORDER_SIZE, 0.50f),
                Feature.slider("Shortcut Debug 11", "Font Size", "快捷键调试11", "字体大小", Role.SHORTCUT_FONT_SIZE, 0.50f),
                Feature.switcher("Shortcut Debug 12", "Glow", true, "快捷键调试12", "辉光开关", Role.SHORTCUT_GLOW_ENABLED),
                Feature.slider("Shortcut Debug 13", "Glow Strength", "快捷键调试13", "辉光强度", Role.SHORTCUT_GLOW_STRENGTH, 0.72f),
                shortcutGlowColorFeature
        };

        Feature fontSettings = Feature.group("Debug 05", "Font Import", "调试05", "字体调试", Role.FONT_GROUP);
        fontSettings.settings = new Feature[]{
                Feature.action("Font Debug 01", "Import TTF/OTF", "字体调试01", "导入 TTF/OTF", Role.FONT_IMPORT),
                Feature.action("Font Debug 02", "Restore Default", "字体调试02", "恢复原样", Role.FONT_RESET)
        };

        Feature globalSettings = Feature.group("Debug 00", "Global Debug", "调试00", "全局调试", Role.GLOBAL_GROUP);
        globalSettings.settings = new Feature[]{
                Feature.slider("Global Debug 01", "Global Resolution", "全局调试01", "全局分辨率", Role.GLOBAL_RESOLUTION, 0.32f),
                Feature.slider("Global Debug 02", "Performance Quality", "全局调试02", "性能调试", Role.GLOBAL_PERFORMANCE, 0.60f),
                Feature.slider("Global Debug 03", "Global Opacity", "全局调试03", "全局透明度", Role.GLOBAL_OPACITY, 1.00f),
                Feature.slider("Global Debug 04", "Corner Scale", "全局调试04", "全局圆角倍率", Role.GLOBAL_CORNER, 0.50f),
                Feature.slider("Global Debug 05", "Stroke Scale", "全局调试05", "全局描边倍率", Role.GLOBAL_STROKE, 0.50f),
                Feature.slider("Global Debug 06", "Glow Scale", "全局调试06", "全局辉光倍率", Role.GLOBAL_GLOW, 0.50f),
                Feature.slider("Global Debug 07", "Animation Speed", "全局调试07", "全局动画速度", Role.GLOBAL_ANIM_SPEED, 0.50f),
                Feature.slider("Global Debug 08", "Font Size Scale", "全局调试08", "全局字体大小倍率", Role.GLOBAL_TEXT_SCALE, 0.50f),
                Feature.slider("Global Debug 09", "Glass Strength", "全局调试09", "全局玻璃强度", Role.GLOBAL_GLASS, 0.50f),
                Feature.slider("Global Debug 10", "Background Dim", "全局调试10", "全局背景暗化", Role.GLOBAL_DIM, 0.00f),
                Feature.slider("Global Debug 11", "Touch Feedback", "全局调试11", "触摸反馈强度", Role.GLOBAL_TOUCH_FEEDBACK, 0.50f)
        };

        Feature guiSettings = Feature.group("Debug 06", "ui设置", "调试06", "ui设置", Role.GUI_GROUP);
        guiSettings.settings = new Feature[]{
                Feature.slider("UI Setting 01", "Panel Width", "ui设置01", "面板宽度", Role.PANEL_WIDTH, 0.50f),
                Feature.slider("UI Setting 02", "Panel Height", "ui设置02", "面板高度", Role.PANEL_HEIGHT, 0.50f),
                Feature.slider("UI Setting 03", "Panel Background Opacity", "ui设置03", "面板背景透明度", Role.PANEL_BG_OPACITY, 1.00f),
                Feature.slider("UI Setting 04", "Panel Corner", "ui设置04", "面板圆角", Role.PANEL_CORNER, 0.50f),
                Feature.slider("UI Setting 05", "Panel Stroke", "ui设置05", "面板描边大小", Role.PANEL_STROKE, 0.50f),
                Feature.slider("UI Setting 06", "Panel Padding", "ui设置06", "面板内边距", Role.PANEL_PADDING, 0.50f),
                Feature.switcher("UI Setting 07", "Panel Glow", true, "ui设置07", "面板辉光开关", Role.PANEL_GLOW_ENABLED),
                Feature.slider("UI Setting 08", "Panel Glow Strength", "ui设置08", "面板辉光强度", Role.PANEL_GLOW, 0.00f),
                Feature.slider("UI Setting 09", "Panel Title Size", "ui设置09", "标题字体大小", Role.PANEL_TITLE_SIZE, 0.50f),
                Feature.slider("UI Setting 10", "Panel Content Text Size", "ui设置10", "内容字体大小", Role.PANEL_CONTENT_SIZE, 0.50f),
                Feature.switcher("UI Setting 11", "Panel Edge Snap", false, "ui设置11", "边缘吸附", Role.PANEL_EDGE_SNAP),
                Feature.slider("UI Setting 12", "Section Size", "ui设置12", "板块大小", Role.SECTION_SIZE, 0.50f),
                Feature.slider("UI Setting 13", "Section Spacing", "ui设置13", "板块间距", Role.SECTION_SPACING, 0.50f),
                Feature.slider("UI Setting 14", "Section Corner", "ui设置14", "板块圆角", Role.SECTION_CORNER, 0.50f),
                Feature.slider("UI Setting 15", "Section Text", "ui设置15", "板块文字大小", Role.SECTION_TEXT, 0.50f),
                Feature.switcher("UI Setting 16", "Section Glow", true, "ui设置16", "板块辉光开关", Role.SECTION_GLOW_ENABLED),
                Feature.slider("UI Setting 17", "Section Glow Strength", "ui设置17", "板块辉光强度", Role.SECTION_GLOW, 0.00f),
                Feature.slider("UI Setting 18", "Feature Button Height", "ui设置18", "功能按钮高度", Role.FEATURE_HEIGHT, 0.50f),
                Feature.slider("UI Setting 19", "Feature Button Gap", "ui设置19", "功能按钮间距", Role.FEATURE_GAP, 0.50f),
                Feature.slider("UI Setting 20", "Feature Button Corner", "ui设置20", "功能按钮圆角", Role.FEATURE_CORNER, 0.50f),
                Feature.slider("UI Setting 21", "Feature Text Size", "ui设置21", "功能文字大小", Role.FEATURE_TEXT, 0.50f),
                Feature.slider("UI Setting 22", "Feature Stroke Width", "ui设置22", "功能描边大小", Role.FEATURE_STROKE, 0.50f),
                Feature.switcher("UI Setting 23", "Feature Glow", true, "ui设置23", "功能辉光开关", Role.FEATURE_GLOW_ENABLED),
                Feature.slider("UI Setting 24", "Feature Glow Strength", "ui设置24", "功能辉光强度", Role.FEATURE_GLOW, 0.00f),
                Feature.slider("UI Setting 25", "Feature Press Feedback", "ui设置25", "按下缩放强度", Role.FEATURE_PRESS, 0.50f),
                Feature.switcher("UI Setting 26", "Show Feature Icons", false, "ui设置26", "显示图标", Role.FEATURE_ICONS),
                Feature.switcher("UI Setting 27", "Haptic Feedback", false, "ui设置27", "震动反馈", Role.FEATURE_HAPTIC)
        };

        Feature layoutSettings = Feature.group("Debug 09", "Layout Debug", "调试09", "布局调试", Role.LAYOUT_GROUP);
        layoutSettings.settings = new Feature[]{
                Feature.slider("Layout Debug 01", "Left Width", "布局调试01", "左侧栏宽度", Role.LAYOUT_LEFT_WIDTH, 0.50f),
                Feature.slider("Layout Debug 02", "Top Height", "布局调试02", "顶部高度", Role.LAYOUT_TOP_HEIGHT, 0.50f),
                Feature.slider("Layout Debug 03", "Control Gap", "布局调试03", "控件间距", Role.LAYOUT_ROW_GAP, 0.50f),
                Feature.slider("Layout Debug 04", "Control Width", "布局调试04", "选择框宽度", Role.LAYOUT_CONTROL_WIDTH, 0.50f),
                Feature.slider("Layout Debug 05", "Slider Height", "布局调试05", "滑条高度", Role.LAYOUT_SLIDER_HEIGHT, 0.50f),
                Feature.slider("Layout Debug 06", "Safe Inset", "布局调试06", "安全区偏移", Role.LAYOUT_SAFE_INSET, 0.50f),
                Feature.switcher("Layout Debug 07", "Show Scrollbar", true, "布局调试07", "显示滚动条", Role.LAYOUT_SCROLLBAR_VISIBLE)
        };

        Feature themeSettings = Feature.group("Debug 10", "Theme Advanced", "调试10", "主题高级调试", Role.THEME_GROUP);
        Feature rgbDirection = Feature.select("Theme Debug 01", "RGB Direction", new String[]{"Horizontal", "Vertical", "Diagonal", "Center"}, 0);
        rgbDirection.nameCn = "主题调试01"; rgbDirection.titleCn = "RGB 渐变方向"; rgbDirection.optionsCn = new String[]{"横向", "竖向", "对角", "中心"}; rgbDirection.role = Role.THEME_RGB_DIRECTION; rgbDirection.isSettingOnlyForNoToast = true;
        themeSettings.settings = new Feature[]{
                rgbDirection,
                Feature.slider("Theme Debug 02", "iOS Glass Opacity", "主题调试02", "iOS 玻璃透明度", Role.THEME_IOS_OPACITY, 0.50f),
                Feature.slider("Theme Debug 03", "iOS Highlight", "主题调试03", "iOS 高光强度", Role.THEME_IOS_HIGHLIGHT, 0.50f),
                Feature.slider("Theme Debug 04", "Noise Strength", "主题调试04", "噪点强度", Role.THEME_NOISE, 0.25f)
        };

        // 音乐窗调试和日志窗调试已合并到对应的“音乐悬浮窗 / 实时日志”功能内。

        Feature pickerSettings = Feature.group("Debug 13", "Color Picker Debug", "调试13", "选色器调试", Role.PICKER_GROUP);
        pickerSettings.settings = new Feature[]{
                Feature.none("Picker Debug 01", "Every color picker supports static / gradient / classic cycle", "选色器调试01", "静态 / 渐变 / 经典变色"),
                Feature.none("Picker Debug 02", "Gradient speed 100%-600% and gradient delay are available", "选色器调试02", "渐变速度与渐变延迟"),
                Feature.none("Picker Debug 03", "RGB input, palette click and color list are supported", "选色器调试03", "RGB 输入与颜色列表")
        };

        Feature configSettings = Feature.group("Debug 14", "Config Manager", "调试14", "配置管理", Role.CONFIG_GROUP);
        configSettings.settings = new Feature[]{
                Feature.action("Config Debug 01", "Save Current Config", "配置调试01", "保存当前配置", Role.CONFIG_SAVE),
                Feature.action("Config Debug 02", "Load Config", "配置调试02", "加载配置", Role.CONFIG_LOAD),
                Feature.action("Config Debug 03", "Restore Defaults", "配置调试03", "恢复默认", Role.CONFIG_RESTORE),
                Feature.action("Config Debug 04", "Random RGB Theme", "配置调试04", "随机 RGB 主题", Role.CONFIG_RANDOM_THEME)
        };

        sections[4] = new Section(new Feature[]{chinese, switchHint, musicWindow, logWindow, arrayList, theme, globalSettings, guiSettings, layoutSettings, themeSettings, scrollSettings, ballSettings, animationSettings, shortcutSettings, pickerSettings, configSettings, fontSettings});
        installShortcutSettings();

        applyFeatureValue(chinese);
        applyFeatureValue(switchHint);
        for (int i = 0; i < switchHint.settings.length; i++) applyFeatureValue(switchHint.settings[i]);
        applyFeatureValue(scrollSettings.settings[0]);
        applyFeatureValue(scrollSettings.settings[1]);
        applyFeatureValue(scrollSettings.settings[2]);
        applyFeatureValue(scrollSettings.settings[3]);
        applyFeatureValue(ballSettings.settings[0]);
        applyFeatureValue(ballSettings.settings[1]);
        applyFeatureValue(ballSettings.settings[2]);
        applyFeatureValue(animationSettings.settings[0]);
        applyFeatureValue(animationSettings.settings[1]);
        applyFeatureValue(animationSettings.settings[2]);
        applyFeatureValue(animationSettings.settings[3]);
        applyFeatureValue(musicWindow);
        applyFeatureValue(arrayList);
        for (int i = 0; i < sections[4].features.length; i++) {
            Feature root = sections[4].features[i];
            if (root.settings != null) {
                for (int j = 0; j < root.settings.length; j++) applyFeatureValue(root.settings[j]);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        screenRect.set(0, 0, w, h);
        if (!panelBoundsReady && w > 0 && h > 0) {
            float marginX = w * 0.038f;
            float marginY = h * 0.055f;
            panelRect.set(marginX, marginY, w - marginX, h - marginY);
            if (savedPanelBoundsLoaded && savedPanelR > savedPanelL && savedPanelB > savedPanelT) {
                panelRect.set(savedPanelL * w, savedPanelT * h, savedPanelR * w, savedPanelB * h);
            }
            panelBoundsReady = true;
        }
        if (!ballPositionReady && w > 0 && h > 0) {
            ballX = Math.max(12, panelRect.left - 40);
            ballY = panelRect.top + 42;
            ballPositionReady = true;
        }
        if (!musicPositionReady && w > 0 && h > 0) {
            musicX = w - musicWindowWidth() - dpRaw(28);
            musicY = h * 0.16f;
            musicPositionReady = true;
        }
        rebuildLayoutCache();
    }

    private void rebuildLayoutCache() {
        if (getWidth() <= 0 || getHeight() <= 0 || !panelBoundsReady) {
            layoutReady = false;
            return;
        }

        constrainPanelRect();
        uiScale = Math.min(panelRect.width() / 1280f, panelRect.height() / 720f);
        if (uiScale < 0.48f) uiScale = 0.48f;
        if (uiScale > 1.72f) uiScale = 1.72f;

        float margin = Math.max(dp(14), panelRect.width() * 0.022f) * panelPaddingScale * layoutSafeInsetScale;
        float sidebarLeft = panelRect.left + margin;
        float sidebarW = Math.min(dp(255), panelRect.width() * 0.235f) * layoutLeftWidthScale;
        if (sidebarW < dp(142)) sidebarW = dp(142);

        float logoSize = Math.min(dp(58), Math.max(dp(36), panelRect.height() * 0.095f));
        logoRect.set(sidebarLeft, panelRect.top + dp(24), sidebarLeft + logoSize, panelRect.top + dp(24) + logoSize);

        float footerH = Math.min(dp(44), Math.max(dp(28), panelRect.height() * 0.067f));
        footerRect.set(sidebarLeft, panelRect.bottom - dp(24) - footerH, sidebarLeft + sidebarW, panelRect.bottom - dp(24));

        float sectionTop = Math.max(logoRect.bottom + dp(34), panelRect.top + dp(104));
        float sectionBottom = footerRect.top - dp(18);
        float gap = Math.max(dp(5), Math.min(dp(10), panelRect.height() * 0.012f)) * sectionSpacingScale;
        float itemH = (sectionBottom - sectionTop - gap * 4f) / 5f;
        if (itemH > dp(58)) itemH = dp(58);
        if (itemH < dp(28)) itemH = dp(28);
        itemH *= sectionSizeScale;
        for (int i = 0; i < SECTION_COUNT; i++) {
            float y = sectionTop + i * (itemH + gap);
            sectionRects[i].set(sidebarLeft, y, sidebarLeft + sidebarW, y + itemH);
        }

        dividerRect.set(sidebarLeft + sidebarW + dp(14), panelRect.top + dp(26), sidebarLeft + sidebarW + dp(15), panelRect.bottom - dp(26));

        float contentLeft = dividerRect.right + dp(22);
        float contentRight = panelRect.right - margin;
        if (contentRight - contentLeft < dp(400)) {
            contentLeft = dividerRect.right + dp(14);
            contentRight = panelRect.right - dp(14);
        }
        float contentW = contentRight - contentLeft;
        float searchH = Math.min(dp(48), Math.max(dp(34), panelRect.height() * 0.072f)) * layoutTopHeightScale;
        searchRect.set(contentLeft, panelRect.top + dp(24), contentRight, panelRect.top + dp(24) + searchH);
        closeRect.set(searchRect.right - searchH + dp(7), searchRect.top + dp(7), searchRect.right - dp(7), searchRect.bottom - dp(7));

        float badgeH = Math.min(dp(34), Math.max(dp(24), panelRect.height() * 0.052f));
        float badgeW = Math.min(dp(138), Math.max(dp(92), contentW * 0.25f));
        badgeRect.set(contentRight - badgeW, searchRect.bottom + dp(14), contentRight, searchRect.bottom + dp(14) + badgeH);

        float listTop = Math.max(searchRect.bottom + dp(92) * layoutTopHeightScale, panelRect.top + dp(132) * layoutTopHeightScale);
        featureListRect.set(contentLeft, listTop, contentRight, panelRect.bottom - dp(24));
        welcomeCardRect.set(featureListRect.left, featureListRect.top, featureListRect.right, Math.min(featureListRect.bottom, featureListRect.top + dp(178)));

        layoutFeatureCards();

        float baseBall = Math.min(getHeight() * 0.13f, Math.max(54f, dpRaw(88) * Math.min(getWidth() / 1280f, getHeight() / 720f)));
        ballSize = baseBall * (0.72f + ballSizeFactor * 0.72f);
        clampBall();
        clampMusic();

        if (!hintPositionReady) {
            setHintDefaultPosition();
            hintPositionReady = true;
        } else {
            clampHint();
        }
        layoutReady = true;
    }

    private void layoutFeatureCards() {
        Section section = sections[selectedSection];
        float y = featureListRect.top - scrollY;
        float gap = Math.max(dp(7), Math.min(dp(13), panelRect.height() * 0.015f)) * featureGapScale * layoutRowGapScale;
        float visibleH = featureListRect.height();
        float baseH = Math.min(dp(94), Math.max(dp(64), visibleH * 0.18f));
        if (selectedSection != 4) baseH = Math.min(dp(86), Math.max(dp(60), visibleH * 0.18f));
        baseH *= featureHeightScale;
        float settingRowH = Math.min(dp(54), Math.max(dp(38), visibleH * 0.092f)) * featureHeightScale;
        float settingGap = Math.max(dp(4), Math.min(dp(7), panelRect.height() * 0.009f)) * layoutRowGapScale;

        float total = 0f;
        for (int i = 0; i < section.features.length; i++) {
            Feature f = section.features[i];
            float extra = 0f;
            if (f.settings != null && f.settings.length > 0) {
                extra = f.debugProgress * (dp(14) + f.settings.length * settingRowH + Math.max(0, f.settings.length - 1) * settingGap + dp(12));
            }
            total += baseH + extra;
            if (i < section.features.length - 1) total += gap;
        }
        maxScrollY = Math.max(0f, total - visibleH);
        clampScroll();
        y = featureListRect.top - scrollY;

        for (int i = 0; i < section.features.length; i++) {
            Feature f = section.features[i];
            float extra = 0f;
            if (f.settings != null && f.settings.length > 0) {
                extra = f.debugProgress * (dp(14) + f.settings.length * settingRowH + Math.max(0, f.settings.length - 1) * settingGap + dp(12));
            }
            f.cardRect.set(featureListRect.left, y, featureListRect.right, y + baseH + extra);
            f.mainRect.set(f.cardRect.left, f.cardRect.top, f.cardRect.right, f.cardRect.top + baseH);
            layoutControlForFeature(f, f.mainRect);

            if (f.settings != null) {
                float p = easeValue(f.debugProgress);
                float st = f.mainRect.bottom + dp(11) * p;
                for (int s = 0; s < f.settings.length; s++) {
                    Feature setting = f.settings[s];
                    float rowTop = st + s * (settingRowH + settingGap);
                    setting.cardRect.set(f.cardRect.left + dp(24), rowTop, f.cardRect.right - dp(24), rowTop + settingRowH);
                    layoutControlForFeature(setting, setting.cardRect);
                }
            }
            y = f.cardRect.bottom + gap;
        }
    }

    private void layoutControlForFeature(Feature f, RectF area) {
        float controlH = Math.min(dp(36), Math.max(dp(25), area.height() * 0.48f)) * layoutSliderHeightScale;
        float controlW = dp(150);
        if (f.type == CONTROL_SWITCH) controlW = controlH * 1.92f;
        else if (f.type == CONTROL_SELECT) controlW = Math.min(dp(164), Math.max(dp(112), area.width() * 0.22f));
        else if (f.type == CONTROL_SLIDER) controlW = Math.min(dp(258), Math.max(dp(132), area.width() * 0.36f));
        else if (f.type == CONTROL_GROUP) controlW = Math.min(dp(116), Math.max(dp(82), area.width() * 0.16f));
        else if (f.type == CONTROL_COLOR) controlW = Math.min(dp(166), Math.max(dp(106), area.width() * 0.22f));
        else if (f.type == CONTROL_ACTION) controlW = Math.min(dp(150), Math.max(dp(98), area.width() * 0.20f));
        controlW *= layoutControlWidthScale;
        f.controlRect.set(area.right - controlW - dp(24), area.centerY() - controlH / 2f, area.right - dp(24), area.centerY() + controlH / 2f);
        if (f.type == CONTROL_SLIDER && f.role == Role.HINT_DURATION) {
            f.controlRect.inset(0, -dp(3));
        }
    }

    @Override
    /**
     * Main render entry.
     *
     * Draw order matters:
     * 1. background/test surface
     * 2. panel and debug controls
     * 3. floating shortcuts / music / lyrics / logs
     * 4. top-level popups such as color picker
     */
    protected void onDraw(Canvas canvas) {
        frameScheduled = false;
        frameStartMs = SystemClock.uptimeMillis();
        hotInteractionFrame = isHotInteractionFrame();
        expensiveEffectsAllowed = shouldDrawExpensiveEffects(frameStartMs);
        long frameNowNs = System.nanoTime();
        frameDeltaSeconds = NativeUiOptimizer.frameDeltaSeconds(lastFrameNs, frameNowNs);
        lastFrameNs = frameNowNs;
        super.onDraw(canvas);
        updateFps();
        if (!layoutReady) rebuildLayoutCache();
        drawBackground(canvas);
        if (globalBackgroundDim > 0.01f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(applyAlpha(0xFF000000, (int)(globalBackgroundDim * 110)));
            canvas.drawRect(screenRect, paint);
        }
        if (panelProgress > 0.01f) drawPanel(canvas);
        drawTransitionParticles(canvas);
        drawMusicWindow(canvas);
        drawLyricOverlay(canvas);
        drawFeatureShortcuts(canvas);
        drawArrayListWindow(canvas);
        drawFloatingBall(canvas);
        drawHintToast(canvas);
        drawLogWindow(canvas);
        if (colorPickerOpen) drawColorPicker(canvas);
        if (shouldKeepFastRenderLoop()) {
            requestFrame();
        } else {
            long slowDelay = nextSlowFrameDelayMs();
            if (slowDelay > 0L) requestFrameDelayed(slowDelay);
        }
    }

    private void drawBackground(Canvas canvas) {
        ThemePalette t = theme();
        canvas.drawColor(t.pageBg);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(Math.min(dpRaw(13), getHeight() * 0.018f));
        textPaint.setColor(applyAlpha(t.textLight, 170));
        canvas.drawText(chineseMode ? "Canvas 横屏 UI 测试 - 拖动面板边缘可调整大小" : "Canvas landscape UI test - drag panel edge to resize", dpRaw(34), getHeight() - dpRaw(26), textPaint);
    }

    /**
     * Draws the main white/ios/rgb panel shell and applies open/close scale.
     * The body is split into smaller methods so each part can be optimized
     * without changing touch handling.
     */
    private void drawPanel(Canvas canvas) {
        int alpha = clampAlpha((int) (255 * panelProgress * globalOpacityScale));
        float scale = 0.965f + 0.035f * easeValue(panelProgress);
        canvas.save();
        canvas.scale(scale, scale, panelRect.centerX(), panelRect.centerY());
        drawPanelBody(canvas, alpha);
        drawSidebar(canvas, alpha);
        drawDivider(canvas, alpha);
        drawHeader(canvas, alpha);
        drawFeatureList(canvas, alpha);
        drawScrollBar(canvas, alpha);
        drawResizeHighlight(canvas, alpha);
        if (themeDropdownOpen || themeDropdownProgress > 0.001f) drawThemePopup(canvas, alpha);
        canvas.restore();
    }

    /**
     * Draws panel content: logo, section navigation, search bar, feature list
     * and footer. All coordinates are derived from panelRect every frame so
     * global scale/resolution debugging can move the whole layout safely.
     */
    private void drawPanelBody(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        float r = dp(34) * globalCornerScale * panelCornerScale;
        rect.set(panelRect);
        rect.offset(0, dp(7));
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0x10000000, alpha));
        canvas.drawRoundRect(rect, r, r, paint);
        rect.set(panelRect);
        rect.offset(0, dp(13));
        paint.setColor(applyAlpha(0x07000000, alpha));
        canvas.drawRoundRect(rect, r, r, paint);
        if (panelGlowEnabled && panelGlowStrength > 0.01f && !hotInteractionFrame) drawShapeGlow(canvas, panelRect, r, false, panelGlowStrength * globalGlowScale, false, null, 0xFF000000, alpha, true, 1.0f, 0);
        if (isGlassTheme()) {
            drawGlassCard(canvas, panelRect, r, alpha);
        } else {
            int bodyAlpha = alpha;
            int bodyColor = t.panelBg;
            paint.setColor(applyAlpha(bodyColor, bodyAlpha));
            canvas.drawRoundRect(panelRect, r, r, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1.3f) * globalStrokeScale * panelStrokeScale);
            if (isRgbTheme()) {
                paint.setShader(makeMovingGradient(panelRect, rgbThemeColors(), t.accent, alpha, 1.25f));
                canvas.drawRoundRect(panelRect, r, r, paint);
                paint.setShader(null);
            } else {
                paint.setColor(applyAlpha(t.stroke, alpha));
                canvas.drawRoundRect(panelRect, r, r, paint);
            }
        }
    }

    private void drawResizeHighlight(Canvas canvas, int alpha) {
        if (!resizingPanel) return;
        ThemePalette t = theme();
        float s = dp(28);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3.0f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(applyAlpha(t.accent, alpha));
        if ((activeResizeMode & RESIZE_LEFT) != 0 && (activeResizeMode & RESIZE_TOP) != 0) drawCornerHandle(canvas, panelRect.left, panelRect.top, s, true, true);
        else if ((activeResizeMode & RESIZE_RIGHT) != 0 && (activeResizeMode & RESIZE_TOP) != 0) drawCornerHandle(canvas, panelRect.right, panelRect.top, s, false, true);
        else if ((activeResizeMode & RESIZE_LEFT) != 0 && (activeResizeMode & RESIZE_BOTTOM) != 0) drawCornerHandle(canvas, panelRect.left, panelRect.bottom, s, true, false);
        else if ((activeResizeMode & RESIZE_RIGHT) != 0 && (activeResizeMode & RESIZE_BOTTOM) != 0) drawCornerHandle(canvas, panelRect.right, panelRect.bottom, s, false, false);
        else if ((activeResizeMode & RESIZE_LEFT) != 0) canvas.drawLine(panelRect.left, panelRect.top + s, panelRect.left, panelRect.bottom - s, paint);
        else if ((activeResizeMode & RESIZE_RIGHT) != 0) canvas.drawLine(panelRect.right, panelRect.top + s, panelRect.right, panelRect.bottom - s, paint);
        else if ((activeResizeMode & RESIZE_TOP) != 0) canvas.drawLine(panelRect.left + s, panelRect.top, panelRect.right - s, panelRect.top, paint);
        else if ((activeResizeMode & RESIZE_BOTTOM) != 0) canvas.drawLine(panelRect.left + s, panelRect.bottom, panelRect.right - s, panelRect.bottom, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawCornerHandle(Canvas canvas, float x, float y, float s, boolean left, boolean top) {
        float x2 = left ? x + s : x - s;
        float y2 = top ? y + s : y - s;
        canvas.drawLine(x, y, x2, y, paint);
        canvas.drawLine(x, y, x, y2, paint);
    }

    private void drawSidebar(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        drawAppLogoCard(canvas, logoRect, alpha);

        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(20) * globalTextScale * panelTitleScale);
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, "Linux", logoRect.right + dp(14), logoRect.top + dp(24), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(12) * globalTextScale * featureTextScale);
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, chineseMode ? "UI 测试面板" : "UI Test Panel", logoRect.right + dp(14), logoRect.top + dp(43), textPaint);

        float fromY = sectionRects[previousSection].top;
        float toY = sectionRects[selectedSection].top;
        float activeY = lerp(fromY, toY, easeValue(sectionProgress));
        rect.set(sectionRects[selectedSection]);
        rect.offset(0, activeY - rect.top);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.activeSoft, alpha));
        if (sectionGlowEnabled && sectionGlowStrength > 0.01f && !hotInteractionFrame) drawShapeGlow(canvas, rect, dp(18) * sectionCornerScale, false, sectionGlowStrength * globalGlowScale, false, null, 0xFF000000, alpha, true, 1.0f, 0);
        canvas.drawRoundRect(rect, dp(18) * globalCornerScale * sectionCornerScale, dp(18) * globalCornerScale * sectionCornerScale, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(rect, dp(18) * globalCornerScale * sectionCornerScale, dp(18) * globalCornerScale * sectionCornerScale, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.accent, alpha));
        tempRect.set(rect.left + dp(10), rect.top + dp(15), rect.left + dp(14), rect.bottom - dp(15));
        canvas.drawRoundRect(tempRect, dp(4), dp(4), paint);

        for (int i = 0; i < SECTION_COUNT; i++) {
            RectF item = sectionRects[i];
            boolean sel = i == selectedSection;
            textPaint.setTextSize(dp(15) * globalTextScale * sectionTextScale);
            textPaint.setFakeBoldText(sel);
            textPaint.setColor(applyAlpha(sel ? t.textDark : t.textMid, alpha));
            drawText(canvas, getSectionLabel(i), item.left + dp(30), item.centerY() + dp(5), textPaint);
        }
        textPaint.setFakeBoldText(false);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.softBg, alpha));
        canvas.drawRoundRect(footerRect, dp(15), dp(15), paint);
        textPaint.setTextSize(dp(12) * globalTextScale);
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, "FPS-" + currentFps, footerRect.left + dp(16), footerRect.centerY() + dp(4), textPaint);
    }

    private void drawLinuxLogo(Canvas canvas, float cx, float cy, float size, int alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0xFFFFFFFF, alpha));
        rect.set(cx - size * 0.46f, cy - size * 0.28f, cx + size * 0.46f, cy + size * 0.62f);
        canvas.drawOval(rect, paint);
        paint.setColor(applyAlpha(0xFF111827, alpha));
        canvas.drawCircle(cx - size * 0.18f, cy - size * 0.10f, size * 0.06f, paint);
        canvas.drawCircle(cx + size * 0.18f, cy - size * 0.10f, size * 0.06f, paint);
        paint.setColor(applyAlpha(0xFFF59E0B, alpha));
        canvas.drawCircle(cx, cy + size * 0.12f, size * 0.12f, paint);
    }

    private void drawAppLogoCard(Canvas canvas, RectF b, int alpha) {
        float r = dp(16);
        if (isRgbTheme()) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(makeMovingGradient(b, rgbThemeColors(), theme().accent, alpha, 1.2f));
            canvas.drawRoundRect(b, r, r, paint);
            paint.setShader(null);
            drawRgbPenguinIcon(canvas, b.centerX(), b.centerY(), Math.min(b.width(), b.height()) * 0.74f, alpha, true);
        } else if (isGlassTheme()) {
            drawGlassCard(canvas, b, r, alpha);
            drawMinimalPenguinIcon(canvas, b.centerX(), b.centerY(), Math.min(b.width(), b.height()) * 0.72f, alpha, true);
        } else {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(theme().accent, alpha));
            canvas.drawRoundRect(b, r, r, paint);
            drawMinimalPenguinIcon(canvas, b.centerX(), b.centerY(), Math.min(b.width(), b.height()) * 0.72f, alpha, false);
        }
    }

    private void drawGlassCard(Canvas canvas, RectF b, float r, int alpha) {
        ThemePalette t = theme();
        rect.set(b);
        rect.offset(0, Math.max(1f, r * 0.15f));
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(0x24000000, (int)(alpha * 0.75f)));
        canvas.drawRoundRect(rect, r, r, paint);
        if (!hotInteractionFrame) drawShapeGlow(canvas, b, r, false, 0.16f * globalGlassStrength, false, null, 0x66FFFFFF, (int)(alpha * 0.36f * themeIosHighlight), false);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(t.panelBg, isGlassTheme() ? (int)(alpha * 0.76f * globalGlassStrength * themeIosGlassOpacity) : (int)(alpha * panelBgOpacityScale)));
        canvas.drawRoundRect(b, r, r, paint);
        tempRect.set(b.left + 1f, b.top + 1f, b.right - 1f, b.top + b.height() * 0.48f);
        paint.setColor(applyAlpha(0x70FFFFFF, isGlassTheme() ? (int)(alpha * 0.26f * globalGlassStrength * themeIosHighlight) : 0));
        canvas.drawRoundRect(tempRect, Math.max(1f, r - 1f), Math.max(1f, r - 1f), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, r * 0.035f));
        if (isRgbTheme()) {
            paint.setShader(makeMovingGradient(b, rgbThemeColors(), t.accent, alpha, 1.25f));
            canvas.drawRoundRect(b, r, r, paint);
            paint.setShader(null);
        } else {
            paint.setColor(applyAlpha(isGlassTheme() ? 0x80FFFFFF : t.stroke, alpha));
            canvas.drawRoundRect(b, r, r, paint);
        }
    }

    // Canvas port inspired by Jacquesqwq/LiquidGlassShader:
    // - blurred/tinted sample layer
    // - superellipse-like soft edge
    // - directional rim lighting
    // - subtle stable glass grain
    // Android Canvas cannot sample the OpenGL framebuffer like the GLSL shader, so this keeps the
    // visual model while remaining AIDE/Java compatible.
    private void drawLiquidGlassSurface(Canvas canvas, RectF b, float r, int alpha, float press) {
        ThemePalette t = theme();
        int a = clampAlpha(alpha);
        float p = clamp(press, 0f, 1f);

        rect.set(b);
        rect.offset(0, Math.max(1f, r * 0.18f));
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(0x28000000, (int)(a * 0.62f)));
        canvas.drawRoundRect(rect, r, r, paint);

        if (!hotInteractionFrame) {
            drawShapeGlow(canvas, b, r, false, 0.18f + 0.08f * p, false, null, 0x90FFFFFF, (int)(a * 0.42f), false);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(
                b.left, b.top, b.right, b.bottom,
                new int[]{
                        applyAlpha(0xBBFFFFFF, (int)(a * (0.24f + 0.06f * p))),
                        applyAlpha(0x665B8CFF, (int)(a * 0.20f)),
                        applyAlpha(t.panelBg, (int)(a * (0.64f + 0.08f * p))),
                        applyAlpha(0x3338BDF8, (int)(a * 0.20f))
                },
                new float[]{0f, 0.30f, 0.70f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawRoundRect(b, r, r, paint);
        paint.setShader(null);

        // Refraction-like center bloom. It mimics the shader sampling a blurred framebuffer through a
        // distorted superellipse by brighter, softer light in the center and colder edges.
        paint.setShader(new RadialGradient(
                b.centerX(), b.centerY(), Math.max(b.width(), b.height()) * 0.72f,
                new int[]{
                        applyAlpha(0x44FFFFFF, (int)(a * 0.56f)),
                        applyAlpha(0x18D8ECFF, (int)(a * 0.35f)),
                        applyAlpha(0x00000000, 0)
                },
                new float[]{0f, 0.54f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawRoundRect(b, r, r, paint);
        paint.setShader(null);

        // Top liquid highlight.
        tempRect.set(b.left + 1.5f, b.top + 1.5f, b.right - 1.5f, b.top + b.height() * 0.45f);
        paint.setShader(new LinearGradient(
                tempRect.left, tempRect.top, tempRect.left, tempRect.bottom,
                applyAlpha(0xAAFFFFFF, (int)(a * 0.32f)),
                applyAlpha(0x00FFFFFF, 0),
                Shader.TileMode.CLAMP));
        canvas.drawRoundRect(tempRect, Math.max(1f, r - 1f), Math.max(1f, r - 1f), paint);
        paint.setShader(null);

        // Directional rim lighting, close to LiquidGlassShader's Glow(localUV) edge mask.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, r * 0.045f));
        paint.setShader(new LinearGradient(
                b.left, b.top, b.right, b.bottom,
                new int[]{
                        applyAlpha(0xE8FFFFFF, (int)(a * 0.72f)),
                        applyAlpha(0x66BBD7FF, (int)(a * 0.42f)),
                        applyAlpha(0x22FFFFFF, (int)(a * 0.22f)),
                        applyAlpha(0xAAFFFFFF, (int)(a * 0.48f))
                },
                new float[]{0f, 0.38f, 0.70f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawRoundRect(b, r, r, paint);
        paint.setShader(null);

        // Inner fine outline and small specular cuts.
        paint.setStrokeWidth(Math.max(1f, r * 0.018f));
        paint.setColor(applyAlpha(0xB8FFFFFF, (int)(a * 0.36f)));
        rect.set(b.left + dp(2), b.top + dp(2), b.right - dp(2), b.bottom - dp(2));
        canvas.drawRoundRect(rect, Math.max(1f, r - dp(2)), Math.max(1f, r - dp(2)), paint);
        paint.setStrokeWidth(Math.max(1f, r * 0.014f));
        paint.setColor(applyAlpha(0xCCFFFFFF, (int)(a * 0.24f)));
        canvas.drawLine(b.left + r * 0.70f, b.top + r * 0.42f, b.left + b.width() * 0.38f, b.top + r * 0.18f, paint);
        canvas.drawLine(b.right - b.width() * 0.32f, b.bottom - r * 0.26f, b.right - r * 0.50f, b.bottom - r * 0.55f, paint);

        // Low-cost stable grain. Fixed grid avoids random per-frame shimmer.
        if (!hotInteractionFrame && b.width() > dp(45) && b.height() > dp(35)) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(applyAlpha(0xFFFFFFFF, (int)(a * 0.035f)));
            float step = Math.max(dp(13), Math.min(b.width(), b.height()) * 0.11f);
            int countX = Math.min(11, Math.max(2, (int)(b.width() / step)));
            int countY = Math.min(8, Math.max(2, (int)(b.height() / step)));
            for (int gy = 1; gy < countY; gy++) {
                for (int gx = 1; gx < countX; gx++) {
                    int seed = gx * 1103515245 + gy * 12345;
                    float nx = b.left + (gx + ((seed >>> 8) & 7) / 18f) * b.width() / countX;
                    float ny = b.top + (gy + ((seed >>> 3) & 7) / 18f) * b.height() / countY;
                    if (b.contains(nx, ny)) canvas.drawCircle(nx, ny, Math.max(0.65f, dp(0.55f)), paint);
                }
            }
        }
        paint.setShader(null);
    }

    private void drawMinimalPenguinIcon(Canvas canvas, float cx, float cy, float size, int alpha, boolean ios) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(ios ? 0xFFFFFFFF : 0xFF111827, alpha));
        rect.set(cx - size * 0.32f, cy - size * 0.25f, cx + size * 0.32f, cy + size * 0.38f);
        canvas.drawOval(rect, paint);
        paint.setColor(applyAlpha(ios ? 0xFF111827 : 0xFFFFFFFF, alpha));
        canvas.drawCircle(cx - size * 0.12f, cy - size * 0.06f, size * 0.035f, paint);
        canvas.drawCircle(cx + size * 0.12f, cy - size * 0.06f, size * 0.035f, paint);
        paint.setColor(applyAlpha(0xFFF59E0B, alpha));
        canvas.drawCircle(cx, cy + size * 0.08f, size * 0.075f, paint);
    }

    private void drawRgbPenguinIcon(Canvas canvas, float cx, float cy, float size, int alpha, boolean uiLogo) {
        RectF b = new RectF(cx - size * 0.42f, cy - size * 0.35f, cx + size * 0.42f, cy + size * 0.42f);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(makeMovingGradient(b, rgbThemeColors(), 0xFFE100FF, alpha, uiLogo ? 1.5f : 1.0f));
        canvas.drawOval(b, paint);
        paint.setShader(null);
        paint.setColor(applyAlpha(0xEEFFFFFF, alpha));
        rect.set(cx - size * 0.27f, cy - size * 0.05f, cx + size * 0.27f, cy + size * 0.42f);
        canvas.drawOval(rect, paint);
        // glasses
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, size * 0.035f));
        paint.setColor(applyAlpha(0xFF111827, alpha));
        rect.set(cx - size * 0.26f, cy - size * 0.16f, cx - size * 0.05f, cy + size * 0.04f);
        canvas.drawOval(rect, paint);
        rect.set(cx + size * 0.05f, cy - size * 0.16f, cx + size * 0.26f, cy + size * 0.04f);
        canvas.drawOval(rect, paint);
        canvas.drawLine(cx - size * 0.05f, cy - size * 0.06f, cx + size * 0.05f, cy - size * 0.06f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0xFFFFB020, alpha));
        canvas.drawCircle(cx, cy + size * 0.13f, size * 0.07f, paint);
    }

    private void drawDivider(Canvas canvas, int alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(theme().stroke, (int) (alpha * 0.82f)));
        canvas.drawRoundRect(dividerRect, dp(1), dp(1), paint);
    }

    private void drawHeader(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.softBg, alpha));
        canvas.drawRoundRect(searchRect, dp(18), dp(18), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(searchRect, dp(18), dp(18), paint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(14));
        textPaint.setColor(applyAlpha(t.textLight, alpha));
        drawText(canvas, chineseMode ? "搜索设置..." : "Search settings...", searchRect.left + dp(18), searchRect.centerY() + dp(5), textPaint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.activeSoft, alpha));
        canvas.drawOval(closeRect, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.8f));
        paint.setColor(applyAlpha(t.textMid, alpha));
        canvas.drawLine(closeRect.left + closeRect.width() * 0.35f, closeRect.top + closeRect.height() * 0.35f, closeRect.right - closeRect.width() * 0.35f, closeRect.bottom - closeRect.height() * 0.35f, paint);
        canvas.drawLine(closeRect.right - closeRect.width() * 0.35f, closeRect.top + closeRect.height() * 0.35f, closeRect.left + closeRect.width() * 0.35f, closeRect.bottom - closeRect.height() * 0.35f, paint);

        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(24));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, welcomeVisible ? "Welcome to use Linux" : getSectionLabel(selectedSection), featureListRect.left, searchRect.bottom + dp(49), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(13) * globalTextScale * featureTextScale);
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, welcomeVisible ? (chineseMode ? "切换任意板块后此信息界面会消失" : "Switch any section to enter the panel") : (chineseMode ? "By bacon and ChatGPT5.5 Thinking" : "By bacon and ChatGPT5.5 Thinking"), featureListRect.left, searchRect.bottom + dp(74), textPaint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.softBg, alpha));
        canvas.drawRoundRect(badgeRect, dp(14), dp(14), paint);
        textPaint.setTextSize(dp(12));
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawCenteredText(canvas, chineseMode ? "横屏" : "Landscape", badgeRect, textPaint);
    }

    private void drawFeatureList(Canvas canvas, int groupAlpha) {
        if (welcomeVisible) {
            drawWelcomeInfo(canvas, groupAlpha);
            return;
        }
        Section section = sections[selectedSection];
        ThemePalette t = theme();
        canvas.save();
        canvas.clipRect(featureListRect);
        for (int i = 0; i < section.features.length; i++) {
            Feature f = section.features[i];
            if (f.cardRect.bottom < featureListRect.top - dp(30) || f.cardRect.top > featureListRect.bottom + dp(30)) continue;
            float stagger = stagger(contentProgress, i, 0.065f);
            int alpha = multiplyAlpha(groupAlpha, (int) (255 * stagger));
            float scale = 0.985f + 0.015f * stagger - f.press * 0.018f;
            float tx = (1f - stagger) * dp(20);
            canvas.save();
            canvas.translate(tx, 0);
            canvas.scale(scale, scale, f.cardRect.centerX(), f.cardRect.top + f.mainRect.height() / 2f);
            drawFeatureCard(canvas, f, i, alpha);
            canvas.restore();
        }
        canvas.restore();
    }


    private void drawWelcomeInfo(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        rect.set(welcomeCardRect);
        rect.offset(0, dp(5));
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0x0E000000, alpha));
        canvas.drawRoundRect(rect, dp(26), dp(26), paint);
        paint.setColor(applyAlpha(t.panelBg, alpha));
        canvas.drawRoundRect(welcomeCardRect, dp(26), dp(26), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(welcomeCardRect, dp(26), dp(26), paint);

        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(26));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, "Welcome to use Linux", welcomeCardRect.left + dp(28), welcomeCardRect.top + dp(48), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(14));
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, chineseMode ? "这是初始信息界面，点击左侧任意板块后会永久隐藏。" : "This is the initial info screen. Tap any section to hide it.", welcomeCardRect.left + dp(28), welcomeCardRect.top + dp(82), textPaint);
        drawText(canvas, chineseMode ? "当前支持主题、滚动、悬浮球、动画、音乐悬浮窗和字体调试。" : "Theme, scroll, floating ball, animation, music window and font debugging are ready.", welcomeCardRect.left + dp(28), welcomeCardRect.top + dp(112), textPaint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.activeSoft, alpha));
        tempRect.set(welcomeCardRect.left + dp(28), welcomeCardRect.bottom - dp(48), welcomeCardRect.left + dp(198), welcomeCardRect.bottom - dp(16));
        canvas.drawRoundRect(tempRect, dp(14), dp(14), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(12));
        textPaint.setColor(applyAlpha(t.accent, alpha));
        drawCenteredText(canvas, chineseMode ? "选择板块开始" : "Select a section", tempRect, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawFeatureCard(Canvas canvas, Feature f, int order, int alpha) {
        ThemePalette t = theme();
        float cardR = dp(23) * globalCornerScale * featureCornerScale;
        rect.set(f.cardRect);
        rect.offset(0, dp(4));
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0x0E000000, alpha));
        canvas.drawRoundRect(rect, cardR, cardR, paint);
        if (featureGlowEnabled && featureGlowStrength > 0.01f && !hotInteractionFrame) drawShapeGlow(canvas, f.cardRect, cardR, false, featureGlowStrength * globalGlowScale, false, null, 0xFF000000, alpha, true, 1.0f, 0);
        if (isGlassTheme()) {
            drawGlassCard(canvas, f.cardRect, cardR, alpha);
        } else {
            int cardBodyAlpha = alpha;
            int cardBodyColor = blend(t.panelBg, t.softBg, f.press * 0.75f);
            paint.setColor(applyAlpha(cardBodyColor, cardBodyAlpha));
            canvas.drawRoundRect(f.cardRect, cardR, cardR, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1) * globalStrokeScale * featureStrokeScale);
            if (isRgbTheme()) {
                paint.setShader(makeMovingGradient(f.cardRect, rgbThemeColors(), t.accent, alpha, 1.0f));
                canvas.drawRoundRect(f.cardRect, cardR, cardR, paint);
                paint.setShader(null);
            } else {
                paint.setColor(applyAlpha(blend(t.stroke, t.accent, f.press * 0.20f), alpha));
                canvas.drawRoundRect(f.cardRect, cardR, cardR, paint);
            }
        }

        drawFeatureMain(canvas, f, order, alpha);
        if (f.settings != null && f.debugProgress > 0.002f) drawFeatureSettings(canvas, f, alpha);
    }

    private void drawFeatureMain(Canvas canvas, Feature f, int order, int alpha) {
        ThemePalette t = theme();
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(13));
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, getFeatureName(f), f.mainRect.left + dp(24), f.mainRect.top + dp(30), textPaint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(18) * globalTextScale * featureTextScale);
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, getFeatureTitle(f), f.mainRect.left + dp(24), f.mainRect.top + dp(58), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(12));
        textPaint.setColor(applyAlpha(t.textLight, alpha));
        drawText(canvas, getFeatureHint(f), f.mainRect.left + dp(24), f.mainRect.top + dp(80), textPaint);

        if (f.type == CONTROL_SWITCH) drawSwitch(canvas, f, f.controlRect, alpha);
        else if (f.type == CONTROL_SELECT) drawSelect(canvas, f, f.controlRect, alpha);
        else if (f.type == CONTROL_GROUP) drawGroupPill(canvas, f, f.controlRect, alpha);
        else if (f.type == CONTROL_SLIDER) drawSlider(canvas, f, f.controlRect, alpha, false);
        else if (f.type == CONTROL_ACTION) drawActionButton(canvas, f, f.controlRect, alpha);
    }

    private void drawFeatureSettings(Canvas canvas, Feature host, int groupAlpha) {
        float p = easeValue(host.debugProgress);
        int alpha = multiplyAlpha(groupAlpha, (int) (255 * p));
        for (int i = 0; i < host.settings.length; i++) {
            Feature s = host.settings[i];
            if (s.cardRect.height() <= 0f) continue;
            float yMove = (1f - p) * dp(10);
            canvas.save();
            canvas.translate(0, yMove);
            drawSettingRow(canvas, s, alpha);
            canvas.restore();
        }
    }

    private void drawSettingRow(Canvas canvas, Feature s, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.softBg, (int) (alpha * 0.74f)));
        canvas.drawRoundRect(s.cardRect, dp(15), dp(15), paint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dp(12) * globalTextScale * featureTextScale);
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, getFeatureName(s), s.cardRect.left + dp(14), s.cardRect.top + dp(20), textPaint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(14) * globalTextScale * featureTextScale);
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, getFeatureTitle(s), s.cardRect.left + dp(14), s.cardRect.bottom - dp(13), textPaint);
        textPaint.setFakeBoldText(false);

        if (s.type == CONTROL_SWITCH) drawSwitch(canvas, s, s.controlRect, alpha);
        else if (s.type == CONTROL_SLIDER) drawSlider(canvas, s, s.controlRect, alpha, true);
        else if (s.type == CONTROL_SELECT) drawSelect(canvas, s, s.controlRect, alpha);
        else if (s.type == CONTROL_COLOR) drawColorButton(canvas, s, s.controlRect, alpha);
        else if (s.type == CONTROL_ACTION) drawActionButton(canvas, s, s.controlRect, alpha);
    }

    private void drawActionButton(Canvas canvas, Feature f, RectF b, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.accent, alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(blend(t.stroke, t.panelBg, 0.35f), alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(12));
        textPaint.setColor(applyAlpha(t.panelBg, alpha));
        drawCenteredText(canvas, getActionButtonText(f), b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawColorButton(Canvas canvas, Feature f, RectF b, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        if (isColorFeatureGradient(f) && getColorFeatureGradientColors(f) != null && getColorFeatureGradientColors(f).length > 1) {
            Shader old = paint.getShader();
            if (f.gradientStyle == 1) {
                paint.setShader(null);
                paint.setColor(animatedClassicColorAtTime(getColorFeatureGradientColors(f), getColorFeatureValue(f), alpha, f.gradientSpeed, featureGradientFrameTimeMs(f)));
            } else {
                paint.setShader(makeMovingGradientAtTime(b, getColorFeatureGradientColors(f), getColorFeatureValue(f), alpha, f.gradientSpeed, featureGradientFrameTimeMs(f)));
            }
            canvas.drawRoundRect(b, dp(15), dp(15), paint);
            paint.setShader(old);
        } else {
            paint.setShader(null);
            paint.setColor(applyAlpha(getColorFeatureValue(f), alpha));
            canvas.drawRoundRect(b, dp(15), dp(15), paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(11));
        textPaint.setColor(applyAlpha(contrastTextColor(getColorFeatureValue(f)), alpha));
        drawCenteredText(canvas, colorLabel(f), b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawSwitch(Canvas canvas, Feature f, RectF b, int alpha) {
        ThemePalette t = theme();
        float v = easeValue(f.anim);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(f.enabled ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, b.height() / 2f, b.height() / 2f, paint);
        float knob = b.height() - dp(6);
        float x = b.left + dp(3) + (b.width() - knob - dp(6)) * v;
        rect.set(x, b.top + dp(3), x + knob, b.bottom - dp(3));
        tempRect.set(rect);
        tempRect.offset(0, dp(2));
        paint.setColor(applyAlpha(0x18000000, alpha));
        canvas.drawOval(tempRect, paint);
        paint.setColor(applyAlpha(t.panelBg, alpha));
        canvas.drawOval(rect, paint);
    }

    private void drawSelect(Canvas canvas, Feature f, RectF b, int alpha) {
        ThemePalette t = theme();
        float p = f.role == Role.THEME ? themeDropdownProgress : 0f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(blend(t.softBg, t.activeSoft, p), alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(blend(t.stroke, t.accent, p * 0.6f), alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(13));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, getOptionText(f), b.left + dp(14), b.centerY() + dp(5), textPaint);
        textPaint.setFakeBoldText(false);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.8f));
        paint.setColor(applyAlpha(t.textMid, alpha));
        float cx = b.right - dp(18);
        float cy = b.centerY();
        canvas.drawLine(cx - dp(4), cy - dp(2), cx, cy + dp(3), paint);
        canvas.drawLine(cx, cy + dp(3), cx + dp(4), cy - dp(2), paint);
    }

    private void drawGroupPill(Canvas canvas, Feature f, RectF b, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(f.debugOpen ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(f.debugOpen ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dp(15), dp(15), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dp(12));
        textPaint.setColor(applyAlpha(f.debugOpen ? t.accent : t.textMid, alpha));
        drawCenteredText(canvas, f.debugOpen ? (chineseMode ? "收起" : "Hide") : (chineseMode ? "调试" : "Settings"), b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawSlider(Canvas canvas, Feature f, RectF b, int alpha, boolean setting) {
        ThemePalette t = theme();
        float trackY = b.centerY();
        if (setting && f.role == Role.HINT_DURATION) trackY = b.centerY() - dp(3);
        if (setting && isValueBelowSlider(f)) trackY = b.top + b.height() * 0.42f;
        Paint.Cap old = paint.getStrokeCap();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(5.2f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawLine(b.left, trackY, b.right, trackY, paint);
        paint.setColor(applyAlpha(t.accent, alpha));
        float fillX = b.left + b.width() * f.displayValue;
        canvas.drawLine(b.left, trackY, fillX, trackY, paint);
        paint.setStrokeCap(old);
        paint.setStyle(Paint.Style.FILL);
        tempRect.set(fillX - dp(10), trackY - dp(10), fillX + dp(10), trackY + dp(10));
        rect.set(tempRect);
        rect.offset(0, dp(2));
        paint.setColor(applyAlpha(0x18000000, alpha));
        canvas.drawOval(rect, paint);
        paint.setColor(applyAlpha(t.panelBg, alpha));
        canvas.drawOval(tempRect, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.5f));
        paint.setColor(applyAlpha(t.accent, alpha));
        canvas.drawOval(tempRect, paint);

        String v = getValueText(f);
        if (v.length() > 0) {
            textPaint.setFakeBoldText(false);
            textPaint.setTextSize(dp(11));
            textPaint.setColor(applyAlpha(t.textMid, alpha));
            if (setting || isValueBelowSlider(f)) {
                drawCenteredText(canvas, v, new RectF(b.left, trackY + dp(11), b.right, b.bottom), textPaint);
            } else {
                canvas.drawText(v, b.right + dp(10), trackY + dp(4), textPaint);
            }
        }
    }

    private boolean isValueBelowSlider(Feature f) {
        return f.role == Role.BALL_SIZE || f.role == Role.BALL_OPACITY || f.role == Role.ANIM_PANEL || f.role == Role.ANIM_SECTION || f.role == Role.ANIM_DEBUG || f.role == Role.HINT_GLOW_STRENGTH || f.role == Role.SHORTCUT_BG_SIZE || f.role == Role.SHORTCUT_BORDER_SIZE || f.role == Role.SHORTCUT_FONT_SIZE || f.role == Role.SHORTCUT_GLOW_STRENGTH || f.role == Role.ARRAYLIST_BAR_LENGTH || f.role == Role.ARRAYLIST_BAR_WIDTH || f.role == Role.ARRAYLIST_TEXT_SIZE || f.role == Role.ARRAYLIST_GLOW_STRENGTH || f.role == Role.GLOBAL_RESOLUTION || f.role == Role.GLOBAL_PERFORMANCE;
    }

    private void drawThemePopup(Canvas canvas, int panelAlpha) {
        Feature theme = getThemeFeature();
        if (theme == null) return;
        RectF c = theme.controlRect;
        float p = easeValue(themeDropdownProgress);
        if (p <= 0f) return;
        ThemePalette t = theme();
        float itemH = dp(38);
        float gap = dp(5);
        float fullH = dp(10) + themes.length * itemH + (themes.length - 1) * gap + dp(10);
        float h = fullH * p;
        float width = Math.max(c.width(), dp(170));
        float left = c.right - width;
        float top = c.bottom + dp(8);
        if (top + h > featureListRect.bottom) top = c.top - dp(8) - h;
        themePopupRect.set(left, top, left + width, top + h);

        paint.setStyle(Paint.Style.FILL);
        rect.set(themePopupRect);
        rect.offset(0, dp(5));
        paint.setColor(applyAlpha(0x15000000, panelAlpha));
        canvas.drawRoundRect(rect, dp(17), dp(17), paint);
        paint.setColor(applyAlpha(t.panelBg, panelAlpha));
        canvas.drawRoundRect(themePopupRect, dp(17), dp(17), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(applyAlpha(t.stroke, panelAlpha));
        canvas.drawRoundRect(themePopupRect, dp(17), dp(17), paint);

        canvas.save();
        canvas.clipRect(themePopupRect);
        for (int i = 0; i < themes.length; i++) {
            float y = themePopupRect.top + dp(10) + i * (itemH + gap);
            RectF row = new RectF(themePopupRect.left + dp(8), y, themePopupRect.right - dp(8), y + itemH);
            if (i == themeIndex) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(applyAlpha(t.activeSoft, panelAlpha));
                canvas.drawRoundRect(row, dp(13), dp(13), paint);
            }
            textPaint.setFakeBoldText(i == themeIndex);
            textPaint.setTextSize(dp(13));
            textPaint.setColor(applyAlpha(i == themeIndex ? t.accent : t.textDark, panelAlpha));
            drawText(canvas, chineseMode ? themes[i].nameCn : themes[i].name, row.left + dp(12), row.centerY() + dp(5), textPaint);
        }
        canvas.restore();
        textPaint.setFakeBoldText(false);
    }

    private void drawScrollBar(Canvas canvas, int alpha) {
        if (!layoutScrollBarVisible || welcomeVisible || maxScrollY <= 1f) return;
        long now = SystemClock.uptimeMillis();
        if (!draggingScroll && now > scrollBarVisibleUntil) return;
        ThemePalette t = theme();
        float ratio = featureListRect.height() / (featureListRect.height() + maxScrollY);
        float h = Math.max(dp(28), featureListRect.height() * ratio);
        float track = featureListRect.height() - h;
        float y = featureListRect.top + (maxScrollY == 0f ? 0f : track * (scrollY / maxScrollY));
        float w = dp(3 + 8 * scrollBarWidth);
        rect.set(featureListRect.right - w, y, featureListRect.right, y + h);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.accent, (int) (alpha * scrollBarOpacity)));
        canvas.drawRoundRect(rect, w / 2f, w / 2f, paint);
    }

    private void drawFeatureShortcuts(Canvas canvas) {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        for (int i = 0; i < SECTION_COUNT; i++) {
            Section section = sections[i];
            if (section == null || section.features == null) continue;
            for (int j = 0; j < section.features.length; j++) {
                drawShortcutForFeature(canvas, section.features[j], j);
            }
        }
    }

    private void drawShortcutForFeature(Canvas canvas, Feature f, int order) {
        if (f == null || !f.shortcutEnabled || f.type != CONTROL_SWITCH) return;
        ensureShortcutPosition(f);
        layoutShortcutRect(f);
        RectF b = f.shortcutRect;
        boolean circle = shortcutShape == 1;
        float radius = circle ? b.width() / 2f : Math.min(dpRaw(18), b.height() / 2f);
        int bgColor = f.enabled ? shortcutOnBgColor : shortcutOffBgColor;
        int textColor = f.enabled ? shortcutOnTextColor : shortcutOffTextColor;
        int bgAlpha = clampAlpha((int) (255 * shortcutBgOpacity));
        int borderAlpha = clampAlpha((int) (255 * shortcutBorderOpacity));
        float pressScale = 1f - f.shortcutPress * 0.035f;
        canvas.save();
        canvas.scale(pressScale, pressScale, b.centerX(), b.centerY());
        if (shortcutGlowEnabled) drawShapeGlowDelayed(canvas, b, radius, circle, shortcutGlowStrength, shortcutGlowGradient, shortcutGlowColors, shortcutGlowColor, borderAlpha, true, shortcutGlowGradientSpeed, shortcutGlowGradientStyle, shortcutGlowGradientDelay);
        tempRect.set(b);
        tempRect.offset(0, dpRaw(3));
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(0x16000000, bgAlpha));
        if (circle) canvas.drawOval(tempRect, paint); else canvas.drawRoundRect(tempRect, radius, radius, paint);
        paint.setColor(applyAlpha(bgColor, bgAlpha));
        if (circle) canvas.drawOval(b, paint); else canvas.drawRoundRect(b, radius, radius, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(dpRaw(0.8f), b.height() * 0.045f * shortcutBorderSizeFactor));
        if (shortcutBorderGradient && shortcutBorderColors != null && shortcutBorderColors.length > 1) {
            Shader old = paint.getShader();
            if (shortcutBorderGradientStyle == 1) {
                paint.setShader(null);
                paint.setColor(animatedClassicColor(shortcutBorderColors, shortcutBorderColor, borderAlpha, shortcutBorderGradientSpeed));
            } else {
                paint.setShader(makeShortcutGradient(b, borderAlpha));
            }
            if (circle) canvas.drawOval(b, paint); else canvas.drawRoundRect(b, radius, radius, paint);
            paint.setShader(old);
        } else {
            paint.setShader(null);
            paint.setColor(applyAlpha(shortcutBorderColor, borderAlpha));
            if (circle) canvas.drawOval(b, paint); else canvas.drawRoundRect(b, radius, radius, paint);
        }
        textPaint.setFakeBoldText(true);
        float shortcutTextPx = dpRaw(13.5f) * shortcutTextSizeFactor;
        float shortcutMaxPx = Math.max(dpRaw(9f), b.height() * 0.58f);
        textPaint.setTextSize(Math.min(shortcutTextPx, shortcutMaxPx));
        textPaint.setColor(applyAlpha(textColor, 255));
        String label = getFeatureTitle(f);
        float pad = circle ? b.width() * 0.18f : dpRaw(13);
        RectF clip = new RectF(b.left + pad, b.top + dpRaw(2), b.right - pad, b.bottom - dpRaw(2));
        String safe = ellipsize(label, textPaint, Math.max(1f, clip.width()));
        canvas.save();
        canvas.clipRect(clip);
        boolean oldThemeGradient = themeTextGradientEnabled;
        themeTextGradientEnabled = false;
        drawCenteredText(canvas, safe, b, textPaint);
        themeTextGradientEnabled = oldThemeGradient;
        canvas.restore();
        textPaint.setFakeBoldText(false);
        canvas.restore();
    }

    private Shader makeShortcutGradient(RectF b, int alpha) {
        return makeMovingGradientAtTime(b, shortcutBorderColors, shortcutBorderColor, alpha, shortcutBorderGradientSpeed, gradientFrameTimeMs(gradientDelayMs(shortcutBorderGradientDelay)));
    }

    private long gradientFrameTimeMs() {
        return gradientFrameTimeMs(EXPENSIVE_EFFECT_INTERVAL_MS);
    }

    private long gradientFrameTimeMs(long intervalMs) {
        long now = SystemClock.uptimeMillis();
        if (fpsBoostMode) {
            long step = Math.max(16L, intervalMs);
            now = (now / step) * step;
        }
        return now;
    }

    private long arrayListGradientFrameTimeMs() {
        return gradientFrameTimeMs(50L);
    }

    private long gradientDelayMs(float delay) {
        return 50L + (long)(clamp01(delay) * 450L);
    }

    private long featureGradientFrameTimeMs(Feature f) {
        return gradientFrameTimeMs(gradientDelayMs(f == null ? 1.0f : f.gradientDelay));
    }

    private int animatedClassicColor(int[] colors, int fallback, int alpha, float speed) {
        long frameTime = gradientFrameOverrideMs >= 0L ? gradientFrameOverrideMs : gradientFrameTimeMs();
        return animatedClassicColorAtTime(colors, fallback, alpha, speed, frameTime);
    }

    private int animatedClassicColorAtTime(int[] colors, int fallback, int alpha, float speed, long frameTimeMs) {
        if (colors == null || colors.length == 0) return applyAlpha(fallback, alpha);
        if (colors.length == 1) return applyAlpha(colors[0], alpha);
        float safeSpeed = clamp(speed, 1.0f, 6.0f);
        float phase = NativeUiOptimizer.gradientPhase(frameTimeMs, 0.20f * safeSpeed, 1.0f);
        float u = (phase / (float)(Math.PI * 2.0));
        u = u - (float)Math.floor(u);
        float scaled = u * colors.length;
        int i0 = ((int)Math.floor(scaled)) % colors.length;
        int i1 = (i0 + 1) % colors.length;
        float t = scaled - (float)Math.floor(scaled);
        return applyAlpha(blend(colors[i0], colors[i1], t), alpha);
    }

    private Shader makeMovingGradient(RectF b, int[] colors, int fallback, int alpha, float speed) {
        long frameTime = gradientFrameOverrideMs >= 0L ? gradientFrameOverrideMs : gradientFrameTimeMs();
        return makeMovingGradientAtTime(b, colors, fallback, alpha, speed, frameTime);
    }

    private Shader makeMovingGradientAtTime(RectF b, int[] colors, int fallback, int alpha, float speed, long frameTimeMs) {
        if (colors == null || colors.length == 0) colors = new int[]{fallback, fallback};
        if (colors.length == 1) colors = new int[]{colors[0], colors[0]};
        int[] alphaColors = new int[colors.length];
        for (int i = 0; i < colors.length; i++) alphaColors[i] = applyAlpha(colors[i], alpha);
        float boost = isRgbTheme() ? 5.0f : 1.0f;
        float phase = NativeUiOptimizer.gradientPhase(frameTimeMs, clamp(speed, 1.0f, 6.0f), boost);
        float shift = (float) Math.sin(phase) * Math.max(1f, b.width());
        return new LinearGradient(b.left + shift, b.top, b.right + shift, b.bottom, alphaColors, null, Shader.TileMode.MIRROR);
    }

    private void drawShapeGlow(Canvas canvas, RectF bounds, float radius, boolean circle, float strength, boolean gradient, int[] colors, int fallback, int alpha, boolean rawDp) {
        drawShapeGlow(canvas, bounds, radius, circle, strength, gradient, colors, fallback, alpha, rawDp, 1.0f, 0);
    }

    private void drawShapeGlow(Canvas canvas, RectF bounds, float radius, boolean circle, float strength, boolean gradient, int[] colors, int fallback, int alpha, boolean rawDp, float gradientSpeed, int gradientStyle) {
        drawShapeGlowDelayed(canvas, bounds, radius, circle, strength, gradient, colors, fallback, alpha, rawDp, gradientSpeed, gradientStyle, 1.0f);
    }

    private void drawShapeGlowDelayed(Canvas canvas, RectF bounds, float radius, boolean circle, float strength, boolean gradient, int[] colors, int fallback, int alpha, boolean rawDp, float gradientSpeed, int gradientStyle, float gradientDelay) {
        if (strength <= 0.01f || alpha <= 0 || bounds == null || bounds.isEmpty()) return;

        // Restored backup glow: a single blurred mask with cached BlurMaskFilter.
        // This gives a natural soft halo without the hard/incorrect gradient artifacts from the FPS layer.
        float safeStrength = Math.min(1f, Math.max(0f, strength * globalGlowScale)) * (0.35f + performanceQuality * 0.65f);
        float unit = rawDp ? dpRaw(1) : dp(1);
        if (unit < 1f) unit = 1f;
        float blur = unit * (8f + (14f + 42f * safeStrength) * performanceQuality);
        float spread = unit * (2.2f + 8.0f * safeStrength);
        // Lower transparency / stronger visible glow while keeping the restored soft blurred halo.
        int glowAlpha = clampAlpha((int) (alpha * (0.330f + 0.620f * safeStrength)));
        if (hotInteractionFrame) glowAlpha = (int)(glowAlpha * 0.86f);
        if (glowAlpha <= 0) return;

        glowRectCache.set(bounds.left - spread, bounds.top - spread, bounds.right + spread, bounds.bottom + spread);
        glowPaint.reset();
        glowPaint.setAntiAlias(true);
        glowPaint.setDither(true);
        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeCap(Paint.Cap.ROUND);
        glowPaint.setStrokeJoin(Paint.Join.ROUND);
        glowPaint.setStrokeWidth(Math.max(unit * 2.5f, unit * (4.0f + safeStrength * 5.0f)));
        int blurKey = Math.max(1, Math.round(blur * 10f));
        BlurMaskFilter mask = glowMaskCache.get(blurKey);
        if (mask == null) {
            if (glowMaskCache.size() > 24) glowMaskCache.clear();
            mask = new BlurMaskFilter(blurKey / 10f, BlurMaskFilter.Blur.NORMAL);
            glowMaskCache.put(blurKey, mask);
        }
        glowPaint.setMaskFilter(mask);
        if (gradient && colors != null && colors.length > 1) {
            if (gradientStyle == 1) {
                glowPaint.setShader(null);
                glowPaint.setColor(animatedClassicColorAtTime(colors, fallback, glowAlpha, gradientSpeed, gradientFrameTimeMs(gradientDelayMs(gradientDelay))));
            } else {
                glowPaint.setShader(makeMovingGradientAtTime(glowRectCache, colors, fallback, glowAlpha, gradientSpeed, gradientFrameTimeMs(gradientDelayMs(gradientDelay))));
            }
        } else {
            glowPaint.setShader(null);
            glowPaint.setColor(applyAlpha(fallback, glowAlpha));
        }
        if (circle) canvas.drawOval(glowRectCache, glowPaint);
        else canvas.drawRoundRect(glowRectCache, radius + spread, radius + spread, glowPaint);
        glowPaint.setShader(null);
        glowPaint.setMaskFilter(null);
    }

    private void layoutShortcutRect(Feature f) {
        String label = getFeatureTitle(f);
        float layoutTextSize = dpRaw(13.5f) * shortcutTextSizeFactor;
        textPaint.setTextSize(layoutTextSize);
        textPaint.setFakeBoldText(true);
        float textW = textPaint.measureText(label);
        textPaint.setFakeBoldText(false);
        float sizeScale = shortcutSizeFactor;
        float h = Math.max(dpRaw(38), Math.min(dpRaw(54), getHeight() * 0.065f)) * sizeScale;
        h = Math.max(h, layoutTextSize * 2.05f);
        float w;
        if (shortcutShape == 1) {
            w = Math.max(h, textW + dpRaw(28) * sizeScale);
            w = Math.min(w, Math.max(dpRaw(64), getWidth() - dpRaw(16)));
            h = w;
        } else {
            w = Math.max(dpRaw(92) * sizeScale, textW + dpRaw(34) * sizeScale);
            w = Math.min(w, Math.max(dpRaw(120), getWidth() * 0.50f));
        }
        if (f.shortcutX + w > getWidth() - dpRaw(8)) f.shortcutX = getWidth() - w - dpRaw(8);
        if (f.shortcutY + h > getHeight() - dpRaw(8)) f.shortcutY = getHeight() - h - dpRaw(8);
        if (f.shortcutX < dpRaw(8)) f.shortcutX = dpRaw(8);
        if (f.shortcutY < dpRaw(8)) f.shortcutY = dpRaw(8);
        f.shortcutRect.set(f.shortcutX, f.shortcutY, f.shortcutX + w, f.shortcutY + h);
    }

    private void ensureShortcutPosition(Feature f) {
        if (f == null || f.shortcutPositionReady || getWidth() <= 0 || getHeight() <= 0) return;
        int index = shortcutIndex(f);
        float startX = dpRaw(22);
        float startY = getHeight() * 0.20f;
        float row = Math.max(dpRaw(48), getHeight() * 0.075f) * Math.max(1f, shortcutSizeFactor * 0.86f);
        f.shortcutX = startX;
        f.shortcutY = startY + index * row;
        f.shortcutPositionReady = true;
        layoutShortcutRect(f);
    }

    private int shortcutIndex(Feature target) {
        int index = 0;
        for (int i = 0; i < SECTION_COUNT; i++) {
            Section section = sections[i];
            if (section == null || section.features == null) continue;
            for (int j = 0; j < section.features.length; j++) {
                Feature f = section.features[j];
                if (f == target) return index;
                if (f != null && f.type == CONTROL_SWITCH) index++;
            }
        }
        return index;
    }

    private Feature hitAnyShortcut(float x, float y) {
        for (int i = SECTION_COUNT - 1; i >= 0; i--) {
            Section section = sections[i];
            if (section == null || section.features == null) continue;
            for (int j = section.features.length - 1; j >= 0; j--) {
                Feature f = section.features[j];
                if (f == null || !f.shortcutEnabled || f.type != CONTROL_SWITCH) continue;
                ensureShortcutPosition(f);
                layoutShortcutRect(f);
                if (f.shortcutRect.contains(x, y)) return f;
            }
        }
        return null;
    }

    private boolean handleShortcutTouch(MotionEvent event, float x, float y) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                Feature hit = hitAnyShortcut(x, y);
                if (hit == null) return false;
                shortcutDownFeature = hit;
                shortcutDragging = false;
                shortcutDownX = x;
                shortcutDownY = y;
                shortcutStartX = hit.shortcutX;
                shortcutStartY = hit.shortcutY;
                hit.shortcutPress = 1f;
                requestFrame();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (shortcutDownFeature == null) return false;
                float dx = x - shortcutDownX;
                float dy = y - shortcutDownY;
                if (Math.abs(dx) > dpRaw(7) || Math.abs(dy) > dpRaw(7)) shortcutDragging = true;
                if (shortcutDragging) {
                    shortcutDownFeature.shortcutX = shortcutStartX + dx;
                    shortcutDownFeature.shortcutY = shortcutStartY + dy;
                    layoutShortcutRect(shortcutDownFeature);
                    requestFrame();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (shortcutDownFeature == null) return false;
                Feature f = shortcutDownFeature;
                f.shortcutPress = 0f;
                if (!shortcutDragging && f.shortcutRect.contains(x, y)) toggleSwitch(f);
                shortcutDownFeature = null;
                shortcutDragging = false;
                requestFrame();
                return true;
        }
        return false;
    }

    private void drawFloatingBall(Canvas canvas) {
        if (ballSize <= 0f) return;

        float drawAlphaScale = 1f;

        if (transitionActive) {
            if (transitionMode == TRANSITION_CLOSE) {
                // During close transition the ball fades back in while particles
                // arrive at different speeds, so the ending feels continuous.
                drawAlphaScale = naturalEase(clamp01((transitionProgress - 0.18f) / 0.78f));
                if (drawAlphaScale <= 0.01f) return;
            } else {
                return;
            }
        } else if (panelVisible && panelProgress > 0.02f) {
            return;
        }

        int alpha = (int) (255 * ballOpacity * drawAlphaScale);
        if (alpha <= 0) return;

        float cx = ballX + ballSize / 2f;
        float cy = ballY + ballSize / 2f;
        canvas.save();
        float transitionScale = transitionActive && transitionMode == TRANSITION_CLOSE
                ? (0.84f + 0.16f * drawAlphaScale)
                : 1f;
        canvas.scale(ballScale * transitionScale, ballScale * transitionScale, cx, cy);
        RectF ballRect = new RectF(cx - ballSize * 0.44f, cy - ballSize * 0.44f, cx + ballSize * 0.44f, cy + ballSize * 0.44f);
        if (isRgbTheme()) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(makeMovingGradient(ballRect, rgbThemeColors(), theme().accent, alpha, 1.2f));
            canvas.drawCircle(cx, cy, ballSize * 0.44f, paint);
            paint.setShader(null);
            drawRgbPenguinIcon(canvas, cx, cy, ballSize * 0.48f, alpha, false);
        } else if (isGlassTheme()) {
            drawShapeGlow(canvas, ballRect, ballSize * 0.44f, true, 0.35f, false, null, theme().accent, alpha, true);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(theme().panelBg, (int)(alpha * 0.70f)));
            canvas.drawCircle(cx, cy, ballSize * 0.44f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, ballSize * 0.018f));
            paint.setColor(applyAlpha(0x88FFFFFF, alpha));
            canvas.drawCircle(cx, cy, ballSize * 0.44f, paint);
            drawMinimalPenguinIcon(canvas, cx, cy, ballSize * 0.48f, alpha, true);
        } else {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(0x16000000, alpha));
            canvas.drawCircle(cx, cy + ballSize * 0.055f, ballSize * 0.44f, paint);
            paint.setColor(applyAlpha(theme().panelBg, alpha));
            canvas.drawCircle(cx, cy, ballSize * 0.44f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, ballSize * 0.018f));
            paint.setColor(applyAlpha(theme().stroke, alpha));
            canvas.drawCircle(cx, cy, ballSize * 0.44f, paint);
            drawMinimalPenguinIcon(canvas, cx, cy, ballSize * 0.48f, alpha, false);
        }
        canvas.restore();
    }

    private void drawBallIcon(Canvas canvas, float cx, float cy, float size, int alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0xFF111827, alpha));
        rect.set(cx - size * 0.45f, cy - size * 0.40f, cx + size * 0.45f, cy + size * 0.48f);
        canvas.drawOval(rect, paint);
        paint.setColor(applyAlpha(0xFFFFFFFF, alpha));
        rect.set(cx - size * 0.28f, cy - size * 0.08f, cx + size * 0.28f, cy + size * 0.52f);
        canvas.drawOval(rect, paint);
        paint.setColor(applyAlpha(0xFFFFFFFF, alpha));
        canvas.drawCircle(cx - size * 0.15f, cy - size * 0.25f, size * 0.055f, paint);
        canvas.drawCircle(cx + size * 0.15f, cy - size * 0.25f, size * 0.055f, paint);
        paint.setColor(applyAlpha(0xFFF59E0B, alpha));
        canvas.drawCircle(cx, cy - size * 0.08f, size * 0.095f, paint);
    }


    private float musicWindowWidth() {
        float w = Math.max(dpRaw(390), Math.min(getWidth() * 0.44f, dpRaw(540))) * musicWindowScale;
        if (w > getWidth() - dpRaw(24)) w = getWidth() - dpRaw(24);
        return w;
    }

    private float musicWindowHeight() {
        float h = Math.max(dpRaw(288), Math.min(getHeight() * 0.74f, dpRaw(420))) * musicWindowScale;
        if (h > getHeight() - dpRaw(24)) h = getHeight() - dpRaw(24);
        return h;
    }

    private void drawMusicWindow(Canvas canvas) {
        if (!musicWindowEnabled) return;
        if (!musicPositionReady) {
            musicX = getWidth() - musicWindowWidth() - dpRaw(28);
            musicY = getHeight() * 0.16f;
            musicPositionReady = true;
            clampMusic();
        }
        ThemePalette t = theme();
        float w = musicWindowWidth();
        float h = musicWindowHeight();
        musicRect.set(musicX, musicY, musicX + w, musicY + h);
        int alpha = 238;

        drawGlassCard(canvas, musicRect, dpRaw(22), alpha);

        float album = Math.min(dpRaw(62), h * 0.18f);
        rect.set(musicRect.left + dpRaw(18), musicRect.top + dpRaw(16), musicRect.left + dpRaw(18) + album, musicRect.top + dpRaw(16) + album);
        if (isRgbTheme()) drawRgbPenguinIcon(canvas, rect.centerX(), rect.centerY(), album * 0.86f, alpha, true);
        else drawMinimalPenguinIcon(canvas, rect.centerX(), rect.centerY(), album * 0.86f, alpha, isGlassTheme());

        float titleX = rect.right + dpRaw(14);
        float titleW = musicRect.right - titleX - dpRaw(90);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(16));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, ellipsize(musicTitle, textPaint, titleW), titleX, musicRect.top + dpRaw(34), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(11));
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, ellipsize(musicStatus, textPaint, titleW), titleX, musicRect.top + dpRaw(56), textPaint);

        musicLyricToggleRect.set(musicRect.right - dpRaw(78), musicRect.top + dpRaw(18), musicRect.right - dpRaw(18), musicRect.top + dpRaw(48));
        drawMusicToolButton(canvas, musicLyricToggleRect, chineseMode ? "歌词" : "Lyric", alpha, lyricOverlayEnabled);

        float tabsTop = Math.max(rect.bottom + dpRaw(12), musicRect.top + dpRaw(90));
        float tabH = dpRaw(34);
        float tabW = (musicRect.width() - dpRaw(36) - dpRaw(8)) / 2f;
        musicLocalTabRect.set(musicRect.left + dpRaw(18), tabsTop, musicRect.left + dpRaw(18) + tabW, tabsTop + tabH);
        musicNeteaseTabRect.set(musicLocalTabRect.right + dpRaw(8), tabsTop, musicRect.right - dpRaw(18), tabsTop + tabH);
        drawMusicTab(canvas, musicLocalTabRect, chineseMode ? "本地音乐" : "Local", musicPanelMode == 0, alpha);
        drawMusicTab(canvas, musicNeteaseTabRect, chineseMode ? "网易云" : "Netease", musicPanelMode == 1, alpha);

        float bodyTop = musicLocalTabRect.bottom + dpRaw(10);
        float controlsTop = musicRect.bottom - dpRaw(64);
        musicResultsRect.set(musicRect.left + dpRaw(18), bodyTop, musicRect.right - dpRaw(18), controlsTop - dpRaw(8));
        if (musicPanelMode == 0) drawLocalMusicPanel(canvas, alpha);
        else drawNeteaseMusicPanel(canvas, alpha);

        float controlsY = musicRect.bottom - dpRaw(35);
        float btn = dpRaw(30);
        musicPrevRect.set(musicRect.left + w * 0.50f - btn * 1.75f, controlsY - btn / 2f, musicRect.left + w * 0.50f - btn * 0.75f, controlsY + btn / 2f);
        musicPlayRect.set(musicRect.left + w * 0.50f - btn / 2f, controlsY - btn / 2f, musicRect.left + w * 0.50f + btn / 2f, controlsY + btn / 2f);
        musicNextRect.set(musicRect.left + w * 0.50f + btn * 0.75f, controlsY - btn / 2f, musicRect.left + w * 0.50f + btn * 1.75f, controlsY + btn / 2f);
        drawMusicButton(canvas, musicPrevRect, "‹", alpha);
        drawMusicButton(canvas, musicPlayRect, musicPlaying ? "Ⅱ" : "▶", alpha);
        drawMusicButton(canvas, musicNextRect, "›", alpha);

        float barLeft = musicRect.left + dpRaw(18);
        float barRight = musicRect.right - dpRaw(18);
        float barY = musicRect.bottom - dpRaw(11);
        float p = getMusicProgress();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(3));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawLine(barLeft, barY, barRight, barY, paint);
        paint.setColor(applyAlpha(t.accent, alpha));
        canvas.drawLine(barLeft, barY, barLeft + (barRight - barLeft) * p, barY, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);

        if (localAddDialogOpen) drawLocalAddDialog(canvas, alpha);
    }

    private void drawMusicTab(Canvas canvas, RectF b, String label, boolean active, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(active ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(b, dpRaw(14), dpRaw(14), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(active ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dpRaw(14), dpRaw(14), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(active ? t.accent : t.textMid, alpha));
        drawCenteredText(canvas, label, b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawLocalMusicPanel(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        musicAddLocalRect.set(musicResultsRect.right - dpRaw(86), musicResultsRect.top, musicResultsRect.right, musicResultsRect.top + dpRaw(32));
        drawMusicToolButton(canvas, musicAddLocalRect, chineseMode ? "+ 添加" : "+ Add", alpha, false);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(13));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, chineseMode ? "本地歌单" : "Local Playlist", musicResultsRect.left + dpRaw(4), musicResultsRect.top + dpRaw(22), textPaint);
        textPaint.setFakeBoldText(false);
        float top = musicAddLocalRect.bottom + dpRaw(8);
        float rowH = Math.max(dpRaw(34), Math.min(dpRaw(44), (musicResultsRect.bottom - top) / 5.2f));
        if (localPlaylist.size() == 0) {
            textPaint.setTextSize(dpRaw(12));
            textPaint.setColor(applyAlpha(t.textLight, alpha));
            drawText(canvas, chineseMode ? "点击 + 添加本地音乐，音乐/LRC/名称会保存。" : "Tap + Add. Music/LRC/name will be saved.", musicResultsRect.left + dpRaw(6), top + dpRaw(28), textPaint);
        }
        int count = Math.min(localPlaylist.size(), localSongRects.length);
        for (int i = 0; i < count; i++) {
            float y = top + i * (rowH + dpRaw(6));
            localSongRects[i].set(musicResultsRect.left, y, musicResultsRect.right, y + rowH);
            LocalSong song = localPlaylist.get(i);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(i == selectedLocalSongIndex ? t.activeSoft : t.softBg, alpha));
            canvas.drawRoundRect(localSongRects[i], dpRaw(12), dpRaw(12), paint);
            textPaint.setFakeBoldText(true);
            textPaint.setTextSize(dpRaw(12));
            textPaint.setColor(applyAlpha(t.textDark, alpha));
            drawText(canvas, ellipsize(song.name, textPaint, localSongRects[i].width() * 0.62f), localSongRects[i].left + dpRaw(12), localSongRects[i].centerY() - dpRaw(2), textPaint);
            textPaint.setFakeBoldText(false);
            textPaint.setTextSize(dpRaw(10) * logWindowTextScale);
            textPaint.setColor(applyAlpha(t.textMid, alpha));
            drawText(canvas, song.lrcUri.length() > 0 ? "LRC" : "No LRC", localSongRects[i].right - dpRaw(58), localSongRects[i].centerY() - dpRaw(2), textPaint);
        }
        for (int i = count; i < localSongRects.length; i++) localSongRects[i].setEmpty();
    }

    private void drawNeteaseMusicPanel(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        float searchH = dpRaw(34);
        musicSearchRect.set(musicResultsRect.left, musicResultsRect.top, musicResultsRect.right - dpRaw(52), musicResultsRect.top + searchH);
        musicSearchButtonRect.set(musicSearchRect.right + dpRaw(8), musicResultsRect.top, musicResultsRect.right, musicResultsRect.top + searchH);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(musicSearchFocused ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(musicSearchRect, dpRaw(14), dpRaw(14), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(musicSearchFocused ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(musicSearchRect, dpRaw(14), dpRaw(14), paint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(13));
        textPaint.setColor(applyAlpha(musicQuery.length() == 0 ? t.textLight : t.textDark, alpha));
        String searchText = musicQuery.length() == 0 ? (chineseMode ? "搜索音乐..." : "Search music...") : musicQuery;
        drawText(canvas, ellipsize(searchText + (musicSearchFocused ? "|" : ""), textPaint, musicSearchRect.width() - dpRaw(24)), musicSearchRect.left + dpRaw(12), musicSearchRect.centerY() + dpRaw(5), textPaint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.accent, alpha));
        canvas.drawRoundRect(musicSearchButtonRect, dpRaw(14), dpRaw(14), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(t.panelBg, alpha));
        drawCenteredText(canvas, chineseMode ? "搜索" : "Go", musicSearchButtonRect, textPaint);
        textPaint.setFakeBoldText(false);
        RectF old = new RectF(musicResultsRect);
        musicResultsRect.set(old.left, musicSearchRect.bottom + dpRaw(10), old.right, old.bottom);
        drawMusicResults(canvas, alpha);
        musicResultsRect.set(old);
    }

    private void drawLocalAddDialog(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        float w = Math.min(dpRaw(380), getWidth() - dpRaw(48));
        float h = Math.min(dpRaw(236), getHeight() - dpRaw(48));
        localAddDialogRect.set((getWidth() - w) / 2f, (getHeight() - h) / 2f, (getWidth() + w) / 2f, (getHeight() + h) / 2f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
        drawGlassCard(canvas, localAddDialogRect, dpRaw(22), 255);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(17));
        textPaint.setColor(applyAlpha(t.textDark, 255));
        drawText(canvas, chineseMode ? "添加本地音乐" : "Add Local Music", localAddDialogRect.left + dpRaw(20), localAddDialogRect.top + dpRaw(34), textPaint);
        textPaint.setFakeBoldText(false);
        float y = localAddDialogRect.top + dpRaw(56);
        localAddMusicRect.set(localAddDialogRect.left + dpRaw(20), y, localAddDialogRect.right - dpRaw(20), y + dpRaw(34));
        y += dpRaw(42);
        localAddLrcRect.set(localAddDialogRect.left + dpRaw(20), y, localAddDialogRect.right - dpRaw(20), y + dpRaw(34));
        y += dpRaw(42);
        localAddNameRect.set(localAddDialogRect.left + dpRaw(20), y, localAddDialogRect.right - dpRaw(20), y + dpRaw(34));
        localAddCancelRect.set(localAddDialogRect.left + dpRaw(20), localAddDialogRect.bottom - dpRaw(48), localAddDialogRect.left + dpRaw(120), localAddDialogRect.bottom - dpRaw(16));
        localAddSaveRect.set(localAddDialogRect.right - dpRaw(120), localAddDialogRect.bottom - dpRaw(48), localAddDialogRect.right - dpRaw(20), localAddDialogRect.bottom - dpRaw(16));
        drawMusicToolButton(canvas, localAddMusicRect, (pendingAddMusicUri == null ? (chineseMode ? "选择音乐文件" : "Pick music file") : shortUriName(pendingAddMusicUri)), 255, pendingAddMusicUri != null);
        drawMusicToolButton(canvas, localAddLrcRect, (pendingAddLrcUri == null ? (chineseMode ? "选择 LRC 歌词" : "Pick LRC file") : shortUriName(pendingAddLrcUri)), 255, pendingAddLrcUri != null);
        drawInputField(canvas, localAddNameRect, pendingAddNameFocused, pendingAddName, chineseMode ? "音乐名称" : "Music name", 255);
        drawMusicToolButton(canvas, localAddCancelRect, chineseMode ? "取消" : "Cancel", 255, false);
        drawMusicToolButton(canvas, localAddSaveRect, chineseMode ? "完成" : "Save", 255, pendingAddMusicUri != null);
    }

    private void drawInputField(Canvas canvas, RectF b, boolean focused, String text, String hint, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(focused ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(focused ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(text == null || text.length() == 0 ? t.textLight : t.textDark, alpha));
        String show = text == null || text.length() == 0 ? hint : text;
        drawText(canvas, ellipsize(show + (focused ? "|" : ""), textPaint, b.width() - dpRaw(22)), b.left + dpRaw(11), b.centerY() + dpRaw(4), textPaint);
    }

    private void drawLyrics(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        canvas.save();
        canvas.clipRect(musicResultsRect);
        int current = currentLyricIndex();
        if (current < 0) current = 0;
        float centerY = musicResultsRect.centerY();
        float lineH = Math.max(dpRaw(24), musicResultsRect.height() / 4.5f);
        textPaint.setTextAlign(Paint.Align.LEFT);
        for (int offset = -2; offset <= 2; offset++) {
            int idx = current + offset;
            if (idx < 0 || idx >= lyricLines.length) continue;
            float y = centerY + offset * lineH + dpRaw(5);
            boolean active = offset == 0;
            textPaint.setFakeBoldText(active);
            textPaint.setTextSize(active ? dpRaw(15) : dpRaw(12));
            textPaint.setColor(applyAlpha(active ? t.accent : t.textMid, active ? alpha : (int)(alpha * 0.72f)));
            String text = lyricLines[idx].text == null ? "" : lyricLines[idx].text;
            if (text.length() == 0) text = "…";
            drawText(canvas, ellipsize(text, textPaint, musicResultsRect.width() - dpRaw(22)), musicResultsRect.left + dpRaw(11), y, textPaint);
            textPaint.setFakeBoldText(false);
        }
        textPaint.setTextSize(dpRaw(10));
        textPaint.setColor(applyAlpha(t.textLight, alpha));
        drawText(canvas, lyricStatus, musicResultsRect.left + dpRaw(11), musicResultsRect.bottom - dpRaw(8), textPaint);
        canvas.restore();
    }


    private void drawLyricOverlay(Canvas canvas) {
        if (!lyricOverlayEnabled) return;
        if (lyricLines == null || lyricLines.length == 0) return;
        int current = currentLyricIndex();
        if (current < 0) current = 0;
        long now = SystemClock.uptimeMillis();
        if (lyricDisplayedIndex < 0) {
            lyricDisplayedIndex = current;
            lyricAnimFromIndex = current;
            lyricAnimStartMs = now - LYRIC_ANIM_MS;
        } else if (current != lyricDisplayedIndex) {
            lyricAnimFromIndex = lyricDisplayedIndex;
            lyricDisplayedIndex = current;
            lyricAnimStartMs = now;
        }

        float anim = Math.min(1f, Math.max(0f, (now - lyricAnimStartMs) / (float) LYRIC_ANIM_MS));
        anim = easeValue(anim);
        ThemePalette t = theme();
        float w = Math.min(getWidth() * 0.68f, dpRaw(760));
        float lineH = Math.max(dpRaw(25), getHeight() * 0.052f);
        float h = lineH * 3f + dpRaw(24);
        float left = (getWidth() - w) / 2f;
        float top = getHeight() - h - dpRaw(38);
        if (panelVisible && panelProgress > 0.25f) top = Math.min(top, panelRect.bottom - h - dpRaw(18));
        if (top < dpRaw(18)) top = dpRaw(18);
        lyricOverlayRect.set(left, top, left + w, top + h);

        // Pure lyric overlay: no background and no border, only the three lyric lines.

        canvas.save();
        canvas.clipRect(lyricOverlayRect.left + dpRaw(14), lyricOverlayRect.top + dpRaw(8), lyricOverlayRect.right - dpRaw(14), lyricOverlayRect.bottom - dpRaw(8));
        float centerY = lyricOverlayRect.centerY() + dpRaw(5);
        textPaint.setTextAlign(Paint.Align.CENTER);
        for (int offset = -1; offset <= 1; offset++) {
            int idx = current + offset;
            if (idx < 0 || idx >= lyricLines.length) continue;
            float startY = centerY + (idx - lyricAnimFromIndex) * lineH;
            float targetY = centerY + offset * lineH;
            float y = startY + (targetY - startY) * anim;
            boolean active = offset == 0;
            int targetAlpha = active ? 245 : 112;
            int startAlpha = (idx == lyricAnimFromIndex) ? 245 : 92;
            int lineAlpha = (int) (startAlpha + (targetAlpha - startAlpha) * anim);
            textPaint.setFakeBoldText(active);
            textPaint.setTextSize((active ? dpRaw(18) : dpRaw(14)) * musicLyricScale);
            textPaint.setColor(applyAlpha(active ? t.accent : t.textDark, lineAlpha));
            String text = lyricLines[idx].text == null ? "" : lyricLines[idx].text.trim();
            if (text.length() == 0) text = "…";
            drawText(canvas, ellipsize(text, textPaint, w - dpRaw(44)), lyricOverlayRect.centerX(), y, textPaint);
            textPaint.setFakeBoldText(false);
        }
        textPaint.setTextAlign(Paint.Align.LEFT);
        canvas.restore();
    }

    private void drawMusicResults(Canvas canvas, int alpha) {
        ThemePalette t = theme();
        canvas.save();
        canvas.clipRect(musicResultsRect);
        if (musicLoading || musicPreparing) {
            textPaint.setFakeBoldText(false);
            textPaint.setTextSize(dpRaw(12));
            textPaint.setColor(applyAlpha(t.textLight, alpha));
            drawText(canvas, chineseMode ? "正在请求网易云 API..." : "Requesting Netease API...", musicResultsRect.left + dpRaw(8), musicResultsRect.top + dpRaw(25), textPaint);
        } else if (musicResults.length == 0) {
            textPaint.setFakeBoldText(false);
            textPaint.setTextSize(dpRaw(12));
            textPaint.setColor(applyAlpha(t.textLight, alpha));
            drawText(canvas, chineseMode ? "输入关键词后点击搜索" : "Type a keyword and tap Go", musicResultsRect.left + dpRaw(8), musicResultsRect.top + dpRaw(25), textPaint);
        } else {
            float rowH = Math.max(dpRaw(34), musicResultsRect.height() / 5.4f);
            int count = Math.min(musicResults.length, musicResultRects.length);
            for (int i = 0; i < count; i++) {
                float top = musicResultsRect.top + i * (rowH + dpRaw(5));
                musicResultRects[i].set(musicResultsRect.left, top, musicResultsRect.right, top + rowH);
                MusicSong song = musicResults[i];
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(applyAlpha(i == selectedSongIndex ? t.activeSoft : t.softBg, alpha));
                canvas.drawRoundRect(musicResultRects[i], dpRaw(12), dpRaw(12), paint);
                textPaint.setFakeBoldText(true);
                textPaint.setTextSize(dpRaw(12));
                textPaint.setColor(applyAlpha(t.textDark, alpha));
                drawText(canvas, ellipsize(song.name, textPaint, musicResultRects[i].width() * 0.58f), musicResultRects[i].left + dpRaw(12), musicResultRects[i].centerY() - dpRaw(2), textPaint);
                textPaint.setFakeBoldText(false);
                textPaint.setTextSize(dpRaw(11));
                textPaint.setColor(applyAlpha(t.textMid, alpha));
                drawText(canvas, ellipsize(song.artist, textPaint, musicResultRects[i].width() * 0.32f), musicResultRects[i].left + musicResultRects[i].width() * 0.62f, musicResultRects[i].centerY() - dpRaw(2), textPaint);
            }
            for (int i = count; i < musicResultRects.length; i++) musicResultRects[i].setEmpty();
        }
        canvas.restore();
    }

    private void drawMusicButton(Canvas canvas, RectF b, String text, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(t.softBg, alpha));
        canvas.drawOval(b, paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(15) * logWindowTextScale);
        textPaint.setColor(applyAlpha(t.accent, alpha));
        drawCenteredText(canvas, text, b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawMusicToolButton(Canvas canvas, RectF b, String text, int alpha, boolean active) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(active ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(active ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(11));
        textPaint.setColor(applyAlpha(active ? t.accent : t.textDark, alpha));
        drawCenteredText(canvas, text, b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawMusicNameField(Canvas canvas, RectF b, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(musicNameFocused ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(musicNameFocused ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dpRaw(12), dpRaw(12), paint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(11));
        textPaint.setColor(applyAlpha(musicNameInput.length() == 0 ? t.textLight : t.textDark, alpha));
        String show = musicNameInput.length() == 0 ? (chineseMode ? "输入音乐名称" : "Music name") : musicNameInput;
        drawText(canvas, ellipsize(show + (musicNameFocused ? "|" : ""), textPaint, b.width() - dpRaw(20)), b.left + dpRaw(10), b.centerY() + dpRaw(4), textPaint);
    }

    private void drawGgbMusicIcon(Canvas canvas, RectF b, int alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(0xFFE60000, alpha));
        canvas.drawRoundRect(b, dpRaw(17), dpRaw(17), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(dpRaw(3), b.width() * 0.08f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(applyAlpha(0xFFFFFFFF, alpha));
        float cx = b.centerX();
        float cy = b.centerY();
        float r = Math.min(b.width(), b.height()) * 0.28f;
        canvas.drawCircle(cx, cy, r, paint);
        canvas.drawArc(new RectF(cx - r * 1.55f, cy - r * 1.55f, cx + r * 1.55f, cy + r * 1.55f), 135, 285, false, paint);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx, cy, Math.max(dpRaw(4), r * 0.34f), paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private boolean musicTouchStartedOnControl() {
        return musicSearchRect.contains(musicDownX, musicDownY)
                || musicSearchButtonRect.contains(musicDownX, musicDownY)
                || musicImportMusicRect.contains(musicDownX, musicDownY)
                || musicImportLrcRect.contains(musicDownX, musicDownY)
                || musicLyricToggleRect.contains(musicDownX, musicDownY)
                || musicNameRect.contains(musicDownX, musicDownY)
                || musicPlayRect.contains(musicDownX, musicDownY)
                || musicPrevRect.contains(musicDownX, musicDownY)
                || musicNextRect.contains(musicDownX, musicDownY);
    }

    private boolean handleMusicTouch(MotionEvent event, float x, float y) {
        if (!musicWindowEnabled && !localAddDialogOpen) return false;
        float w = musicWindowWidth();
        float h = musicWindowHeight();
        musicRect.set(musicX, musicY, musicX + w, musicY + h);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (localAddDialogOpen && localAddDialogRect.contains(x, y)) {
                    musicDownX = x;
                    musicDownY = y;
                    musicDragging = true;
                    return true;
                }
                if (!musicRect.contains(x, y)) {
                    if (musicSearchFocused) deactivateMusicSearch();
                    if (musicNameFocused) deactivateMusicNameInput();
                    if (pendingAddNameFocused) deactivatePendingAddNameInput();
                    return false;
                }
                musicDownX = x;
                musicDownY = y;
                musicStartX = musicX;
                musicStartY = musicY;
                musicDragging = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (musicDragging && !isMusicControlAt(musicDownX, musicDownY) && !localAddDialogOpen) {
                    if (dist(x, y, musicDownX, musicDownY) > dpRaw(10)) {
                        musicX = musicStartX + x - musicDownX;
                        musicY = musicStartY + y - musicDownY;
                        clampMusic();
                        requestFrame();
                    }
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (musicDragging) {
                    musicDragging = false;
                    if (dist(x, y, musicDownX, musicDownY) < dpRaw(8)) {
                        if (localAddDialogOpen) {
                            if (localAddMusicRect.contains(x, y)) {
                                pendingFileTarget = 1;
                                requestLocalMusicImport();
                            } else if (localAddLrcRect.contains(x, y)) {
                                pendingFileTarget = 2;
                                requestLocalLrcImport();
                            } else if (localAddNameRect.contains(x, y)) {
                                activatePendingAddNameInput();
                            } else if (localAddSaveRect.contains(x, y)) {
                                savePendingLocalSong();
                            } else if (localAddCancelRect.contains(x, y)) {
                                closeLocalAddDialog();
                            } else if (!localAddDialogRect.contains(x, y)) {
                                closeLocalAddDialog();
                            }
                        } else if (musicLyricToggleRect.contains(x, y)) {
                            toggleLyricOverlay();
                        } else if (musicLocalTabRect.contains(x, y)) {
                            musicPanelMode = 0;
                            try { prefs().edit().putInt("music_panel_mode", musicPanelMode).apply(); } catch (Exception ignored) { }
                            deactivateMusicSearch();
                        } else if (musicNeteaseTabRect.contains(x, y)) {
                            musicPanelMode = 1;
                            try { prefs().edit().putInt("music_panel_mode", musicPanelMode).apply(); } catch (Exception ignored) { }
                        } else if (musicPanelMode == 0 && musicAddLocalRect.contains(x, y)) {
                            openLocalAddDialog();
                        } else if (musicPanelMode == 0) {
                            int idx = hitLocalSong(x, y);
                            if (idx >= 0) playLocalSong(idx);
                            else if (musicPlayRect.contains(x, y)) toggleMusicPlay();
                            else if (musicPrevRect.contains(x, y)) selectRelativeLocalSong(-1);
                            else if (musicNextRect.contains(x, y)) selectRelativeLocalSong(1);
                            else { if (pendingAddNameFocused) deactivatePendingAddNameInput(); }
                        } else if (musicPanelMode == 1) {
                            if (musicSearchRect.contains(x, y)) activateMusicSearch();
                            else if (musicSearchButtonRect.contains(x, y)) performMusicSearch();
                            else if (musicPlayRect.contains(x, y)) toggleMusicPlay();
                            else if (musicPrevRect.contains(x, y)) selectRelativeMusic(-1);
                            else if (musicNextRect.contains(x, y)) selectRelativeMusic(1);
                            else {
                                int result = hitMusicResult(x, y);
                                if (result >= 0) selectMusicResult(result, true);
                                else { if (musicSearchFocused) deactivateMusicSearch(); if (musicNameFocused) deactivateMusicNameInput(); }
                            }
                        }
                    }
                    return true;
                }
                break;
        }
        return false;
    }

    private boolean isMusicControlAt(float x, float y) {
        if (musicLyricToggleRect.contains(x, y) || musicLocalTabRect.contains(x, y) || musicNeteaseTabRect.contains(x, y)
                || musicPlayRect.contains(x, y) || musicPrevRect.contains(x, y) || musicNextRect.contains(x, y)) return true;
        if (musicPanelMode == 0) {
            if (musicAddLocalRect.contains(x, y)) return true;
            return hitLocalSong(x, y) >= 0;
        }
        return musicSearchRect.contains(x, y) || musicSearchButtonRect.contains(x, y) || hitMusicResult(x, y) >= 0;
    }

    private void openLocalAddDialog() {
        localAddDialogOpen = true;
        pendingAddMusicUri = null;
        pendingAddLrcUri = null;
        pendingAddName = "Local Music";
        pendingAddNameFocused = false;
        pendingFileTarget = 0;
        requestFrame();
    }

    private void closeLocalAddDialog() {
        localAddDialogOpen = false;
        pendingAddNameFocused = false;
        pendingFileTarget = 0;
        hideKeyboard();
        requestFrame();
    }

    private void savePendingLocalSong() {
        if (pendingAddMusicUri == null) {
            musicStatus = chineseMode ? "请先选择音乐文件" : "Pick music file first";
            requestFrame();
            return;
        }
        String name = pendingAddName == null || pendingAddName.trim().length() == 0 ? shortUriName(pendingAddMusicUri) : pendingAddName.trim();
        LocalSong song = new LocalSong(name, pendingAddMusicUri.toString(), pendingAddLrcUri == null ? "" : pendingAddLrcUri.toString());
        localPlaylist.add(song);
        selectedLocalSongIndex = localPlaylist.size() - 1;
        saveLocalPlaylist();
        closeLocalAddDialog();
        musicPanelMode = 0;
        musicStatus = chineseMode ? "已保存本地音乐" : "Local music saved";
        selectLocalSong(selectedLocalSongIndex, false);
        requestFrame();
    }

    private void selectLocalSong(int index, boolean autoPlay) {
        if (index < 0 || index >= localPlaylist.size()) return;
        selectedLocalSongIndex = index;
        LocalSong song = localPlaylist.get(index);
        localMusicUri = Uri.parse(song.musicUri);
        localMusicMode = true;
        selectedSongIndex = -1;
        musicNameInput = song.name;
        musicTitle = song.name;
        musicArtist = chineseMode ? "本地音乐" : "Local music";
        if (song.lrcUri != null && song.lrcUri.length() > 0) {
            try {
                String lrc = readTextFromUri(Uri.parse(song.lrcUri));
                lyricLines = parseLrc(lrc);
                lyricStatus = (chineseMode ? "LRC 已加载：" : "LRC loaded: ") + song.name;
            } catch (Exception e) {
                lyricLines = new LrcLine[0];
                lyricStatus = chineseMode ? "LRC 加载失败" : "LRC load failed";
            }
        } else {
            lyricLines = new LrcLine[0];
            lyricStatus = chineseMode ? "无 LRC" : "No LRC";
        }
        lyricDisplayedIndex = -1;
        lyricAnimFromIndex = -1;
        musicStatus = chineseMode ? "已选择本地音乐" : "Local music selected";
        if (autoPlay) startLocalMediaPlayer(localMusicUri);
    }

    private void playLocalSong(int index) {
        selectLocalSong(index, true);
    }

    private void selectRelativeLocalSong(int direction) {
        if (localPlaylist.size() == 0) return;
        int next = selectedLocalSongIndex;
        if (next < 0) next = 0;
        else next += direction;
        if (next < 0) next = localPlaylist.size() - 1;
        if (next >= localPlaylist.size()) next = 0;
        playLocalSong(next);
    }

    private int hitLocalSong(float x, float y) {
        int count = Math.min(localPlaylist.size(), localSongRects.length);
        for (int i = 0; i < count; i++) if (localSongRects[i] != null && localSongRects[i].contains(x, y)) return i;
        return -1;
    }

    private void toggleLyricOverlay() {
        lyricOverlayEnabled = !lyricOverlayEnabled;
        lyricDisplayedIndex = -1;
        lyricAnimFromIndex = -1;
        lyricAnimStartMs = SystemClock.uptimeMillis();
        if (lyricOverlayEnabled) {
            if (lyricLines == null || lyricLines.length == 0) musicStatus = chineseMode ? "请先导入 LRC 歌词" : "Import LRC first";
            else musicStatus = chineseMode ? "歌词显示已开启" : "Lyric overlay on";
        } else {
            musicStatus = chineseMode ? "歌词显示已关闭" : "Lyric overlay off";
        }
        requestFrame();
    }

    private void toggleMusicPlay() {
        if (musicPreparing || musicLoading) return;
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    musicPlaying = false;
                    musicStatus = chineseMode ? "已暂停" : "Paused";
                } else {
                    mediaPlayer.start();
                    musicPlaying = true;
                    musicStatus = chineseMode ? "正在播放" : "Playing";
                }
            } catch (Exception e) {
                musicPlaying = false;
                musicStatus = chineseMode ? "播放器状态异常" : "Player state error";
            }
            requestFrame();
            return;
        }
        if (musicPanelMode == 0 && selectedLocalSongIndex >= 0 && selectedLocalSongIndex < localPlaylist.size()) {
            selectLocalSong(selectedLocalSongIndex, true);
        } else if (localMusicUri != null) {
            startLocalMediaPlayer(localMusicUri);
        } else if (selectedSongIndex >= 0 && selectedSongIndex < musicResults.length) {
            selectMusicResult(selectedSongIndex, true);
        } else {
            performMusicSearch();
        }
    }

    public void requestFontImport() {
        Context c = getContext();
        if (c instanceof MainActivity) ((MainActivity) c).openFontPicker();
        else if (c instanceof Activity) openDocument((Activity) c, "*/*", new String[]{"font/ttf", "font/otf", "application/x-font-ttf", "application/x-font-otf", "application/octet-stream"}, MainActivity.REQUEST_PICK_FONT);
    }

    public void requestLocalMusicImport() {
        Context c = getContext();
        if (c instanceof MainActivity) ((MainActivity) c).openMusicPicker();
        else if (c instanceof Activity) openDocument((Activity) c, "audio/*", null, MainActivity.REQUEST_PICK_MUSIC);
    }

    public void requestLocalLrcImport() {
        Context c = getContext();
        if (c instanceof MainActivity) ((MainActivity) c).openLrcPicker();
        else if (c instanceof Activity) openDocument((Activity) c, "*/*", new String[]{"text/*", "application/octet-stream"}, MainActivity.REQUEST_PICK_LRC);
    }

    private void openDocument(Activity a, String type, String[] mimes, int requestCode) {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(type == null ? "*/*" : type);
            if (mimes != null) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            a.startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            if (requestCode == MainActivity.REQUEST_PICK_FONT) fontStatus = chineseMode ? "无法打开文件管理器" : "Cannot open file manager";
            else musicStatus = chineseMode ? "无法打开文件管理器" : "Cannot open file manager";
            requestFrame();
        }
    }

    public void handleImportedFont(Uri uri) {
        if (uri == null) return;
        try {
            String ext = guessFontExt(uri);
            File file = copyUriToCache(uri, "imported_global_font" + ext);
            Typeface tf = Typeface.createFromFile(file);
            globalTypeface = tf;
            textPaint.setTypeface(globalTypeface);
            fontStatus = (chineseMode ? "已应用字体：" : "Font applied: ") + shortUriName(uri);
        } catch (Exception e) {
            fontStatus = chineseMode ? "字体导入失败，请选择 TTF/OTF" : "Font import failed, choose TTF/OTF";
        }
        rebuildLayoutCache();
        requestFrame();
    }

    public void handleImportedMusic(Uri uri) {
        if (uri == null) return;
        if (pendingFileTarget == 1 || localAddDialogOpen) {
            pendingAddMusicUri = uri;
            if (pendingAddName == null || pendingAddName.trim().length() == 0 || "Local Music".equals(pendingAddName)) pendingAddName = shortUriName(uri);
            pendingFileTarget = 0;
            musicStatus = chineseMode ? "已选择音乐文件" : "Music file selected";
            requestFrame();
            return;
        }
        stopMusicPlayback(false);
        localMusicUri = uri;
        localMusicMode = true;
        musicPanelMode = 0;
        musicResults = new MusicSong[0];
        selectedSongIndex = -1;
        String name = musicNameInput == null || musicNameInput.trim().length() == 0 ? shortUriName(uri) : musicNameInput.trim();
        musicNameInput = name;
        musicTitle = name;
        musicArtist = chineseMode ? "本地音乐" : "Local music";
        musicStatus = chineseMode ? "本地音乐已导入，点击播放" : "Local music imported, tap play";
        requestFrame();
    }

    public void handleImportedLrc(Uri uri) {
        if (uri == null) return;
        if (pendingFileTarget == 2 || localAddDialogOpen) {
            pendingAddLrcUri = uri;
            pendingFileTarget = 0;
            musicStatus = chineseMode ? "已选择 LRC 歌词" : "LRC selected";
            requestFrame();
            return;
        }
        try {
            String text = readTextFromUri(uri);
            lyricLines = parseLrc(text);
            lyricStatus = (chineseMode ? "LRC 已导入：" : "LRC imported: ") + shortUriName(uri);
            lyricDisplayedIndex = -1;
            lyricAnimFromIndex = -1;
            if (lyricLines.length == 0) lyricStatus = chineseMode ? "LRC 没有解析到时间轴" : "No timestamp found in LRC";
        } catch (Exception e) {
            lyricLines = new LrcLine[0];
            lyricStatus = chineseMode ? "LRC 导入失败" : "LRC import failed";
        }
        requestFrame();
    }

    private void resetGlobalFont() {
        globalTypeface = null;
        textPaint.setTypeface(null);
        fontStatus = chineseMode ? "已恢复默认字体" : "Default font restored";
        rebuildLayoutCache();
        requestFrame();
    }

    private File copyUriToCache(Uri uri, String fileName) throws Exception {
        File out = new File(getContext().getCacheDir(), fileName);
        InputStream in = getContext().getContentResolver().openInputStream(uri);
        if (in == null) throw new java.io.IOException("openInputStream failed");
        FileOutputStream fos = new FileOutputStream(out);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        fos.close();
        in.close();
        return out;
    }

    private String readTextFromUri(Uri uri) throws Exception {
        InputStream in = getContext().getContentResolver().openInputStream(uri);
        if (in == null) throw new java.io.IOException("openInputStream failed");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        byte[] data = bos.toByteArray();
        String utf = new String(data, "UTF-8");
        if (utf.indexOf('�') < 0) return utf;
        try {
            return new String(data, "GB18030");
        } catch (Exception ignored) {
            return utf;
        }
    }

    private String guessFontExt(Uri uri) {
        String name = shortUriName(uri).toLowerCase();
        if (name.endsWith(".otf")) return ".otf";
        return ".ttf";
    }

    private String shortUriName(Uri uri) {
        if (uri == null) return "file";
        String s = uri.getLastPathSegment();
        if (s == null || s.length() == 0) s = uri.toString();
        int slash = Math.max(s.lastIndexOf('/'), s.lastIndexOf(':'));
        if (slash >= 0 && slash + 1 < s.length()) s = s.substring(slash + 1);
        if (s.length() > 28) s = s.substring(0, 25) + "...";
        return s;
    }

    private void performMusicSearch() {
        String q = musicQuery == null ? "" : musicQuery.trim();
        if (q.length() == 0) q = "Linux";
        musicQuery = q;
        deactivateMusicSearch();
        localMusicMode = false;
        localMusicUri = null;
        lyricLines = new LrcLine[0];
        lyricOverlayEnabled = false;
        lyricDisplayedIndex = -1;
        lyricAnimFromIndex = -1;
        searchNeteaseMusic(q);
    }

    private void fetchNeteaseMusic() {
        performMusicSearch();
    }

    private void searchNeteaseMusic(final String keyword) {
        if (musicLoading) return;
        stopMusicPlayback(false);
        musicLoading = true;
        musicStatus = chineseMode ? "正在搜索 API Enhanced..." : "Searching API Enhanced...";
        requestFrame();
        new Thread(new Runnable() {
            @Override
            public void run() {
                MusicSong[] results = new MusicSong[0];
                String status;
                String usedBase = "";
                Exception lastError = null;
                for (String base : MUSIC_API_BASES) {
                    try {
                        String q = URLEncoder.encode(keyword, "UTF-8");
                        String api = trimSlash(base) + "/search?keywords=" + q + "&type=1&limit=6&offset=0";
                        String body = httpGet(api);
                        results = parseNeteaseSearch(body);
                        usedBase = base;
                        if (results.length > 0) break;
                    } catch (Exception e) {
                        lastError = e;
                    }
                }

                // Fallback: NetEase official web search endpoint. It does not provide playback URLs,
                // but it usually returns song ids even when api-enhanced instances are unavailable.
                if (results.length == 0) {
                    try {
                        String q = URLEncoder.encode(keyword, "UTF-8");
                        String api = NETEASE_OFFICIAL_SEARCH + "?s=" + q + "&type=1&offset=0&total=true&limit=6";
                        String body = httpGet(api);
                        results = parseNeteaseSearch(body);
                        usedBase = "official-search";
                    } catch (Exception e) {
                        lastError = e;
                    }
                }

                if (results.length > 0) {
                    status = (chineseMode ? "搜索完成 · " : "Search complete · ") + shortApiName(usedBase);
                } else {
                    status = lastError == null ? (chineseMode ? "没有搜索结果" : "No result") : (chineseMode ? "API Enhanced 请求失败" : "API Enhanced failed");
                }
                final MusicSong[] finalResults = results;
                final String finalStatus = status;
                post(new Runnable() {
                    @Override
                    public void run() {
                        musicResults = finalResults;
                        selectedSongIndex = finalResults.length > 0 ? 0 : -1;
                        if (selectedSongIndex >= 0) {
                            musicTitle = finalResults[0].name;
                            musicArtist = finalResults[0].artist;
                        }
                        musicStatus = finalStatus;
                        musicLoading = false;
                        requestFrame();
                    }
                });
            }
        }).start();
    }

    private MusicSong[] parseNeteaseSearch(String body) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONObject result = root.optJSONObject("result");
        JSONArray songs = result == null ? null : result.optJSONArray("songs");
        if (songs == null || songs.length() == 0) return new MusicSong[0];
        int count = Math.min(6, songs.length());
        MusicSong[] out = new MusicSong[count];
        for (int i = 0; i < count; i++) {
            JSONObject song = songs.getJSONObject(i);
            String name = song.optString("name", "Unknown");
            long id = song.optLong("id", 0L);
            String artist = "Netease";
            JSONArray artists = song.optJSONArray("artists");
            if (artists == null) artists = song.optJSONArray("ar");
            if (artists != null && artists.length() > 0) {
                StringBuilder sb = new StringBuilder();
                int ac = Math.min(3, artists.length());
                for (int j = 0; j < ac; j++) {
                    if (j > 0) sb.append("/");
                    sb.append(artists.getJSONObject(j).optString("name", ""));
                }
                if (sb.length() > 0) artist = sb.toString();
            }
            long duration = song.optLong("duration", song.optLong("dt", 0L));
            out[i] = new MusicSong(id, name, artist, duration);
        }
        return out;
    }

    private void selectRelativeMusic(int direction) {
        if (musicResults.length == 0) {
            performMusicSearch();
            return;
        }
        int next = selectedSongIndex + direction;
        if (next < 0) next = musicResults.length - 1;
        if (next >= musicResults.length) next = 0;
        selectMusicResult(next, false);
    }

    private void selectMusicResult(int index, boolean autoPlay) {
        if (index < 0 || index >= musicResults.length) return;
        selectedSongIndex = index;
        MusicSong song = musicResults[index];
        musicTitle = song.name;
        musicArtist = song.artist;
        musicStatus = chineseMode ? "已选择，正在获取播放地址" : "Selected, fetching url";
        requestFrame();
        if (autoPlay) fetchSongUrlAndPlay(song);
    }

    private void fetchSongUrlAndPlay(final MusicSong song) {
        if (song == null || song.id <= 0L || musicPreparing) return;
        stopMusicPlayback(false);
        musicPreparing = true;
        musicStatus = chineseMode ? "正在获取 API Enhanced 播放地址..." : "Fetching API Enhanced url...";
        requestFrame();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String url = "";
                String status;
                String usedBase = "";
                for (String base : MUSIC_API_BASES) {
                    try {
                        url = requestEnhancedSongUrl(base, song.id);
                        if (url.length() > 0) {
                            usedBase = base;
                            break;
                        }
                    } catch (Exception ignored) {
                    }
                }
                if (url.length() == 0) {
                    // Last fallback: official outer url. Free songs normally redirect to a playable file.
                    url = buildOuterUrl(song.id);
                    usedBase = "outer-url";
                }
                status = url.length() > 0 ? ((chineseMode ? "播放地址已获取 · " : "Play url ready · ") + shortApiName(usedBase)) : (chineseMode ? "该歌曲暂无可用播放地址" : "No playable url");
                final String finalUrl = url;
                final String finalStatus = status;
                post(new Runnable() {
                    @Override
                    public void run() {
                        musicPreparing = false;
                        musicUrl = finalUrl;
                        musicStatus = finalStatus;
                        if (finalUrl.length() > 0) startMediaPlayer(finalUrl, buildOuterUrl(song.id));
                        requestFrame();
                    }
                });
            }
        }).start();
    }

    private String requestEnhancedSongUrl(String base, long songId) throws Exception {
        String clean = trimSlash(base);
        String[] urls = new String[]{
                clean + "/song/url?id=" + songId + "&br=320000&randomCNIP=true",
                clean + "/song/url?id=" + songId + "&br=320000&realIP=" + DEFAULT_REAL_IP,
                clean + "/song/url?id=" + songId + "&br=128000&randomCNIP=true",
                clean + "/song/url/v1?id=" + songId + "&level=standard&randomCNIP=true",
                clean + "/song/url/v1?id=" + songId + "&level=higher&randomCNIP=true",
                clean + "/song/url/v1?id=" + songId + "&level=exhigh&randomCNIP=true"
        };
        Exception last = null;
        for (String api : urls) {
            try {
                String body = httpGet(api);
                String url = parseSongUrl(body);
                if (url.length() > 0) return url;
            } catch (Exception e) {
                last = e;
            }
        }
        if (last != null) throw last;
        return "";
    }

    private String parseSongUrl(String body) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONArray data = root.optJSONArray("data");
        if (data != null && data.length() > 0) {
            JSONObject first = data.getJSONObject(0);
            String url = first.optString("url", "");
            if (isPlayableUrl(url)) return url;
        }
        JSONObject dataObj = root.optJSONObject("data");
        if (dataObj != null) {
            String url = dataObj.optString("url", "");
            if (isPlayableUrl(url)) return url;
        }
        return "";
    }

    private boolean isPlayableUrl(String url) {
        if (url == null) return false;
        if (url.length() == 0) return false;
        if ("null".equalsIgnoreCase(url)) return false;
        return url.startsWith("http://") || url.startsWith("https://");
    }

    private String buildOuterUrl(long songId) {
        return NETEASE_OUTER_URL + songId + ".mp3";
    }

    private String trimSlash(String s) {
        if (s == null || s.length() == 0) return "";
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private String shortApiName(String base) {
        if (base == null || base.length() == 0) return "API";
        if (base.indexOf("jimsdeng") >= 0) return "api.jimsdeng";
        if (base.indexOf("10.0.2.2") >= 0) return "local-emulator";
        if (base.indexOf("127.0.0.1") >= 0) return "local";
        if (base.indexOf("outer-url") >= 0) return "outer-url";
        if (base.indexOf("official-search") >= 0) return "official-search";
        return "API Enhanced";
    }

    private String httpGet(String api) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(api).openConnection();
        c.setConnectTimeout(9000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent", MUSIC_USER_AGENT);
        c.setRequestProperty("Referer", "https://music.163.com/");
        c.setRequestProperty("Origin", "https://music.163.com");
        c.setRequestProperty("Accept", "application/json,text/plain,*/*");
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8");
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) throw new java.io.IOException("HTTP " + code);
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        c.disconnect();
        if (code >= 400) throw new java.io.IOException("HTTP " + code + ": " + sb.toString());
        return sb.toString();
    }

    private void startMediaPlayer(final String url, final String fallbackUrl) {
        try {
            stopMusicPlayback(false);
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

            Map<String, String> headers = new HashMap<String, String>();
            headers.put("User-Agent", MUSIC_USER_AGENT);
            headers.put("Referer", "https://music.163.com/");
            headers.put("Origin", "https://music.163.com");
            mediaPlayer.setDataSource(getContext(), Uri.parse(url), headers);

            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    try {
                        mp.start();
                        musicPreparing = false;
                        musicPlaying = true;
                        localMusicMode = false;
                        musicUrl = url;
                        musicPlayStartMs = SystemClock.uptimeMillis();
                        musicStatus = chineseMode ? "正在播放" : "Playing";
                    } catch (Exception e) {
                        musicPreparing = false;
                        musicPlaying = false;
                        musicStatus = chineseMode ? "播放失败" : "Play failed";
                    }
                    requestFrame();
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    musicPlaying = false;
                    musicStatus = chineseMode ? "播放完成" : "Completed";
                    requestFrame();
                }
            });
            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    musicPlaying = false;
                    musicPreparing = false;
                    final boolean canFallback = fallbackUrl != null
                            && fallbackUrl.length() > 0
                            && !fallbackUrl.equals(url);
                    if (canFallback) {
                        musicStatus = chineseMode ? "直链失败，尝试外链播放" : "Direct url failed, trying outer url";
                        requestFrame();
                        postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startMediaPlayer(fallbackUrl, "");
                            }
                        }, 120);
                    } else {
                        musicStatus = chineseMode ? "播放失败：可能需要版权或会员" : "Play failed: copyright/VIP limited";
                        requestFrame();
                    }
                    return true;
                }
            });
            musicPreparing = true;
            musicStatus = chineseMode ? "正在准备播放器" : "Preparing player";
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            musicPreparing = false;
            musicPlaying = false;
            final boolean canFallback = fallbackUrl != null
                    && fallbackUrl.length() > 0
                    && !fallbackUrl.equals(url);
            if (canFallback) {
                musicStatus = chineseMode ? "播放器启动失败，尝试外链" : "Player start failed, trying outer url";
                requestFrame();
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startMediaPlayer(fallbackUrl, "");
                    }
                }, 120);
            } else {
                musicStatus = chineseMode ? "无法播放：API 或版权限制" : "Cannot play: API/copyright limited";
                requestFrame();
            }
        }
    }

    private void startLocalMediaPlayer(final Uri uri) {
        if (uri == null) return;
        try {
            stopMusicPlayback(false);
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(getContext(), uri);
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    try {
                        mp.start();
                        musicPreparing = false;
                        musicPlaying = true;
                        localMusicMode = true;
                        musicPlayStartMs = SystemClock.uptimeMillis();
                        musicTitle = musicNameInput == null || musicNameInput.length() == 0 ? shortUriName(uri) : musicNameInput;
                        musicArtist = chineseMode ? "本地音乐" : "Local music";
                        musicStatus = chineseMode ? "正在播放本地音乐" : "Playing local music";
                    } catch (Exception e) {
                        musicPreparing = false;
                        musicPlaying = false;
                        musicStatus = chineseMode ? "本地音乐播放失败" : "Local play failed";
                    }
                    requestFrame();
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    musicPlaying = false;
                    musicStatus = chineseMode ? "本地音乐播放完成" : "Local music completed";
                    requestFrame();
                }
            });
            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    musicPlaying = false;
                    musicPreparing = false;
                    musicStatus = chineseMode ? "本地音乐播放失败" : "Local music play failed";
                    requestFrame();
                    return true;
                }
            });
            musicPreparing = true;
            musicStatus = chineseMode ? "正在准备本地音乐" : "Preparing local music";
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            musicPreparing = false;
            musicPlaying = false;
            musicStatus = chineseMode ? "无法打开本地音乐" : "Cannot open local music";
            requestFrame();
        }
    }

    private void stopMusicPlayback(boolean clear) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }
        } catch (Exception ignored) {
        }
        mediaPlayer = null;
        musicPlaying = false;
        musicPreparing = false;
        if (clear) {
            musicUrl = "";
            localMusicUri = null;
            localMusicMode = false;
            lyricLines = new LrcLine[0];
            lyricOverlayEnabled = false;
            lyricDisplayedIndex = -1;
            lyricAnimFromIndex = -1;
        }
    }

    private float getMusicProgress() {
        try {
            if (mediaPlayer != null) {
                int dur = mediaPlayer.getDuration();
                if (dur > 0) return Math.max(0f, Math.min(1f, mediaPlayer.getCurrentPosition() / (float) dur));
            }
        } catch (Exception ignored) {
        }
        return musicPlaying ? ((SystemClock.uptimeMillis() - musicPlayStartMs) % 30000L) / 30000f : 0f;
    }

    private LrcLine[] parseLrc(String text) {
        ArrayList<LrcLine> list = new ArrayList<LrcLine>();
        if (text == null) return new LrcLine[0];
        String[] lines = text.replace("\r", "").split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int pos = 0;
            ArrayList<Long> times = new ArrayList<Long>();
            while (pos < line.length()) {
                int l = line.indexOf('[', pos);
                int r = line.indexOf(']', l + 1);
                if (l < 0 || r < 0) break;
                long ms = parseLrcTime(line.substring(l + 1, r));
                if (ms >= 0) times.add(Long.valueOf(ms));
                pos = r + 1;
                if (l != 0) break;
            }
            String lyric = pos < line.length() ? line.substring(pos).trim() : "";
            for (int j = 0; j < times.size(); j++) list.add(new LrcLine(times.get(j).longValue(), lyric));
        }
        Collections.sort(list, new Comparator<LrcLine>() {
            @Override
            public int compare(LrcLine a, LrcLine b) {
                return a.timeMs < b.timeMs ? -1 : (a.timeMs == b.timeMs ? 0 : 1);
            }
        });
        return list.toArray(new LrcLine[list.size()]);
    }

    private long parseLrcTime(String raw) {
        try {
            if (raw == null) return -1;
            int colon = raw.indexOf(':');
            if (colon <= 0) return -1;
            long min = Long.parseLong(raw.substring(0, colon).trim());
            String secRaw = raw.substring(colon + 1).trim();
            long sec;
            long ms = 0;
            int dot = secRaw.indexOf('.');
            if (dot >= 0) {
                sec = Long.parseLong(secRaw.substring(0, dot));
                String frac = secRaw.substring(dot + 1);
                if (frac.length() == 1) ms = Long.parseLong(frac) * 100;
                else if (frac.length() == 2) ms = Long.parseLong(frac) * 10;
                else if (frac.length() >= 3) ms = Long.parseLong(frac.substring(0, 3));
            } else {
                sec = Long.parseLong(secRaw);
            }
            return min * 60000L + sec * 1000L + ms;
        } catch (Exception e) {
            return -1;
        }
    }

    private int currentLyricIndex() {
        if (lyricLines == null || lyricLines.length == 0) return -1;
        long pos = 0;
        try {
            if (mediaPlayer != null) pos = mediaPlayer.getCurrentPosition();
            else if (musicPlaying) pos = (SystemClock.uptimeMillis() - musicPlayStartMs);
        } catch (Exception ignored) {
        }
        int idx = 0;
        for (int i = 0; i < lyricLines.length; i++) {
            if (lyricLines[i].timeMs <= pos) idx = i;
            else break;
        }
        return idx;
    }

    private int hitMusicResult(float x, float y) {
        int count = Math.min(musicResults.length, musicResultRects.length);
        for (int i = 0; i < count; i++) {
            if (musicResultRects[i] != null && musicResultRects[i].contains(x, y)) return i;
        }
        return -1;
    }

    private void activateMusicSearch() {
        musicSearchFocused = true;
        musicNameFocused = false;
        pendingAddNameFocused = false;
        requestFocus();
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        requestFrame();
    }

    private void deactivateMusicSearch() {
        if (!musicSearchFocused) return;
        musicSearchFocused = false;
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
        requestFrame();
    }

    private void activateMusicNameInput() {
        musicNameFocused = true;
        musicSearchFocused = false;
        pendingAddNameFocused = false;
        requestFocus();
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        requestFrame();
    }

    private void deactivateMusicNameInput() {
        if (!musicNameFocused) return;
        musicNameFocused = false;
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
        requestFrame();
    }

    private void activatePendingAddNameInput() {
        pendingAddNameFocused = true;
        musicNameFocused = false;
        musicSearchFocused = false;
        requestFocus();
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        requestFrame();
    }

    private void deactivatePendingAddNameInput() {
        if (!pendingAddNameFocused) return;
        pendingAddNameFocused = false;
        hideKeyboard();
        requestFrame();
    }

    private void appendPendingAddName(CharSequence text) {
        if (text == null) return;
        pendingAddName += text.toString();
        requestFrame();
    }

    private void deletePendingAddName() {
        if (pendingAddName == null || pendingAddName.length() == 0) return;
        pendingAddName = pendingAddName.substring(0, pendingAddName.length() - 1);
        requestFrame();
    }

    private void appendMusicName(CharSequence text) {
        if (text == null) return;
        musicNameInput += text.toString();
        musicTitle = musicNameInput.length() == 0 ? (chineseMode ? "本地音乐" : "Local Music") : musicNameInput;
        requestFrame();
    }

    private void deleteMusicName() {
        if (musicNameInput == null || musicNameInput.length() == 0) return;
        musicNameInput = musicNameInput.substring(0, musicNameInput.length() - 1);
        musicTitle = musicNameInput.length() == 0 ? (chineseMode ? "本地音乐" : "Local Music") : musicNameInput;
        requestFrame();
    }

    private void appendMusicQuery(CharSequence text) {
        if (text == null) return;
        musicQuery += text.toString();
        requestFrame();
    }

    private void deleteMusicQuery() {
        if (musicQuery == null || musicQuery.length() == 0) return;
        musicQuery = musicQuery.substring(0, musicQuery.length() - 1);
        requestFrame();
    }

    private void clampMusic() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float w = musicWindowWidth();
        float h = musicWindowHeight();
        float m = dpRaw(8);
        if (musicX < m) musicX = m;
        if (musicY < m) musicY = m;
        if (musicX > getWidth() - w - m) musicX = getWidth() - w - m;
        if (musicY > getHeight() - h - m) musicY = getHeight() - h - m;
    }

    private String ellipsize(String text, Paint p, float maxWidth) {
        if (text == null) return "";
        if (p.measureText(text) <= maxWidth) return text;
        String suffix = "...";
        int end = text.length();
        while (end > 0 && p.measureText(text.substring(0, end) + suffix) > maxWidth) end--;
        return end <= 0 ? suffix : text.substring(0, end) + suffix;
    }


    private void ensureArrayListPosition() {
        if (arrayListPositionReady && getWidth() > 0 && getHeight() > 0) return;
        arrayListX = Math.max(dpRaw(8), getWidth() - dpRaw(250));
        arrayListY = Math.max(dpRaw(18), getHeight() * 0.18f);
        arrayListPositionReady = true;
    }

    private ArrayList<Feature> collectArrayListFeatures() {
        long now = SystemClock.uptimeMillis();
        if (!arrayListCacheDirty && now - arrayListCacheTimeMs < 650L) return arrayListFeatureCache;
        arrayListFeatureCache.clear();
        for (int si = 0; si < sections.length; si++) {
            Section sec = sections[si];
            if (sec == null || sec.features == null) continue;
            collectArrayListFeaturesFrom(sec.features, arrayListFeatureCache, false);
        }
        Collections.sort(arrayListFeatureCache, new Comparator<Feature>() {
            @Override public int compare(Feature a, Feature b) {
                String ta = getFeatureTitle(a);
                String tb = getFeatureTitle(b);
                return tb.length() - ta.length();
            }
        });
        arrayListCacheTimeMs = now;
        arrayListCacheDirty = false;
        return arrayListFeatureCache;
    }

    private void markArrayListDirty() {
        arrayListCacheDirty = true;
        arrayListCacheTimeMs = 0L;
    }

    private void collectArrayListFeaturesFrom(Feature[] list, ArrayList<Feature> out, boolean setting) {
        if (list == null) return;
        for (int i = 0; i < list.length; i++) {
            Feature f = list[i];
            if (f == null) continue;
            if (f.type == CONTROL_SWITCH && f.enabled) {
                if (!setting || arrayListShowDebugSettings) out.add(f);
            }
            if (arrayListShowDebugSettings && f.debugOpen && f.settings != null) collectArrayListFeaturesFrom(f.settings, out, true);
        }
    }

    private ArrayList<ArrayListAnim> prepareArrayListDrawItems(ArrayList<Feature> activeItems) {
        long now = SystemClock.uptimeMillis();
        if (arrayListLastAnimMs <= 0L) arrayListLastAnimMs = now;
        float dt = Math.min(0.050f, Math.max(0.001f, (now - arrayListLastAnimMs) / 1000f));
        arrayListLastAnimMs = now;

        for (Map.Entry<String, ArrayListAnim> e : arrayListAnimMap.entrySet()) e.getValue().active = false;
        for (int i = 0; i < activeItems.size(); i++) {
            Feature f = activeItems.get(i);
            String label = getFeatureTitle(f);
            String key = label;
            ArrayListAnim a = arrayListAnimMap.get(key);
            if (a == null) {
                a = new ArrayListAnim();
                a.label = label;
                a.progress = 0f;
                arrayListAnimMap.put(key, a);
            }
            if (!label.equals(a.label)) {
                a.label = label;
                a.width = -1f;
            }
            a.active = true;
            a.orderHint = label.length();
        }

        arrayListDrawCache.clear();
        ArrayList<String> remove = null;
        arrayListAnimating = false;
        float step = dt / 0.18f;
        for (Map.Entry<String, ArrayListAnim> e : arrayListAnimMap.entrySet()) {
            ArrayListAnim a = e.getValue();
            float target = a.active ? 1f : 0f;
            if (a.progress < target) a.progress = Math.min(target, a.progress + step);
            else if (a.progress > target) a.progress = Math.max(target, a.progress - step);
            if (Math.abs(a.progress - target) > 0.01f) arrayListAnimating = true;
            if (!a.active && a.progress <= 0.01f) {
                if (remove == null) remove = new ArrayList<String>();
                remove.add(e.getKey());
            } else if (a.progress > 0.01f) {
                arrayListDrawCache.add(a);
            }
        }
        if (remove != null) for (int i = 0; i < remove.size(); i++) arrayListAnimMap.remove(remove.get(i));
        Collections.sort(arrayListDrawCache, new Comparator<ArrayListAnim>() {
            @Override public int compare(ArrayListAnim a, ArrayListAnim b) {
                return b.orderHint - a.orderHint;
            }
        });
        return arrayListDrawCache;
    }

    /**
     * Draws the ArrayList / enabled-feature list.
     *
     * The text, side bar and glow are scaled from the same size factor. This
     * prevents the old bug where text and side bars drifted onto different
     * baselines when "功能列表大小" was changed.
     */
    private void drawArrayListWindow(Canvas canvas) {
        if (!arrayListEnabled) return;
        ensureArrayListPosition();
        ArrayList<Feature> activeItems = collectArrayListFeatures();
        ArrayList<ArrayListAnim> items = prepareArrayListDrawItems(activeItems);
        if (items.size() == 0) return;
        float listScale = arrayListTextSizeFactor;
        float textSize = dpRaw(15f) * listScale;
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(textSize);
        float maxW = 0f;
        for (int i = 0; i < items.size(); i++) {
            ArrayListAnim ai = items.get(i);
            // Always remeasure because 功能列表大小 changes both font and bar scale.
            ai.width = textPaint.measureText(ai.label);
            maxW = Math.max(maxW, ai.width);
        }
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float lineH = Math.max(textSize * 1.34f, (-fm.ascent + fm.descent) * 1.18f);
        float barW = dpRaw(3.5f) * arrayListBarWidthFactor * listScale;
        float totalW = maxW + dpRaw(18) * listScale + barW;
        float totalH = lineH * items.size();
        arrayListX = clamp(arrayListX, dpRaw(4), Math.max(dpRaw(4), getWidth() - totalW - dpRaw(4)));
        arrayListY = clamp(arrayListY, dpRaw(4), Math.max(dpRaw(4), getHeight() - totalH - dpRaw(4)));
        arrayListRect.set(arrayListX, arrayListY, arrayListX + totalW, arrayListY + totalH);

        boolean oldThemeGradientForArrayList = themeTextGradientEnabled;
        long oldGradientOverride = gradientFrameOverrideMs;
        themeTextGradientEnabled = false;
        long arrayListGradientTime = arrayListGradientFrameTimeMs();
        gradientFrameOverrideMs = arrayListGradientTime;
        for (int i = 0; i < items.size(); i++) {
            ArrayListAnim item = items.get(i);
            float p = easeValue(item.progress);
            int itemAlpha = clampAlpha((int) (255f * p));
            if (itemAlpha <= 2) continue;
            float rowTop = arrayListRect.top + i * lineH;
            float baseline = rowTop + lineH / 2f - (fm.ascent + fm.descent) / 2f;
            String label = item.label;
            float textW = item.width < 0f ? textPaint.measureText(label) : item.width;
            float slide = (1f - p) * dpRaw(22f) * listScale;
            float textX = arrayListRect.right - barW - dpRaw(8) * listScale - textW + slide;

            arrayListGlowRect.set(textX - dpRaw(4) * listScale, rowTop - dpRaw(2) * listScale, arrayListRect.right + dpRaw(5) * listScale, rowTop + lineH + dpRaw(2) * listScale);
            // Draw every ArrayList refresh instead of only on expensive-effect frames.
            // The old gate made the glow appear/disappear on alternating frames, which looked like flicker.
            if (arrayListGlowEnabled && !arrayListDragging && arrayListGlowStrength > 0.01f) {
                drawShapeGlow(canvas, arrayListGlowRect, dpRaw(7), false, arrayListGlowStrength * p, false, null, 0xFF000000, (int)(150 * p), true, 1.0f, 0);
            }

            float itemBarH = Math.max(barW * 2.2f, lineH * (0.42f + arrayListBarLengthFactor * 0.46f));
            float barTop = rowTop + (lineH - itemBarH) / 2f;
            arrayListBarRect.set(arrayListRect.right - barW, barTop, arrayListRect.right, barTop + itemBarH);
            paint.setStyle(Paint.Style.FILL);
            if (arrayListBarGradient && arrayListBarColors != null && arrayListBarColors.length > 1) {
                if (arrayListBarGradientStyle == 1) {
                    paint.setShader(null);
                    paint.setColor(animatedClassicColorAtTime(arrayListBarColors, arrayListBarColor, (int)(230 * p), arrayListBarGradientSpeed, gradientFrameTimeMs(gradientDelayMs(arrayListBarGradientDelay))));
                } else {
                    paint.setShader(makeMovingGradientAtTime(arrayListBarRect, arrayListBarColors, arrayListBarColor, (int)(230 * p), arrayListBarGradientSpeed, gradientFrameTimeMs(gradientDelayMs(arrayListBarGradientDelay))));
                }
            } else {
                paint.setShader(null);
                paint.setColor(applyAlpha(arrayListBarColor, (int)(230 * p)));
            }
            canvas.drawRoundRect(arrayListBarRect, barW / 2f, barW / 2f, paint);
            paint.setShader(null);

            if (arrayListTextGradient && arrayListTextColors != null && arrayListTextColors.length > 1) {
                if (arrayListTextGradientStyle == 1) {
                    textPaint.setShader(null);
                    textPaint.setColor(animatedClassicColorAtTime(arrayListTextColors, arrayListTextColor, itemAlpha, arrayListTextGradientSpeed, gradientFrameTimeMs(gradientDelayMs(arrayListTextGradientDelay))));
                } else {
                    textPaint.setColor(0xFFFFFFFF);
                    if (!hotInteractionFrame) {
                        arrayListTextGradientRect.set(textX, baseline + fm.ascent, textX + textW, baseline + fm.descent + dpRaw(4) * listScale);
                        textPaint.setShader(makeMovingGradientAtTime(arrayListTextGradientRect, arrayListTextColors, arrayListTextColor, itemAlpha, arrayListTextGradientSpeed, gradientFrameTimeMs(gradientDelayMs(arrayListTextGradientDelay))));
                    } else {
                        textPaint.setShader(null);
                        textPaint.setColor(applyAlpha(arrayListTextColors != null && arrayListTextColors.length > 0 ? arrayListTextColors[0] : arrayListTextColor, itemAlpha));
                    }
                }
            } else {
                textPaint.setShader(null);
                textPaint.setColor(applyAlpha(arrayListTextColor, itemAlpha));
            }
            drawText(canvas, label, textX, baseline, textPaint);
            textPaint.setShader(null);
        }
        gradientFrameOverrideMs = oldGradientOverride;
        themeTextGradientEnabled = oldThemeGradientForArrayList;
        textPaint.setFakeBoldText(false);
        if (arrayListPositionEdit || arrayListAnimating) requestFrame();
    }

    private boolean handleArrayListTouch(MotionEvent event, float x, float y) {
        if (!arrayListEnabled || !arrayListPositionEdit) return false;
        if (event.getAction() == MotionEvent.ACTION_DOWN && arrayListRect.contains(x, y)) {
            arrayListDragging = true;
            arrayListDownX = x;
            arrayListDownY = y;
            arrayListStartX = arrayListX;
            arrayListStartY = arrayListY;
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE && arrayListDragging) {
            arrayListX = arrayListStartX + x - arrayListDownX;
            arrayListY = arrayListStartY + y - arrayListDownY;
            requestFrame();
            return true;
        }
        if ((event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) && arrayListDragging) {
            arrayListDragging = false;
            return true;
        }
        return arrayListRect.contains(x, y);
    }

    private void ensureLogPosition() {
        if (logPositionReady && getWidth() > 0 && getHeight() > 0) return;
        float w = Math.min(dpRaw(360), Math.max(dpRaw(270), getWidth() * 0.32f));
        float h = Math.min(dpRaw(260), Math.max(dpRaw(180), getHeight() * 0.38f));
        logX = Math.max(dpRaw(18), getWidth() - w - dpRaw(24));
        logY = Math.max(dpRaw(18), getHeight() - h - dpRaw(24));
        logPositionReady = true;
    }

    private void layoutLogWindow() {
        ensureLogPosition();
        float w = Math.min(dpRaw(380), Math.max(dpRaw(280), getWidth() * 0.34f));
        float h = Math.min(dpRaw(280), Math.max(dpRaw(190), getHeight() * 0.40f));
        logX = clamp(logX, dpRaw(8), Math.max(dpRaw(8), getWidth() - w - dpRaw(8)));
        logY = clamp(logY, dpRaw(8), Math.max(dpRaw(8), getHeight() - h - dpRaw(8)));
        logWindowRect.set(logX, logY, logX + w, logY + h);
        logHeaderRect.set(logWindowRect.left, logWindowRect.top, logWindowRect.right, logWindowRect.top + dpRaw(45));
        float btnW = dpRaw(72);
        float btnH = dpRaw(28);
        logExportRect.set(logWindowRect.right - dpRaw(12) - btnW, logWindowRect.top + dpRaw(9), logWindowRect.right - dpRaw(12), logWindowRect.top + dpRaw(9) + btnH);
        logClearRect.set(logExportRect.left - dpRaw(8) - btnW, logExportRect.top, logExportRect.left - dpRaw(8), logExportRect.bottom);
        logBodyRect.set(logWindowRect.left + dpRaw(12), logHeaderRect.bottom + dpRaw(8), logWindowRect.right - dpRaw(12), logWindowRect.bottom - dpRaw(12));
    }

    private void drawLogWindow(Canvas canvas) {
        if (!logWindowEnabled) return;
        layoutLogWindow();
        long now = SystemClock.uptimeMillis();
        if (now - lastRealtimeLogMs > 1000L) {
            if (logRecordFps) appendLog("FPS=" + currentFps + "  panel=" + (panelVisible ? "open" : "closed") + "  music=" + (musicPlaying ? "playing" : "idle"));
            lastRealtimeLogMs = now;
        }
        int alpha = clampAlpha((int)(235 * logWindowOpacity));
        float r = dpRaw(18);
        if (hintGlowEnabled) drawShapeGlowDelayed(canvas, logWindowRect, r, false, 0.28f, hintGlowGradient, hintGlowColors, hintGlowColor, 180, true, hintGlowGradientSpeed, hintGlowGradientStyle, hintGlowGradientDelay);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(isGlassTheme() ? 0xD0142438 : 0xEA0F172A);
        canvas.drawRoundRect(logWindowRect, r, r, paint);
        if (isGlassTheme()) {
            tempRect.set(logWindowRect.left + 1, logWindowRect.top + 1, logWindowRect.right - 1, logWindowRect.top + logWindowRect.height() * 0.42f);
            paint.setColor(0x28FFFFFF);
            canvas.drawRoundRect(tempRect, r, r, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(isRgbTheme() ? 0x99FFFFFF : 0x4D94A3B8);
        canvas.drawRoundRect(logWindowRect, r, r, paint);

        textPaint.setShader(null);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(15));
        textPaint.setColor(0xFFFFFFFF);
        drawText(canvas, chineseMode ? "实时日志" : "Runtime Log", logWindowRect.left + dpRaw(14), logWindowRect.top + dpRaw(28), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(10));
        textPaint.setColor(0xAFCBD5E1);
        String countText = runtimeLogs.size() + (chineseMode ? " 条" : " lines");
        drawText(canvas, countText, logWindowRect.left + dpRaw(92), logWindowRect.top + dpRaw(28), textPaint);
        drawSmallLogButton(canvas, logClearRect, chineseMode ? "清除" : "Clear", alpha);
        drawSmallLogButton(canvas, logExportRect, chineseMode ? "导出" : "Export", alpha);

        canvas.save();
        canvas.clipRect(logBodyRect);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(11) * logWindowTextScale);
        textPaint.setColor(0xDDE5E7EB);
        float lineH = dpRaw(16) * logWindowTextScale;
        float contentH = Math.max(lineH, runtimeLogs.size() * lineH + dpRaw(8));
        logMaxScrollY = Math.max(0f, contentH - logBodyRect.height());
        logScrollY = clamp(logScrollY, 0f, logMaxScrollY);
        float y = logBodyRect.top + dpRaw(13) - logScrollY;
        for (int i = 0; i < runtimeLogs.size(); i++) {
            if (y > logBodyRect.top - lineH && y < logBodyRect.bottom + lineH) {
                String line = ellipsize(runtimeLogs.get(i), textPaint, logBodyRect.width());
                drawText(canvas, line, logBodyRect.left, y, textPaint);
            }
            y += lineH;
        }
        canvas.restore();
        textPaint.setFakeBoldText(false);
    }

    private void drawSmallLogButton(Canvas canvas, RectF b, String label, int alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(isRgbTheme() ? 0xFF334155 : 0xFF1F2937, alpha));
        canvas.drawRoundRect(b, dpRaw(10), dpRaw(10), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(0x66FFFFFF, alpha));
        canvas.drawRoundRect(b, dpRaw(10), dpRaw(10), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(11));
        textPaint.setColor(applyAlpha(0xFFE5E7EB, alpha));
        drawCenteredText(canvas, label, b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private boolean handleLogTouch(MotionEvent event, float x, float y) {
        if (!logWindowEnabled) return false;
        layoutLogWindow();
        if (event.getAction() == MotionEvent.ACTION_DOWN && logWindowRect.contains(x, y)) {
            if (logClearRect.contains(x, y)) {
                clearRuntimeLogs();
                return true;
            }
            if (logExportRect.contains(x, y)) {
                requestLogExport();
                return true;
            }
            if (logHeaderRect.contains(x, y)) {
                logDragging = true;
                logDownX = x;
                logDownY = y;
                logStartX = logX;
                logStartY = logY;
                return true;
            }
            if (logBodyRect.contains(x, y)) {
                logBodyScrolling = true;
                logBodyDownY = y;
                logScrollStartY = logScrollY;
                return true;
            }
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE && logDragging) {
            float w = logWindowRect.width();
            float h = logWindowRect.height();
            logX = clamp(logStartX + x - logDownX, dpRaw(8), Math.max(dpRaw(8), getWidth() - w - dpRaw(8)));
            logY = clamp(logStartY + y - logDownY, dpRaw(8), Math.max(dpRaw(8), getHeight() - h - dpRaw(8)));
            requestFrame();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE && logBodyScrolling) {
            logScrollY = clamp(logScrollStartY - (y - logBodyDownY), 0f, logMaxScrollY);
            requestFrame();
            return true;
        }
        if ((event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) && (logDragging || logBodyScrolling)) {
            logDragging = false;
            logBodyScrolling = false;
            return true;
        }
        return logWindowRect.contains(x, y);
    }

    private void appendLog(String message) {
        if (!logWindowEnabled || message == null) return;
        long now = SystemClock.uptimeMillis();
        long total = now / 1000L;
        long mm = (total / 60L) % 60L;
        long ss = total % 60L;
        String line = String.format("#%03d %02d:%02d  %s", ++logSerial, mm, ss, message);
        runtimeLogs.add(line);
        while (runtimeLogs.size() > 220) runtimeLogs.remove(0);
        if (!logBodyScrolling) logScrollY = 999999f;
        logStatus = chineseMode ? ("已记录 " + runtimeLogs.size() + " 条日志") : ("Recorded " + runtimeLogs.size() + " log lines");
    }

    private void clearRuntimeLogs() {
        runtimeLogs.clear();
        logSerial = 0L;
        logScrollY = 0f;
        logMaxScrollY = 0f;
        logStatus = chineseMode ? "日志已清除" : "Log cleared";
        if (logWindowEnabled) appendLog("Runtime log cleared");
        requestFrame();
    }

    private void requestLogExport() {
        appendLog("Export requested");
        Context c = getContext();
        if (c instanceof MainActivity) ((MainActivity)c).openLogExporter();
        else if (c instanceof Activity) {
            try {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, "linux_ui_log.txt");
                ((Activity)c).startActivityForResult(intent, MainActivity.REQUEST_EXPORT_LOG);
            } catch (Exception e) {
                appendLog("Cannot open export manager: " + e.getClass().getSimpleName());
            }
        }
    }

    public void handleExportLogUri(Uri uri) {
        if (uri == null) return;
        try {
            OutputStream out = getContext().getContentResolver().openOutputStream(uri);
            if (out == null) {
                appendLog("Export failed: null stream");
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Linux UI Runtime Log\n");
            sb.append("Lines: ").append(runtimeLogs.size()).append("\n\n");
            for (int i = 0; i < runtimeLogs.size(); i++) sb.append(runtimeLogs.get(i)).append('\n');
            out.write(sb.toString().getBytes("UTF-8"));
            out.flush();
            out.close();
            logStatus = chineseMode ? "日志已导出" : "Log exported";
            appendLog("Export success");
        } catch (Exception e) {
            logStatus = chineseMode ? "日志导出失败" : "Log export failed";
            appendLog("Export failed: " + e.getClass().getSimpleName());
        }
        requestFrame();
    }

    private void drawHintToast(Canvas canvas) {
        if (hintStyle == 1) {
            draw2HintToast(canvas);
            return;
        }
        drawDefaultHintToast(canvas);
    }

    private void drawDefaultHintToast(Canvas canvas) {
        if (hintToasts.size() == 0) {
            hintActive = false;
            return;
        }

        long now = SystemClock.uptimeMillis();
        float w = getHintToastWidth();
        float h = getHintToastHeight();
        float gap = getHintToastGap();
        int visibleIndex = 0;

        for (int i = 0; i < hintToasts.size(); i++) {
            HintToast toast = hintToasts.get(i);
            long elapsed = now - toast.startMs;

            boolean infiniteHint = hintPositionEdit && hintToasts.size() == 1;
            if (!infiniteHint && elapsed >= hintDurationMs && !draggingHint) {
                hintToasts.remove(i);
                i--;
                continue;
            }

            float life = infiniteHint ? 0f : Math.min(1f, elapsed / (float) Math.max(10L, hintDurationMs));
            float progress = infiniteHint ? 1f : 1f - life;
            float enter = Math.min(1f, elapsed / 180f);
            float exit = infiniteHint ? 1f : Math.min(1f, Math.max(0L, hintDurationMs - elapsed) / 180f);
            float fade = draggingHint ? 1f : Math.min(enter, exit);
            fade = naturalEase(fade);

            // Old prompts stay at the saved base position. New prompts stack above them.
            float toastX = hintX;
            float toastY = hintY - visibleIndex * (h + gap);
            rect.set(toastX, toastY, toastX + w, toastY + h);

            int a = clampAlpha((int) (255 * hintOpacity * fade));
            if (hintGlowEnabled) drawShapeGlowDelayed(canvas, rect, dp(18 * hintSize), false, hintGlowStrength, hintGlowGradient, hintGlowColors, hintGlowColor, a, false, hintGlowGradientSpeed, hintGlowGradientStyle, hintGlowGradientDelay);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);

            tempRect.set(rect);
            tempRect.offset(0, dp(4));
            paint.setColor(applyAlpha(0x16000000, a));
            canvas.drawRoundRect(tempRect, dp(18 * hintSize), dp(18 * hintSize), paint);

            int hintBodyAlpha = isGlassTheme() ? (int) (a * 0.76f) : a;
            int hintBody = isGlassTheme() ? blend(theme().panelBg, theme().softBg, 0.48f) : theme().panelBg;
            paint.setColor(applyAlpha(hintBody, hintBodyAlpha));
            canvas.drawRoundRect(rect, dp(18 * hintSize), dp(18 * hintSize), paint);

            if (isGlassTheme()) {
                tempRect.set(rect.left + dp(1), rect.top + dp(1), rect.right - dp(1), rect.top + rect.height() * 0.45f);
                paint.setColor(applyAlpha(0x55FFFFFF, (int) (a * 0.35f)));
                canvas.drawRoundRect(tempRect, dp(18 * hintSize), dp(18 * hintSize), paint);
            }

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(applyAlpha(isGlassTheme() ? blend(theme().stroke, theme().accent, 0.22f) : theme().stroke, a));
            canvas.drawRoundRect(rect, dp(18 * hintSize), dp(18 * hintSize), paint);

            textPaint.setFakeBoldText(true);
            textPaint.setTextSize(dp(15 * hintSize));
            textPaint.setColor(applyAlpha(theme().textDark, a));
            boolean oldThemeGradient = themeTextGradientEnabled;
            themeTextGradientEnabled = false;
            drawText(canvas, toast.text, rect.left + dp(18 * hintSize), rect.top + dp(31 * hintSize), textPaint);
            themeTextGradientEnabled = oldThemeGradient;
            textPaint.setFakeBoldText(false);

            hintBarBgRect.set(
                    rect.left + dp(18 * hintSize),
                    rect.bottom - dp(20 * hintSize),
                    rect.right - dp(18 * hintSize),
                    rect.bottom - dp(12 * hintSize)
            );
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(theme().stroke, a));
            canvas.drawRoundRect(hintBarBgRect, hintBarBgRect.height() / 2f, hintBarBgRect.height() / 2f, paint);

            hintBarRect.set(hintBarBgRect.left, hintBarBgRect.top, hintBarBgRect.left + hintBarBgRect.width() * progress, hintBarBgRect.bottom);
            paint.setColor(applyAlpha(toast.enabled ? 0xFF22C55E : 0xFFEF4444, a));
            canvas.drawRoundRect(hintBarRect, hintBarRect.height() / 2f, hintBarRect.height() / 2f, paint);

            visibleIndex++;
        }

        hintActive = hintToasts.size() > 0;
        if (hintActive) requestFrame();
    }

    private void draw2HintToast(Canvas canvas) {
        if (hintToasts.size() == 0) {
            hintActive = false;
            return;
        }

        long now = SystemClock.uptimeMillis();
        float w = getHintToastWidth();
        float h = getHintToastHeight();
        float gap = getHintToastGap();
        int visibleIndex = 0;

        for (int i = 0; i < hintToasts.size(); i++) {
            HintToast toast = hintToasts.get(i);
            long elapsed = now - toast.startMs;

            boolean infiniteHint = hintPositionEdit && hintToasts.size() == 1;
            if (!infiniteHint && elapsed >= hintDurationMs && !draggingHint) {
                hintToasts.remove(i);
                i--;
                continue;
            }

            float life = infiniteHint ? 0f : Math.min(1f, elapsed / (float) Math.max(10L, hintDurationMs));
            float progress = infiniteHint ? 1f : 1f - life;
            float enter = Math.min(1f, elapsed / 170f);
            float exit = infiniteHint ? 1f : Math.min(1f, Math.max(0L, hintDurationMs - elapsed) / 170f);
            float fade = draggingHint ? 1f : Math.min(enter, exit);
            fade = naturalEase(fade);
            float slide = dp(30 * hintSize) * (1f - fade);

            float toastX = hintX + slide;
            float toastY = hintY - visibleIndex * (h + gap);
            rect.set(toastX, toastY, toastX + w, toastY + h);

            int a = clampAlpha((int) (255 * hintOpacity * fade));
            int stateColor = toast.enabled ? 0xFF22C55E : 0xFFEF4444;
            int darkBg = isGlassTheme() ? blend(0xFF101827, theme().panelBg, 0.20f) : 0xFF101827;
            if (hintGlowEnabled) drawShapeGlowDelayed(canvas, rect, dp(10 * hintSize), false, hintGlowStrength, hintGlowGradient, hintGlowColors, hintGlowColor, a, false, hintGlowGradientSpeed, hintGlowGradientStyle, hintGlowGradientDelay);

            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            tempRect.set(rect);
            tempRect.offset(0, dp(3 * hintSize));
            paint.setColor(applyAlpha(0x66000000, (int) (a * 0.62f)));
            canvas.drawRoundRect(tempRect, dp(10 * hintSize), dp(10 * hintSize), paint);

            paint.setColor(applyAlpha(darkBg, (int) (a * 0.92f)));
            canvas.drawRoundRect(rect, dp(10 * hintSize), dp(10 * hintSize), paint);

            tempRect.set(rect.left, rect.top, rect.left + dp(5 * hintSize), rect.bottom);
            paint.setColor(applyAlpha(stateColor, a));
            canvas.drawRoundRect(tempRect, dp(10 * hintSize), dp(10 * hintSize), paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1 * hintSize));
            paint.setColor(applyAlpha(stateColor, (int) (a * 0.70f)));
            canvas.drawRoundRect(rect, dp(10 * hintSize), dp(10 * hintSize), paint);

            float pad = dp(14 * hintSize);
            float tagW = dp(50 * hintSize);
            tempRect.set(rect.right - pad - tagW, rect.centerY() - dp(11 * hintSize), rect.right - pad, rect.centerY() + dp(11 * hintSize));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(stateColor, (int) (a * 0.18f)));
            canvas.drawRoundRect(tempRect, tempRect.height() / 2f, tempRect.height() / 2f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1 * hintSize));
            paint.setColor(applyAlpha(stateColor, (int) (a * 0.70f)));
            canvas.drawRoundRect(tempRect, tempRect.height() / 2f, tempRect.height() / 2f, paint);

            textPaint.setFakeBoldText(true);
            textPaint.setTextSize(dp(11 * hintSize));
            textPaint.setColor(applyAlpha(stateColor, a));
            textPaint.setTextAlign(Paint.Align.CENTER);
            boolean oldThemeGradient = themeTextGradientEnabled;
            themeTextGradientEnabled = false;
            drawText(canvas, toast.enabled ? "ON" : "OFF", tempRect.centerX(), tempRect.centerY() + dp(4 * hintSize), textPaint);
            textPaint.setTextAlign(Paint.Align.LEFT);

            textPaint.setTextSize(dp(13 * hintSize));
            textPaint.setColor(applyAlpha(0xFFF8FAFC, a));
            String name = ellipsize(toast.text, textPaint, Math.max(1f, w - tagW - dp(42 * hintSize)));
            drawText(canvas, name, rect.left + dp(16 * hintSize), rect.centerY() + dp(5 * hintSize), textPaint);
            themeTextGradientEnabled = oldThemeGradient;
            textPaint.setFakeBoldText(false);

            float barH = dp(2 * hintSize);
            hintBarBgRect.set(rect.left + dp(10 * hintSize), rect.bottom - barH - dp(4 * hintSize), rect.right - dp(10 * hintSize), rect.bottom - dp(4 * hintSize));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(0x55FFFFFF, (int) (a * 0.35f)));
            canvas.drawRoundRect(hintBarBgRect, barH / 2f, barH / 2f, paint);
            hintBarRect.set(hintBarBgRect.left, hintBarBgRect.top, hintBarBgRect.left + hintBarBgRect.width() * progress, hintBarBgRect.bottom);
            paint.setColor(applyAlpha(stateColor, a));
            canvas.drawRoundRect(hintBarRect, barH / 2f, barH / 2f, paint);

            visibleIndex++;
        }

        hintActive = hintToasts.size() > 0;
        if (hintActive) requestFrame();
    }

    private void drawColorPicker(Canvas canvas) {
        ThemePalette t = theme();
        int alpha = 246;
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        paint.setColor(applyAlpha(0x66000000, 180));
        canvas.drawRect(screenRect, paint);

        float w = Math.min(getWidth() - dpRaw(36), dpRaw(720));
        float h = Math.min(getHeight() - dpRaw(36), dpRaw(430));
        float left = (getWidth() - w) / 2f;
        float top = (getHeight() - h) / 2f;
        colorPickerRect.set(left, top, left + w, top + h);
        rect.set(colorPickerRect);
        rect.offset(0, dpRaw(7));
        paint.setColor(applyAlpha(0x18000000, alpha));
        canvas.drawRoundRect(rect, dpRaw(24), dpRaw(24), paint);
        paint.setColor(applyAlpha(t.panelBg, alpha));
        canvas.drawRoundRect(colorPickerRect, dpRaw(24), dpRaw(24), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1.2f));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(colorPickerRect, dpRaw(24), dpRaw(24), paint);

        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(20));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, chineseMode ? "RGB / 渐变选色界面" : "RGB / Gradient Color Picker", left + dpRaw(24), top + dpRaw(38), textPaint);
        textPaint.setFakeBoldText(false);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(t.textMid, alpha));
        drawText(canvas, chineseMode ? "点击调色板，或输入 RGB；右侧可切换静态/渐变" : "Tap palette or type RGB; use the right side for static/gradient", left + dpRaw(24), top + dpRaw(60), textPaint);

        float preview = dpRaw(58);
        colorPreviewRect.set(colorPickerRect.right - dpRaw(96), top + dpRaw(22), colorPickerRect.right - dpRaw(38), top + dpRaw(22) + preview);
        paint.setStyle(Paint.Style.FILL);
        if (editingColorFeature != null && isColorFeatureGradient(editingColorFeature) && getColorFeatureGradientColors(editingColorFeature) != null && getColorFeatureGradientColors(editingColorFeature).length > 1) {
            Shader oldPreviewShader = paint.getShader();
            if (editingColorFeature.gradientStyle == 1) {
                paint.setShader(null);
                paint.setColor(animatedClassicColorAtTime(getColorFeatureGradientColors(editingColorFeature), argb(255, pickerR, pickerG, pickerB), alpha, editingColorFeature.gradientSpeed, featureGradientFrameTimeMs(editingColorFeature)));
            } else {
                paint.setShader(makeMovingGradientAtTime(colorPreviewRect, getColorFeatureGradientColors(editingColorFeature), argb(255, pickerR, pickerG, pickerB), alpha, editingColorFeature.gradientSpeed, featureGradientFrameTimeMs(editingColorFeature)));
            }
            canvas.drawRoundRect(colorPreviewRect, dpRaw(16), dpRaw(16), paint);
            paint.setShader(oldPreviewShader);
        } else {
            paint.setShader(null);
            paint.setColor(argb(255, pickerR, pickerG, pickerB));
            canvas.drawRoundRect(colorPreviewRect, dpRaw(16), dpRaw(16), paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(colorPreviewRect, dpRaw(16), dpRaw(16), paint);

        float sw = dpRaw(38);
        float gap = dpRaw(8);
        float sx = left + dpRaw(24);
        float sy = top + dpRaw(84);
        for (int i = 0; i < colorSwatchRects.length; i++) {
            int col = paletteColor(i);
            int row = i / 8;
            int colIndex = i % 8;
            RectF r = colorSwatchRects[i];
            r.set(sx + colIndex * (sw + gap), sy + row * (sw + gap), sx + colIndex * (sw + gap) + sw, sy + row * (sw + gap) + sw);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(col);
            canvas.drawRoundRect(r, dpRaw(12), dpRaw(12), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpRaw(1));
            paint.setColor(applyAlpha(t.stroke, alpha));
            canvas.drawRoundRect(r, dpRaw(12), dpRaw(12), paint);
        }

        float sliderLeft = sx;
        float sliderRight = left + w * 0.62f;
        float baseY = sy + dpRaw(154);
        drawRgbSlider(canvas, "R", pickerR, colorRSliderRect, colorRValueRect, sliderLeft, sliderRight, baseY, 0xFFEF4444, alpha);
        drawRgbSlider(canvas, "G", pickerG, colorGSliderRect, colorGValueRect, sliderLeft, sliderRight, baseY + dpRaw(54), 0xFF22C55E, alpha);
        drawRgbSlider(canvas, "B", pickerB, colorBSliderRect, colorBValueRect, sliderLeft, sliderRight, baseY + dpRaw(108), 0xFF3B82F6, alpha);

        if (editingColorFeature != null && editingColorFeature.type == CONTROL_COLOR) {
            float rightX = left + w * 0.66f;
            colorModeRect.set(rightX, top + dpRaw(95), colorPickerRect.right - dpRaw(30), top + dpRaw(132));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(isColorFeatureGradient(editingColorFeature) ? t.activeSoft : t.softBg, alpha));
            canvas.drawRoundRect(colorModeRect, dpRaw(14), dpRaw(14), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpRaw(1));
            paint.setColor(applyAlpha(isColorFeatureGradient(editingColorFeature) ? t.accent : t.stroke, alpha));
            canvas.drawRoundRect(colorModeRect, dpRaw(14), dpRaw(14), paint);
            textPaint.setFakeBoldText(true);
            textPaint.setTextSize(dpRaw(12));
            textPaint.setColor(applyAlpha(isColorFeatureGradient(editingColorFeature) ? t.accent : t.textDark, alpha));
            drawCenteredText(canvas, isColorFeatureGradient(editingColorFeature) ? (chineseMode ? "渐变色" : "Gradient") : (chineseMode ? "静态色" : "Static"), colorModeRect, textPaint);
            textPaint.setFakeBoldText(false);

            colorStyleRect.set(rightX, colorModeRect.bottom + dpRaw(10), colorPickerRect.right - dpRaw(30), colorModeRect.bottom + dpRaw(45));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(t.softBg, alpha));
            canvas.drawRoundRect(colorStyleRect, dpRaw(13), dpRaw(13), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpRaw(1));
            paint.setColor(applyAlpha(t.stroke, alpha));
            canvas.drawRoundRect(colorStyleRect, dpRaw(13), dpRaw(13), paint);
            textPaint.setFakeBoldText(true);
            textPaint.setTextSize(dpRaw(11));
            textPaint.setColor(applyAlpha(t.textDark, alpha));
            drawCenteredText(canvas, editingColorFeature.gradientStyle == 1 ? (chineseMode ? "经典" : "Classic") : (chineseMode ? "混合" : "Mixed"), colorStyleRect, textPaint);
            textPaint.setFakeBoldText(false);

            colorSpeedSliderRect.set(rightX, colorStyleRect.bottom + dpRaw(16), colorPickerRect.right - dpRaw(30), colorStyleRect.bottom + dpRaw(40));
            textPaint.setTextSize(dpRaw(10));
            textPaint.setColor(applyAlpha(t.textMid, alpha));
            drawText(canvas, (chineseMode ? "渐变速度 " : "Gradient speed ") + (int)(editingColorFeature.gradientSpeed * 100f) + "%", colorSpeedSliderRect.left, colorSpeedSliderRect.top - dpRaw(4), textPaint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpRaw(4));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(applyAlpha(t.stroke, alpha));
            canvas.drawLine(colorSpeedSliderRect.left, colorSpeedSliderRect.centerY(), colorSpeedSliderRect.right, colorSpeedSliderRect.centerY(), paint);
            paint.setColor(applyAlpha(t.accent, alpha));
            float speedFill = colorSpeedSliderRect.left + colorSpeedSliderRect.width() * clamp01((editingColorFeature.gradientSpeed - 1f) / 5f);
            canvas.drawLine(colorSpeedSliderRect.left, colorSpeedSliderRect.centerY(), speedFill, colorSpeedSliderRect.centerY(), paint);
            paint.setStrokeCap(Paint.Cap.BUTT);

            colorDelaySliderRect.set(rightX, colorSpeedSliderRect.bottom + dpRaw(18), colorPickerRect.right - dpRaw(30), colorSpeedSliderRect.bottom + dpRaw(42));
            textPaint.setTextSize(dpRaw(10));
            textPaint.setColor(applyAlpha(t.textMid, alpha));
            drawText(canvas, (chineseMode ? "渐变延迟 " : "Gradient delay ") + gradientDelayMs(editingColorFeature.gradientDelay) + "ms", colorDelaySliderRect.left, colorDelaySliderRect.top - dpRaw(4), textPaint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpRaw(4));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(applyAlpha(t.stroke, alpha));
            canvas.drawLine(colorDelaySliderRect.left, colorDelaySliderRect.centerY(), colorDelaySliderRect.right, colorDelaySliderRect.centerY(), paint);
            paint.setColor(applyAlpha(t.accent, alpha));
            float delayFill = colorDelaySliderRect.left + colorDelaySliderRect.width() * clamp01(editingColorFeature.gradientDelay);
            canvas.drawLine(colorDelaySliderRect.left, colorDelaySliderRect.centerY(), delayFill, colorDelaySliderRect.centerY(), paint);
            paint.setStrokeCap(Paint.Cap.BUTT);

            if (isColorFeatureGradient(editingColorFeature)) {
                colorAddRect.set(rightX, colorDelaySliderRect.bottom + dpRaw(10), rightX + dpRaw(42), colorDelaySliderRect.bottom + dpRaw(44));
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(applyAlpha(t.accent, alpha));
                canvas.drawRoundRect(colorAddRect, dpRaw(13), dpRaw(13), paint);
                textPaint.setFakeBoldText(true);
                textPaint.setTextSize(dpRaw(18));
                textPaint.setColor(applyAlpha(t.panelBg, alpha));
                drawCenteredText(canvas, "+", colorAddRect, textPaint);
                textPaint.setFakeBoldText(false);
                int[] editingColors = getColorFeatureGradientColors(editingColorFeature);
                int count = editingColors == null ? 0 : Math.min(editingColors.length, colorListRects.length);
                for (int i = 0; i < count; i++) {
                    float y = colorAddRect.bottom + dpRaw(10) + i * dpRaw(34);
                    colorListRects[i].set(rightX, y, colorPickerRect.right - dpRaw(70), y + dpRaw(26));
                    colorDeleteRects[i].set(colorPickerRect.right - dpRaw(60), y, colorPickerRect.right - dpRaw(30), y + dpRaw(26));
                    paint.setStyle(Paint.Style.FILL);
                    paint.setShader(null);
                    paint.setColor(editingColors[i]);
                    canvas.drawRoundRect(colorListRects[i], dpRaw(10), dpRaw(10), paint);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(dpRaw(i == pickerGradientIndex ? 2.2f : 1f));
                    paint.setColor(applyAlpha(i == pickerGradientIndex ? t.accent : t.stroke, alpha));
                    canvas.drawRoundRect(colorListRects[i], dpRaw(10), dpRaw(10), paint);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(applyAlpha(t.softBg, alpha));
                    canvas.drawRoundRect(colorDeleteRects[i], dpRaw(10), dpRaw(10), paint);
                    textPaint.setFakeBoldText(true);
                    textPaint.setTextSize(dpRaw(14));
                    textPaint.setColor(applyAlpha(t.textMid, alpha));
                    drawCenteredText(canvas, "-", colorDeleteRects[i], textPaint);
                    textPaint.setFakeBoldText(false);
                }
            }
        }

        colorCancelRect.set(colorPickerRect.right - dpRaw(206), colorPickerRect.bottom - dpRaw(54), colorPickerRect.right - dpRaw(118), colorPickerRect.bottom - dpRaw(20));
        colorOkRect.set(colorPickerRect.right - dpRaw(106), colorPickerRect.bottom - dpRaw(54), colorPickerRect.right - dpRaw(24), colorPickerRect.bottom - dpRaw(20));
        drawDialogButton(canvas, colorCancelRect, chineseMode ? "取消" : "Cancel", false, alpha);
        drawDialogButton(canvas, colorOkRect, chineseMode ? "确定" : "OK", true, alpha);
    }

    private void drawRgbSlider(Canvas canvas, String label, int value, RectF slider, RectF valueRect, float left, float right, float cy, int color, int alpha) {
        ThemePalette t = theme();
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(13));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        drawText(canvas, label, left, cy + dpRaw(5), textPaint);
        slider.set(left + dpRaw(26), cy - dpRaw(12), right - dpRaw(74), cy + dpRaw(12));
        valueRect.set(right - dpRaw(62), cy - dpRaw(18), right, cy + dpRaw(18));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(5));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawLine(slider.left, slider.centerY(), slider.right, slider.centerY(), paint);
        paint.setColor(applyAlpha(color, alpha));
        float fillX = slider.left + slider.width() * (value / 255f);
        canvas.drawLine(slider.left, slider.centerY(), fillX, slider.centerY(), paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStyle(Paint.Style.FILL);
        tempRect.set(fillX - dpRaw(8), slider.centerY() - dpRaw(8), fillX + dpRaw(8), slider.centerY() + dpRaw(8));
        paint.setColor(applyAlpha(t.panelBg, alpha));
        canvas.drawOval(tempRect, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1.4f));
        paint.setColor(applyAlpha(color, alpha));
        canvas.drawOval(tempRect, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(colorInputChannel == ("R".equals(label) ? 1 : "G".equals(label) ? 2 : 3) ? t.activeSoft : t.softBg, alpha));
        canvas.drawRoundRect(valueRect, dpRaw(12), dpRaw(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(t.stroke, alpha));
        canvas.drawRoundRect(valueRect, dpRaw(12), dpRaw(12), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(t.textDark, alpha));
        String shown = colorInputChannel == ("R".equals(label) ? 1 : "G".equals(label) ? 2 : 3) && colorInputBuffer.length() > 0 ? colorInputBuffer : String.valueOf(value);
        drawCenteredText(canvas, shown, valueRect, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private void drawDialogButton(Canvas canvas, RectF b, String label, boolean accent, int alpha) {
        ThemePalette t = theme();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(applyAlpha(accent ? t.accent : t.softBg, alpha));
        canvas.drawRoundRect(b, dpRaw(13), dpRaw(13), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpRaw(1));
        paint.setColor(applyAlpha(accent ? t.accent : t.stroke, alpha));
        canvas.drawRoundRect(b, dpRaw(13), dpRaw(13), paint);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(dpRaw(12));
        textPaint.setColor(applyAlpha(accent ? t.panelBg : t.textDark, alpha));
        drawCenteredText(canvas, label, b, textPaint);
        textPaint.setFakeBoldText(false);
    }

    private boolean handleColorPickerTouch(MotionEvent event, float x, float y) {
        if (event.getAction() != MotionEvent.ACTION_DOWN && event.getAction() != MotionEvent.ACTION_MOVE && event.getAction() != MotionEvent.ACTION_UP) return true;
        if (event.getAction() == MotionEvent.ACTION_MOVE) {
            if (colorRSliderRect.contains(x, y)) { setPickerChannel(1, x); return true; }
            if (colorGSliderRect.contains(x, y)) { setPickerChannel(2, x); return true; }
            if (colorBSliderRect.contains(x, y)) { setPickerChannel(3, x); return true; }
            if (editingColorFeature != null && colorSpeedSliderRect.contains(x, y)) {
                editingColorFeature.gradientSpeed = 1.0f + 5.0f * clamp01((x - colorSpeedSliderRect.left) / Math.max(1f, colorSpeedSliderRect.width()));
                applyFeatureValue(editingColorFeature);
                requestFrame();
                return true;
            }
            if (editingColorFeature != null && colorDelaySliderRect.contains(x, y)) {
                editingColorFeature.gradientDelay = clamp01((x - colorDelaySliderRect.left) / Math.max(1f, colorDelaySliderRect.width()));
                applyFeatureValue(editingColorFeature);
                requestFrame();
                return true;
            }
            return true;
        }
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        if (colorCancelRect.contains(x, y)) {
            closeColorPicker(false);
            return true;
        }
        if (!colorPickerRect.contains(x, y)) {
            return true;
        }
        if (colorOkRect.contains(x, y)) {
            closeColorPicker(true);
            return true;
        }
        for (int i = 0; i < colorSwatchRects.length; i++) {
            if (colorSwatchRects[i].contains(x, y)) {
                setPickerColor(paletteColor(i));
                colorInputChannel = 0;
                updateEditingGradientColorLive();
                requestFrame();
                return true;
            }
        }
        if (colorRSliderRect.contains(x, y)) { setPickerChannel(1, x); return true; }
        if (colorGSliderRect.contains(x, y)) { setPickerChannel(2, x); return true; }
        if (colorBSliderRect.contains(x, y)) { setPickerChannel(3, x); return true; }
        if (colorRValueRect.contains(x, y)) { focusColorInput(1); return true; }
        if (colorGValueRect.contains(x, y)) { focusColorInput(2); return true; }
        if (colorBValueRect.contains(x, y)) { focusColorInput(3); return true; }
        if (editingColorFeature != null && editingColorFeature.type == CONTROL_COLOR) {
            if (colorModeRect.contains(x, y)) {
                toggleEditingColorGradient();
                requestFrame();
                return true;
            }
            if (colorStyleRect.contains(x, y)) {
                editingColorFeature.gradientStyle = editingColorFeature.gradientStyle == 0 ? 1 : 0;
                applyFeatureValue(editingColorFeature);
                requestFrame();
                return true;
            }
            if (colorSpeedSliderRect.contains(x, y)) {
                editingColorFeature.gradientSpeed = 1.0f + 5.0f * clamp01((x - colorSpeedSliderRect.left) / Math.max(1f, colorSpeedSliderRect.width()));
                applyFeatureValue(editingColorFeature);
                requestFrame();
                return true;
            }
            if (colorDelaySliderRect.contains(x, y)) {
                editingColorFeature.gradientDelay = clamp01((x - colorDelaySliderRect.left) / Math.max(1f, colorDelaySliderRect.width()));
                applyFeatureValue(editingColorFeature);
                requestFrame();
                return true;
            }
            if (isColorFeatureGradient(editingColorFeature)) {
                if (colorAddRect.contains(x, y)) {
                    addGradientColor(argb(255, pickerR, pickerG, pickerB));
                    requestFrame();
                    return true;
                }
                int[] editingColors = getColorFeatureGradientColors(editingColorFeature);
                int count = editingColors == null ? 0 : Math.min(editingColors.length, colorListRects.length);
                for (int i = 0; i < count; i++) {
                    if (colorDeleteRects[i].contains(x, y)) {
                        removeGradientColor(i);
                        requestFrame();
                        return true;
                    }
                    if (colorListRects[i].contains(x, y)) {
                        pickerGradientIndex = i;
                        setPickerColor(editingColors[i]);
                        requestFrame();
                        return true;
                    }
                }
            }
        }
        colorInputChannel = 0;
        hideKeyboard();
        requestFrame();
        return true;
    }

    private void openColorPicker(Feature f) {
        editingColorFeature = f;
        backupShortcutBorderGradient = shortcutBorderGradient;
        backupShortcutBorderColor = shortcutBorderColor;
        backupShortcutBorderColors = copyColors(shortcutBorderColors);
        backupEditingColorGradient = f != null && f.colorGradient;
        backupEditingColor = f == null ? 0xFFFFFFFF : f.color;
        backupEditingGradientColors = copyColors(f == null ? null : f.gradientColors);
        backupEditingGradientSpeed = f == null ? 1.0f : f.gradientSpeed;
        backupEditingGradientDelay = f == null ? 1.0f : f.gradientDelay;
        backupEditingGradientStyle = f == null ? 0 : f.gradientStyle;
        ensureFeatureGradientColors(f);
        setPickerColor(getColorFeatureValue(f));
        if (f != null && f.type == CONTROL_COLOR && isColorFeatureGradient(f) && getColorFeatureGradientColors(f) != null && getColorFeatureGradientColors(f).length > 0) {
            int[] colors = getColorFeatureGradientColors(f);
            if (pickerGradientIndex >= colors.length) pickerGradientIndex = 0;
            setPickerColor(colors[pickerGradientIndex]);
        }
        colorInputChannel = 0;
        colorInputBuffer = "";
        colorPickerOpen = true;
        requestFocus();
        requestFrame();
    }

    private void closeColorPicker(boolean save) {
        if (!save && editingColorFeature != null) {
            editingColorFeature.colorGradient = backupEditingColorGradient;
            editingColorFeature.color = backupEditingColor;
            editingColorFeature.gradientColors = copyColors(backupEditingGradientColors);
            editingColorFeature.gradientSpeed = backupEditingGradientSpeed;
            editingColorFeature.gradientDelay = backupEditingGradientDelay;
            editingColorFeature.gradientStyle = backupEditingGradientStyle;
            if (editingColorFeature.role == Role.SHORTCUT_BORDER_COLOR) {
                shortcutBorderGradient = backupShortcutBorderGradient;
                shortcutBorderColor = backupShortcutBorderColor;
                shortcutBorderColors = copyColors(backupShortcutBorderColors);
            }
            applyFeatureValue(editingColorFeature);
        }
        if (save && editingColorFeature != null) {
            int c = argb(255, pickerR, pickerG, pickerB);
            if (isColorFeatureGradient(editingColorFeature)) {
                updateEditingGradientColorLive();
            } else {
                editingColorFeature.color = c;
            }
            applyFeatureValue(editingColorFeature);
        }
        colorPickerOpen = false;
        editingColorFeature = null;
        colorInputChannel = 0;
        colorInputBuffer = "";
        hideKeyboard();
        requestFrame();
    }

    private void setPickerChannel(int channel, float x) {
        RectF r = channel == 1 ? colorRSliderRect : channel == 2 ? colorGSliderRect : colorBSliderRect;
        int v = (int) (255f * clamp01((x - r.left) / Math.max(1f, r.width())) + 0.5f);
        if (channel == 1) pickerR = v;
        else if (channel == 2) pickerG = v;
        else pickerB = v;
        colorInputChannel = 0;
        updateEditingGradientColorLive();
        requestFrame();
    }

    private void focusColorInput(int channel) {
        colorInputChannel = channel;
        colorInputBuffer = "";
        requestFocus();
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        requestFrame();
    }

    private void appendColorInput(CharSequence text) {
        if (text == null) return;
        String raw = text.toString();
        StringBuilder sb = new StringBuilder(colorInputBuffer == null ? "" : colorInputBuffer);
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= '0' && c <= '9' && sb.length() < 3) sb.append(c);
        }
        colorInputBuffer = sb.toString();
        applyColorInputBuffer();
    }

    private void deleteColorInput() {
        if (colorInputBuffer != null && colorInputBuffer.length() > 0) colorInputBuffer = colorInputBuffer.substring(0, colorInputBuffer.length() - 1);
        applyColorInputBuffer();
    }

    private void finishColorInput() {
        applyColorInputBuffer();
        colorInputChannel = 0;
        colorInputBuffer = "";
        hideKeyboard();
        requestFrame();
    }

    private void applyColorInputBuffer() {
        int v = 0;
        try {
            if (colorInputBuffer != null && colorInputBuffer.length() > 0) v = Integer.parseInt(colorInputBuffer);
        } catch (Throwable ignored) { v = 0; }
        if (v > 255) v = 255;
        if (colorInputChannel == 1) pickerR = v;
        else if (colorInputChannel == 2) pickerG = v;
        else if (colorInputChannel == 3) pickerB = v;
        updateEditingGradientColorLive();
        requestFrame();
    }

    private void updateEditingGradientColorLive() {
        if (editingColorFeature != null && editingColorFeature.type == CONTROL_COLOR && isColorFeatureGradient(editingColorFeature)) {
            ensureFeatureGradientColors(editingColorFeature);
            int[] colors = getColorFeatureGradientColors(editingColorFeature);
            if (colors != null && colors.length > 0) {
                if (pickerGradientIndex < 0) pickerGradientIndex = 0;
                if (pickerGradientIndex >= colors.length) pickerGradientIndex = colors.length - 1;
                colors[pickerGradientIndex] = argb(255, pickerR, pickerG, pickerB);
                setColorFeatureGradientColors(editingColorFeature, colors);
                applyFeatureValue(editingColorFeature);
            }
        }
    }

    private void toggleEditingColorGradient() {
        if (editingColorFeature == null || editingColorFeature.type != CONTROL_COLOR) return;
        editingColorFeature.colorGradient = !editingColorFeature.colorGradient;
        if (editingColorFeature.colorGradient) ensureFeatureGradientColors(editingColorFeature);
        applyFeatureValue(editingColorFeature);
    }

    private void ensureFeatureGradientColors(Feature f) {
        if (f == null || f.type != CONTROL_COLOR) return;
        if (f.gradientColors == null || f.gradientColors.length < 2) {
            int base = getColorFeatureValue(f);
            int now = argb(255, pickerR, pickerG, pickerB);
            if (now == 0xFF000000 && base != 0xFF000000) now = base;
            f.gradientColors = new int[]{base, now};
        }
    }

    private boolean isColorFeatureGradient(Feature f) {
        return f != null && f.type == CONTROL_COLOR && f.colorGradient;
    }

    private int[] getColorFeatureGradientColors(Feature f) {
        if (f == null || f.type != CONTROL_COLOR) return null;
        return f.gradientColors;
    }

    private void setColorFeatureGradientColors(Feature f, int[] colors) {
        if (f == null || f.type != CONTROL_COLOR) return;
        f.gradientColors = copyColors(colors);
    }

    private void setPickerColor(int color) {
        pickerR = (color >> 16) & 255;
        pickerG = (color >> 8) & 255;
        pickerB = color & 255;
    }

    private int[] copyColors(int[] src) {
        if (src == null) return new int[0];
        int[] out = new int[src.length];
        for (int i = 0; i < src.length; i++) out[i] = src[i];
        return out;
    }

    private void addGradientColor(int color) {
        if (editingColorFeature == null || editingColorFeature.type != CONTROL_COLOR) return;
        ensureFeatureGradientColors(editingColorFeature);
        int[] colors = getColorFeatureGradientColors(editingColorFeature);
        if (colors == null) colors = new int[]{color};
        if (colors.length >= colorListRects.length) return;
        int[] next = new int[colors.length + 1];
        for (int i = 0; i < colors.length; i++) next[i] = colors[i];
        next[next.length - 1] = color;
        setColorFeatureGradientColors(editingColorFeature, next);
        pickerGradientIndex = next.length - 1;
        applyFeatureValue(editingColorFeature);
    }

    private void removeGradientColor(int index) {
        if (editingColorFeature == null || editingColorFeature.type != CONTROL_COLOR) return;
        int[] colors = getColorFeatureGradientColors(editingColorFeature);
        if (colors == null || colors.length <= 2 || index < 0 || index >= colors.length) return;
        int[] next = new int[colors.length - 1];
        int p = 0;
        for (int i = 0; i < colors.length; i++) if (i != index) next[p++] = colors[i];
        setColorFeatureGradientColors(editingColorFeature, next);
        if (pickerGradientIndex >= next.length) pickerGradientIndex = next.length - 1;
        setPickerColor(next[pickerGradientIndex]);
        applyFeatureValue(editingColorFeature);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private int paletteColor(int i) {
        int[] colors = new int[]{
                0xFFFFFFFF, 0xFF000000, 0xFFEF4444, 0xFFF97316, 0xFFF59E0B, 0xFF22C55E, 0xFF06B6D4, 0xFF3B82F6,
                0xFF8B5CF6, 0xFFEC4899, 0xFF64748B, 0xFF94A3B8, 0xFFFEE2E2, 0xFFFFEDD5, 0xFFFEF3C7, 0xFFDCFCE7,
                0xFFCFFAFE, 0xFFDBEAFE, 0xFFEDE9FE, 0xFFFCE7F3, 0xFF111827, 0xFF2563EB, 0xFF059669, 0xFFDC2626
        };
        if (i < 0) i = 0;
        if (i >= colors.length) i = colors.length - 1;
        return colors[i];
    }

    @Override
    public boolean onCheckIsTextEditor() {
        return musicSearchFocused || musicNameFocused || pendingAddNameFocused || colorInputChannel != 0;
    }

    @Override
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        if (colorInputChannel != 0) {
            outAttrs.inputType = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;
            outAttrs.imeOptions = EditorInfo.IME_ACTION_DONE;
        } else {
            outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
            outAttrs.imeOptions = (musicNameFocused || pendingAddNameFocused) ? EditorInfo.IME_ACTION_DONE : EditorInfo.IME_ACTION_SEARCH;
        }
        return new BaseInputConnection(this, false) {
            @Override
            public boolean commitText(CharSequence text, int newCursorPosition) {
                if (colorInputChannel != 0) {
                    appendColorInput(text);
                } else if (pendingAddNameFocused) {
                    appendPendingAddName(text);
                } else if (musicNameFocused) {
                    appendMusicName(text);
                } else {
                    appendMusicQuery(text);
                }
                return true;
            }

            @Override
            public boolean deleteSurroundingText(int beforeLength, int afterLength) {
                if (colorInputChannel != 0) deleteColorInput();
                else if (pendingAddNameFocused) deletePendingAddName();
                else if (musicNameFocused) deleteMusicName();
                else deleteMusicQuery();
                return true;
            }

            @Override
            public boolean performEditorAction(int editorAction) {
                if (colorInputChannel != 0) {
                    finishColorInput();
                    return true;
                }
                if (pendingAddNameFocused && editorAction == EditorInfo.IME_ACTION_DONE) {
                    deactivatePendingAddNameInput();
                    return true;
                }
                if (musicNameFocused && editorAction == EditorInfo.IME_ACTION_DONE) {
                    deactivateMusicNameInput();
                    return true;
                }
                if (editorAction == EditorInfo.IME_ACTION_SEARCH || editorAction == EditorInfo.IME_ACTION_DONE) {
                    performMusicSearch();
                    return true;
                }
                return super.performEditorAction(editorAction);
            }
        };
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (colorInputChannel != 0) {
            if (keyCode == KeyEvent.KEYCODE_DEL) {
                deleteColorInput();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                finishColorInput();
                return true;
            }
        }
        if (pendingAddNameFocused) {
            if (keyCode == KeyEvent.KEYCODE_DEL) {
                deletePendingAddName();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                deactivatePendingAddNameInput();
                return true;
            }
        }
        if (musicNameFocused) {
            if (keyCode == KeyEvent.KEYCODE_DEL) {
                deleteMusicName();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                deactivateMusicNameInput();
                return true;
            }
        }
        if (musicSearchFocused) {
            if (keyCode == KeyEvent.KEYCODE_DEL) {
                deleteMusicQuery();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                performMusicSearch();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    /**
     * Central touch dispatcher.
     *
     * Priority is important: modal popups consume touches first, then floating
     * windows, shortcuts, panel controls and finally panel dragging. This keeps
     * debug sliders from accidentally moving the whole panel.
     */
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        if (transitionActive) return true;
        if (colorPickerOpen) return handleColorPickerTouch(event, x, y);
        if (isThemeLocked()) return handleThemeLockedTouch(event, x, y);
        if (handleLogTouch(event, x, y)) return true;
        if (handleArrayListTouch(event, x, y)) return true;
        if (handleMusicTouch(event, x, y)) return true;
        if (handleShortcutTouch(event, x, y)) return true;

        // In injected overlay mode this view should not block touches outside UI elements.
        // In standalone APK test mode it consumes outside touches to keep focus stable.
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            boolean insidePanel = panelVisible && panelProgress > 0.85f && panelRect.contains(x, y);
            boolean insideResize = panelVisible && panelProgress > 0.85f && hitResizeBorder(x, y) != 0;
            boolean insideBall = hitBall(x, y);
            boolean insideShortcut = hitAnyShortcut(x, y) != null;
            boolean insideEditableHint = hintPositionEdit && hintActive && hitHint(x, y);
            boolean insideLog = logWindowEnabled && logWindowRect.contains(x, y);
            boolean insideArrayList = arrayListEnabled && arrayListRect.contains(x, y);
            if (!insidePanel && !insideResize && !insideBall && !insideShortcut && !insideEditableHint && !insideLog && !insideArrayList) {
                return standaloneTestMode;
            }
        }

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                pressedFeatureIndex = -1;
                pressedFeature = null;
                activeSliderFeature = null;
                draggingSlider = false;
                sectionScrollPositions[selectedSection] = scrollY;
                draggingScroll = false;
                maybeScrolling = false;

                if (hitBall(x, y)) {
                    ballDown = true;
                    ballLongPressed = false;
                    ballDragging = false;
                    ballDownX = x;
                    ballDownY = y;
                    ballStartX = ballX;
                    ballStartY = ballY;
                    postDelayed(ballLongPress, 260);
                    return true;
                }

                if (panelVisible && panelProgress > 0.85f) {
                    int resizeMode = hitResizeBorder(x, y);
                    if (resizeMode != 0) {
                        resizingPanel = true;
                        activeResizeMode = resizeMode;
                        resizeDownX = x;
                        resizeDownY = y;
                        resizeStartL = panelRect.left;
                        resizeStartT = panelRect.top;
                        resizeStartR = panelRect.right;
                        resizeStartB = panelRect.bottom;
                        return true;
                    }
                }

                if (hintPositionEdit && hintActive && hitHint(x, y)) {
                    draggingHint = true;
                    hintDownX = x;
                    hintDownY = y;
                    hintStartX = hintX;
                    hintStartY = hintY;
                    return true;
                }

                if (!panelVisible || panelProgress < 0.85f) return standaloneTestMode;

                if (panelRect.contains(x, y) && isEmptyPanelDragArea(x, y)) {
                    draggingPanel = true;
                    panelDragDownX = x;
                    panelDragDownY = y;
                    panelDragStartL = panelRect.left;
                    panelDragStartT = panelRect.top;
                    panelDragStartR = panelRect.right;
                    panelDragStartB = panelRect.bottom;
                    return true;
                }

                activeSliderFeature = welcomeVisible ? null : findSliderAt(x, y);
                if (activeSliderFeature != null) {
                    draggingSlider = true;
                    updateSlider(activeSliderFeature, x, true);
                    return true;
                }

                Feature f = findMainFeatureAt(x, y);
                if (f != null) {
                    pressedFeature = f;
                    pressedFeatureIndex = indexOfFeature(f);
                    animatePress(f, 1f);
                }

                if (!welcomeVisible && featureListRect.contains(x, y)) {
                    maybeScrolling = true;
                    scrollStartY = scrollY;
                    scrollDownY = y;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (ballDown) {
                    float dx = x - ballDownX;
                    float dy = y - ballDownY;
                    if (Math.abs(dx) > dpRaw(6) || Math.abs(dy) > dpRaw(6)) removeCallbacks(ballLongPress);
                    if (ballLongPressed) {
                        ballDragging = true;
                        ballX = ballStartX + dx;
                        ballY = ballStartY + dy;
                        clampBall();
                        requestFrame();
                    }
                    return true;
                }
                if (resizingPanel) {
                    resizePanelTo(x, y);
                    return true;
                }
                if (draggingPanel) {
                    float dx = x - panelDragDownX;
                    float dy = y - panelDragDownY;
                    panelRect.set(panelDragStartL + dx, panelDragStartT + dy, panelDragStartR + dx, panelDragStartB + dy);
                    constrainPanelRect();
                    rebuildLayoutCache();
                    requestFrame();
                    return true;
                }
                if (draggingHint) {
                    hintX = hintStartX + x - hintDownX;
                    hintY = hintStartY + y - hintDownY;
                    clampHint();
                    requestFrame();
                    return true;
                }
                if (draggingSlider && activeSliderFeature != null) {
                    updateSlider(activeSliderFeature, x, true);
                    return true;
                }
                if (maybeScrolling && featureListRect.contains(downX, downY)) {
                    float dy = y - scrollDownY;
                    if (!draggingScroll && Math.abs(dy) > dpRaw(8)) {
                        draggingScroll = true;
                        if (pressedFeature != null) animatePress(pressedFeature, 0f);
                    }
                    if (draggingScroll) {
                        float next = scrollStartY - dy * scrollSpeed;
                        if (next < 0f) next *= scrollDamping;
                        if (next > maxScrollY) next = maxScrollY + (next - maxScrollY) * scrollDamping;
                        scrollY = next;
                        clampScroll();
                        sectionScrollPositions[selectedSection] = scrollY;
                        layoutFeatureCards();
                        showScrollBar();
                        requestFrame();
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(ballLongPress);
                if (ballDown) {
                    ballDown = false;
                    animateBallScale(1f);
                    if (!ballDragging && !ballLongPressed && dist(x, y, ballDownX, ballDownY) < dpRaw(8)) {
                        animateBallTap();
                        togglePanel();
                    } else if (ballSnapEdge) {
                        snapBallToEdge();
                    }
                    return true;
                }
                if (resizingPanel) {
                    resizingPanel = false;
                    activeResizeMode = 0;
                    rebuildLayoutCache();
                    savePanelBounds();
                    requestFrame();
                    return true;
                }
                if (draggingPanel) {
                    draggingPanel = false;
                    savePanelBounds();
                    requestFrame();
                    return true;
                }
                if (draggingHint) {
                    draggingHint = false;
                    clampHint();
                    return true;
                }
                if (draggingSlider) {
                    draggingSlider = false;
                    activeSliderFeature = null;
                    return true;
                }
                if (pressedFeature != null) animatePress(pressedFeature, 0f);
                if (!draggingScroll && dist(x, y, downX, downY) < dpRaw(8)) handleTap(x, y);
                sectionScrollPositions[selectedSection] = scrollY;
                draggingScroll = false;
                maybeScrolling = false;
                scrollBarVisibleUntil = SystemClock.uptimeMillis() + 700L;
                return true;
        }
        return true;
    }

    private boolean handleThemeLockedTouch(MotionEvent event, float x, float y) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            int option = hitThemeOption(x, y);
            if (option >= 0) selectTheme(option);
        }
        return true;
    }

    private void handleTap(float x, float y) {
        if (closeRect.contains(x, y)) {
            togglePanel();
            return;
        }
        for (int i = 0; i < SECTION_COUNT; i++) {
            if (sectionRects[i].contains(x, y)) {
                if (welcomeVisible) welcomeVisible = false;
                switchSection(i);
                return;
            }
        }
        if (welcomeVisible) return;
        if (!featureListRect.contains(x, y)) return;
        Section section = sections[selectedSection];
        for (int i = 0; i < section.features.length; i++) {
            Feature f = section.features[i];
            if (!f.cardRect.contains(x, y)) continue;
            if (handleSettingTap(f, x, y)) return;
            if (f.mainRect.contains(x, y)) {
                handleMainFeatureTap(f, x, y);
                return;
            }
        }
    }

    private boolean handleSettingTap(Feature host, float x, float y) {
        if (host.settings == null || host.debugProgress <= 0.001f) return false;
        for (int i = 0; i < host.settings.length; i++) {
            Feature s = host.settings[i];
            if (!s.cardRect.contains(x, y)) continue;
            if (s.type == CONTROL_SWITCH) {
                if (s.controlRect.contains(x, y) || s.cardRect.contains(x, y)) toggleSwitch(s);
                return true;
            }
            if (s.type == CONTROL_SLIDER) {
                updateSlider(s, x, false);
                return true;
            }
            if (s.type == CONTROL_SELECT) {
                if (s.controlRect.contains(x, y)) cycleSelect(s);
                return true;
            }
            if (s.type == CONTROL_COLOR) {
                if (s.controlRect.contains(x, y)) openColorPicker(s);
                return true;
            }
            if (s.type == CONTROL_ACTION) {
                if (s.controlRect.contains(x, y)) performAction(s);
                return true;
            }
        }
        return false;
    }

    private void handleMainFeatureTap(Feature f, float x, float y) {
        if (f.type == CONTROL_NONE) return;
        if (f.role == Role.THEME) {
            if (f.controlRect.contains(x, y)) toggleThemeDropdown();
            return;
        }
        if (f.type == CONTROL_SELECT) {
            if (f.controlRect.contains(x, y)) cycleSelect(f);
            return;
        }
        if (f.type == CONTROL_SWITCH) {
            if (f.controlRect.contains(x, y)) {
                toggleSwitch(f);
                return;
            }
            if (f.debuggable) toggleDebug(f);
            return;
        }
        if (f.type == CONTROL_GROUP) {
            toggleDebug(f);
        } else if (f.type == CONTROL_ACTION) {
            performAction(f);
        }
    }

    private void togglePanel() {
        if (transitionActive) return;
        if (!animationsEnabled) {
            panelVisible = !(panelVisible || panelProgress > 0.05f);
            panelProgress = panelVisible ? 1f : 0f;
            transitionActive = false;
            transitionMode = 0;
            rebuildLayoutCache();
            requestFrame();
            return;
        }
        if (panelVisible || panelProgress > 0.05f) {
            if (isParticleTransition()) startPanelToBallTransition();
            else startSimplePanelClose();
        } else {
            if (isParticleTransition()) startBallToPanelTransition();
            else startSimplePanelOpen();
        }
    }


    private void startSimplePanelOpen() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        savedBallX = ballX;
        savedBallY = ballY;
        savedBallPositionReady = true;
        closeThemeDropdown();
        cancel(panelAnimator);
        cancel(transitionAnimator);
        transitionActive = false;
        transitionMode = 0;
        panelVisible = true;
        rebuildLayoutCache();
        panelAnimator = ValueAnimator.ofFloat(panelProgress, 1f);
        panelAnimator.setDuration(getPanelDuration());
        panelAnimator.setInterpolator(ease);
        panelAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                panelProgress = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        panelAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                panelProgress = 1f;
                panelVisible = true;
                rebuildLayoutCache();
                requestFrame();
            }
        });
        panelAnimator.start();
    }

    private void startSimplePanelClose() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        if (!savedBallPositionReady) {
            savedBallX = ballX;
            savedBallY = ballY;
            savedBallPositionReady = true;
        }
        closeThemeDropdown();
        cancel(panelAnimator);
        cancel(transitionAnimator);
        transitionActive = false;
        transitionMode = 0;
        panelVisible = true;
        panelAnimator = ValueAnimator.ofFloat(panelProgress, 0f);
        panelAnimator.setDuration(getPanelDuration());
        panelAnimator.setInterpolator(ease);
        panelAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                panelProgress = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        panelAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                ballX = savedBallX;
                ballY = savedBallY;
                clampBall();
                ballScale = 1f;
                panelProgress = 0f;
                panelVisible = false;
                rebuildLayoutCache();
                requestFrame();
            }
        });
        panelAnimator.start();
    }

    private void startBallToPanelTransition() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        savedBallX = ballX;
        savedBallY = ballY;
        savedBallPositionReady = true;
        closeThemeDropdown();
        cancel(panelAnimator);
        cancel(transitionAnimator);
        panelVisible = true;
        panelProgress = 0f;
        transitionActive = true;
        transitionMode = TRANSITION_OPEN;
        transitionProgress = 0f;
        rebuildLayoutCache();
        buildTransitionParticles(TRANSITION_OPEN);
        transitionAnimator = ValueAnimator.ofFloat(0f, 1f);
        transitionAnimator.setDuration(getTransitionDuration());
        transitionAnimator.setInterpolator(ease);
        transitionAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                transitionProgress = (Float) animation.getAnimatedValue();
                panelProgress = naturalEase(clamp01((transitionProgress - 0.12f) / 0.82f));
                requestFrame();
            }
        });
        transitionAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                transitionProgress = 1f;
                panelProgress = 1f;
                panelVisible = true;
                transitionActive = false;
                transitionMode = 0;
                rebuildLayoutCache();
                requestFrame();
            }
        });
        transitionAnimator.start();
    }

    private void startPanelToBallTransition() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        if (!savedBallPositionReady) {
            savedBallX = ballX;
            savedBallY = ballY;
            savedBallPositionReady = true;
        }
        closeThemeDropdown();
        cancel(panelAnimator);
        cancel(transitionAnimator);
        panelVisible = true;
        panelProgress = Math.max(panelProgress, 1f);
        transitionActive = true;
        transitionMode = TRANSITION_CLOSE;
        transitionProgress = 0f;
        rebuildLayoutCache();
        buildTransitionParticles(TRANSITION_CLOSE);
        transitionAnimator = ValueAnimator.ofFloat(0f, 1f);
        transitionAnimator.setDuration(getTransitionDuration());
        transitionAnimator.setInterpolator(ease);
        transitionAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                transitionProgress = (Float) animation.getAnimatedValue();
                panelProgress = 1f - naturalEase(clamp01((transitionProgress - 0.02f) / 0.78f));
                requestFrame();
            }
        });
        transitionAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                ballX = savedBallX;
                ballY = savedBallY;
                clampBall();
                ballScale = 1f;
                transitionProgress = 1f;
                panelProgress = 0f;
                panelVisible = false;
                transitionActive = false;
                transitionMode = 0;
                rebuildLayoutCache();
                requestFrame();
            }
        });
        transitionAnimator.start();
    }

    private void buildTransitionParticles(int mode) {
        ThemePalette t = theme();
        int[] colors = new int[]{t.accent, t.textDark, t.textMid, t.stroke, t.activeSoft, t.panelBg};
        float ballCx = (savedBallPositionReady ? savedBallX : ballX) + ballSize / 2f;
        float ballCy = (savedBallPositionReady ? savedBallY : ballY) + ballSize / 2f;
        float ballR = Math.max(6f, ballSize * 0.42f);
        float spreadMin = ballR + dpRaw(18);
        float spreadMax = ballR + dpRaw(118);

        random.setSeed(20260602L + mode * 9173L + themeIndex * 31L);

        for (int i = 0; i < transitionParticles.length; i++) {
            Particle p = transitionParticles[i];
            float[] panelPoint = randomPanelParticlePoint(i);

            double innerAngle = random.nextDouble() * Math.PI * 2.0;
            float innerR = (float) Math.sqrt(random.nextFloat()) * ballR;
            float bx = ballCx + (float) Math.cos(innerAngle) * innerR;
            float by = ballCy + (float) Math.sin(innerAngle) * innerR;

            double spreadAngle;
            if (mode == TRANSITION_OPEN) {
                // First motion is a true burst from the floating ball.
                spreadAngle = innerAngle + (random.nextFloat() - 0.5f) * 0.72f;
            } else {
                // Closing collects particles around the old ball position from many directions.
                spreadAngle = Math.atan2(panelPoint[1] - ballCy, panelPoint[0] - ballCx) + Math.PI + (random.nextFloat() - 0.5f) * 1.25f;
            }
            float spreadR = spreadMin + random.nextFloat() * spreadMax;
            float scatterX = ballCx + (float) Math.cos(spreadAngle) * spreadR;
            float scatterY = ballCy + (float) Math.sin(spreadAngle) * spreadR;

            if (mode == TRANSITION_OPEN) {
                p.sx = bx;
                p.sy = by;
                p.mx = scatterX;
                p.my = scatterY;
                p.ex = panelPoint[0];
                p.ey = panelPoint[1];
                buildBezierControls(p, p.mx, p.my, p.ex, p.ey, i);
            } else {
                p.sx = panelPoint[0];
                p.sy = panelPoint[1];
                p.mx = scatterX;
                p.my = scatterY;
                p.ex = bx;
                p.ey = by;
                buildBezierControls(p, p.sx, p.sy, p.mx, p.my, i);
            }

            float wobble = dpRaw(16f + random.nextFloat() * 44f);
            double wobbleAngle = spreadAngle + Math.PI / 2.0 + (random.nextFloat() - 0.5f) * 0.9f;
            p.wobbleX = (float) Math.cos(wobbleAngle) * wobble;
            p.wobbleY = (float) Math.sin(wobbleAngle) * wobble;
            p.size = dpRaw(1.15f + random.nextFloat() * 2.45f);
            if (mode == TRANSITION_CLOSE) {
                // Particles do not reach the ball at the same moment: some enter
                // quickly, others drift in later for a more natural closing effect.
                p.delay = random.nextFloat() * 0.18f;
                float arrival = (float) Math.pow(random.nextFloat(), 0.72f);
                p.endProgress = 0.46f + arrival * 0.50f;
                if (p.endProgress <= p.delay + 0.22f) p.endProgress = p.delay + 0.22f;
                if (p.endProgress > 0.98f) p.endProgress = 0.98f;
            } else {
                p.delay = random.nextFloat() * 0.105f;
                p.endProgress = 1f;
            }
            p.color = colors[i % colors.length];
        }
    }

    private void buildBezierControls(Particle p, float sx, float sy, float ex, float ey, int index) {
        float dx = ex - sx;
        float dy = ey - sy;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) len = 1f;
        float nx = -dy / len;
        float ny = dx / len;
        float wave = ((index & 1) == 0 ? 1f : -1f) * (dpRaw(38f) + random.nextFloat() * dpRaw(92f));
        float bias = 0.22f + random.nextFloat() * 0.18f;
        p.c1x = sx + dx * bias + nx * wave;
        p.c1y = sy + dy * bias + ny * wave;
        p.c2x = sx + dx * (0.72f + random.nextFloat() * 0.14f) - nx * wave * (0.45f + random.nextFloat() * 0.28f);
        p.c2y = sy + dy * (0.72f + random.nextFloat() * 0.14f) - ny * wave * (0.45f + random.nextFloat() * 0.28f);
    }

    private float[] randomPanelParticlePoint(int index) {
        float x;
        float y;
        int bucket = index % 7;
        if (bucket == 0) {
            x = panelRect.left + random.nextFloat() * panelRect.width();
            y = panelRect.top + random.nextFloat() * dp(64);
        } else if (bucket == 1) {
            x = panelRect.left + random.nextFloat() * panelRect.width();
            y = panelRect.bottom - random.nextFloat() * dp(64);
        } else if (bucket == 2) {
            x = panelRect.left + random.nextFloat() * dp(250);
            y = panelRect.top + random.nextFloat() * panelRect.height();
        } else if (bucket == 3) {
            x = featureListRect.left + random.nextFloat() * Math.max(1f, featureListRect.width());
            y = featureListRect.top + random.nextFloat() * Math.max(1f, featureListRect.height());
        } else if (bucket == 4) {
            x = searchRect.left + random.nextFloat() * Math.max(1f, searchRect.width());
            y = searchRect.top + random.nextFloat() * Math.max(1f, searchRect.height());
        } else if (bucket == 5) {
            x = closeRect.left + random.nextFloat() * Math.max(1f, closeRect.width());
            y = closeRect.top + random.nextFloat() * Math.max(1f, closeRect.height());
        } else {
            x = panelRect.left + random.nextFloat() * panelRect.width();
            y = panelRect.top + random.nextFloat() * panelRect.height();
        }
        return new float[]{x, y};
    }

    private void drawTransitionParticles(Canvas canvas) {
        if (!transitionActive) return;
        float raw = transitionProgress;
        float panelAlpha;
        if (transitionMode == TRANSITION_OPEN) {
            panelAlpha = clamp01((raw - 0.14f) / 0.80f);
        } else {
            panelAlpha = 1f - clamp01((raw - 0.03f) / 0.76f);
        }
        for (int i = 0; i < transitionParticles.length; i++) {
            Particle p = transitionParticles[i];
            float local;
            if (transitionMode == TRANSITION_CLOSE) {
                float end = p.endProgress <= p.delay ? 1f : p.endProgress;
                local = (raw - p.delay) / (end - p.delay);
                if (raw > end + 0.035f) continue;
            } else {
                local = (raw - p.delay) / (1f - p.delay);
            }
            local = clamp01(local);

            float x;
            float y;
            if (transitionMode == TRANSITION_OPEN) {
                if (local < 0.25f) {
                    float t = naturalEase(local / 0.25f);
                    float wave = (float) Math.sin(t * Math.PI);
                    x = lerp(p.sx, p.mx, t) + p.wobbleX * wave;
                    y = lerp(p.sy, p.my, t) + p.wobbleY * wave;
                } else {
                    float t = naturalEase((local - 0.25f) / 0.75f);
                    x = cubic(p.mx, p.c1x, p.c2x, p.ex, t);
                    y = cubic(p.my, p.c1y, p.c2y, p.ey, t);
                }
            } else {
                if (local < 0.72f) {
                    float t = naturalEase(local / 0.72f);
                    x = cubic(p.sx, p.c1x, p.c2x, p.mx, t);
                    y = cubic(p.sy, p.c1y, p.c2y, p.my, t);
                } else {
                    float t = naturalEase((local - 0.72f) / 0.28f);
                    float wave = (float) Math.sin(t * Math.PI);
                    x = lerp(p.mx, p.ex, t) + p.wobbleX * (1f - t) * 0.42f * wave;
                    y = lerp(p.my, p.ey, t) + p.wobbleY * (1f - t) * 0.42f * wave;
                }
            }

            float pulse = 0.42f + 0.58f * (float) Math.sin(Math.PI * clamp01(local));
            int a = (int) (230f * pulse);
            if (transitionMode == TRANSITION_OPEN) {
                a = (int) (a * (1f - clamp01((raw - 0.92f) / 0.08f) * panelAlpha));
            } else {
                // Fade each particle into the ball near its own arrival time.
                float enterFade = 1f - naturalEase(clamp01((local - 0.82f) / 0.18f));
                a = (int) (a * enterFade);
                if (raw < 0.08f) a = (int) (a * clamp01(raw / 0.08f));
            }
            if (a <= 0) continue;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(applyAlpha(p.color, a));
            canvas.drawCircle(x, y, p.size * (0.78f + pulse * 0.55f), paint);
        }
    }

    private void switchSection(final int index) {
        if (index < 0 || index >= SECTION_COUNT) return;
        closeThemeDropdown();
        sectionScrollPositions[selectedSection] = scrollY;
        if (index == selectedSection && !welcomeVisible) return;
        previousSection = selectedSection;
        selectedSection = index;
        scrollY = sectionScrollPositions[selectedSection];
        sectionProgress = animationsEnabled ? 0f : 1f;
        contentProgress = animationsEnabled ? 0f : 1f;
        cancel(sectionAnimator);
        cancel(contentAnimator);
        if (!animationsEnabled) {
            rebuildLayoutCache();
            requestFrame();
            return;
        }
        sectionAnimator = ValueAnimator.ofFloat(0f, 1f);
        sectionAnimator.setDuration(getSectionDuration());
        sectionAnimator.setInterpolator(ease);
        sectionAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                sectionProgress = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        sectionAnimator.start();
        contentAnimator = ValueAnimator.ofFloat(0f, 1f);
        contentAnimator.setDuration(getSectionDuration() + 40);
        contentAnimator.setInterpolator(ease);
        contentAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                contentProgress = (Float) animation.getAnimatedValue();
                rebuildLayoutCache();
                requestFrame();
            }
        });
        contentAnimator.start();
        rebuildLayoutCache();
    }

    private void toggleDebug(final Feature f) {
        if (f.settings == null || f.settings.length == 0) return;
        f.debugOpen = !f.debugOpen;
        cancel(f.debugAnimator);
        if (!animationsEnabled) {
            f.debugProgress = f.debugOpen ? 1f : 0f;
            rebuildLayoutCache();
            showScrollBar();
            requestFrame();
            return;
        }
        f.debugAnimator = ValueAnimator.ofFloat(f.debugProgress, f.debugOpen ? 1f : 0f);
        f.debugAnimator.setDuration(getDebugDuration());
        f.debugAnimator.setInterpolator(ease);
        f.debugAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                f.debugProgress = (Float) animation.getAnimatedValue();
                rebuildLayoutCache();
                showScrollBar();
                requestFrame();
            }
        });
        f.debugAnimator.start();
    }

    private void toggleThemeDropdown() {
        themeDropdownOpen = !themeDropdownOpen;
        cancel(themeAnimator);
        if (!animationsEnabled) {
            themeDropdownProgress = themeDropdownOpen ? 1f : 0f;
            requestFrame();
            return;
        }
        themeAnimator = ValueAnimator.ofFloat(themeDropdownProgress, themeDropdownOpen ? 1f : 0f);
        themeAnimator.setDuration(getDebugDuration());
        themeAnimator.setInterpolator(ease);
        themeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                themeDropdownProgress = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        themeAnimator.start();
    }

    private void closeThemeDropdown() {
        if (!themeDropdownOpen && themeDropdownProgress <= 0.001f) return;
        themeDropdownOpen = false;
        cancel(themeAnimator);
        if (!animationsEnabled) {
            themeDropdownProgress = themeDropdownOpen ? 1f : 0f;
            requestFrame();
            return;
        }
        themeAnimator = ValueAnimator.ofFloat(themeDropdownProgress, 0f);
        themeAnimator.setDuration(180);
        themeAnimator.setInterpolator(ease);
        themeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                themeDropdownProgress = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        themeAnimator.start();
    }

    private void selectTheme(int index) {
        if (index < 0 || index >= themes.length) return;
        themeIndex = index;
        Feature f = getThemeFeature();
        if (f != null) f.optionIndex = index;
        try { prefs().edit().putInt("theme_index", themeIndex).apply(); } catch (Exception ignored) { }
        rebuildLayoutCache();
        closeThemeDropdown();
    }

    private void installShortcutSettings() {
        for (int sectionIndex = 0; sectionIndex < SECTION_COUNT; sectionIndex++) {
            Section section = sections[sectionIndex];
            if (section == null || section.features == null) continue;
            for (int i = 0; i < section.features.length; i++) {
                Feature f = section.features[i];
                if (f == null || f.type != CONTROL_SWITCH) continue;
                f.debuggable = true;
                if (hasShortcutSetting(f)) continue;
                String shortcutNameCn = (f.nameCn != null ? f.nameCn : f.name) + " 快捷键";
                Feature shortcut = Feature.switcher(f.name + " shortcut", "Floating Shortcut", false,
                        shortcutNameCn, "悬浮快捷键", Role.SHORTCUT_ENABLE);
                shortcut.isSettingOnlyForNoToast = true;
                shortcut.shortcutTarget = f;
                f.settings = appendSettingFirst(f.settings, shortcut);
            }
        }
    }

    private boolean hasShortcutSetting(Feature f) {
        if (f == null || f.settings == null) return false;
        for (int i = 0; i < f.settings.length; i++) {
            Feature setting = f.settings[i];
            if (setting != null && setting.role == Role.SHORTCUT_ENABLE) return true;
        }
        return false;
    }

    private Feature[] appendSettingFirst(Feature[] old, Feature first) {
        int n = old == null ? 0 : old.length;
        Feature[] out = new Feature[n + 1];
        out[0] = first;
        for (int i = 0; i < n; i++) out[i + 1] = old[i];
        return out;
    }

    private void performAction(Feature f) {
        if (f == null) return;
        if (f.role == Role.FONT_IMPORT) requestFontImport();
        else if (f.role == Role.FONT_RESET) resetGlobalFont();
        else if (f.role == Role.LOG_CLEAR) clearRuntimeLogs();
        else if (f.role == Role.LOG_EXPORT) requestLogExport();
        else if (f.role == Role.CONFIG_RESTORE) { resetCustomDebugDefaults(); rebuildLayoutCache(); }
        else if (f.role == Role.CONFIG_RANDOM_THEME) { randomizeRgbTheme(); rebuildLayoutCache(); }
        else if (f.role == Role.CONFIG_SAVE) appendLog("Config saved in memory");
        else if (f.role == Role.CONFIG_LOAD) appendLog("Config loaded from memory");
        appendLog("Action: " + getFeatureTitle(f));
        requestFrame();
    }

    private String getActionButtonText(Feature f) {
        if (f == null) return chineseMode ? "执行" : "Run";
        if (f.role == Role.FONT_IMPORT) return chineseMode ? "导入" : "Import";
        if (f.role == Role.FONT_RESET) return chineseMode ? "恢复" : "Reset";
        if (f.role == Role.LOG_CLEAR) return chineseMode ? "清除" : "Clear";
        if (f.role == Role.LOG_EXPORT) return chineseMode ? "导出" : "Export";
        if (f.role == Role.CONFIG_SAVE) return chineseMode ? "保存" : "Save";
        if (f.role == Role.CONFIG_LOAD) return chineseMode ? "加载" : "Load";
        if (f.role == Role.CONFIG_RESTORE) return chineseMode ? "恢复" : "Restore";
        if (f.role == Role.CONFIG_RANDOM_THEME) return chineseMode ? "随机" : "Random";
        return chineseMode ? "执行" : "Run";
    }

    private void cycleSelect(Feature f) {
        if (f == null || f.options == null || f.options.length == 0) return;
        f.optionIndex++;
        if (f.optionIndex >= f.options.length) f.optionIndex = 0;
        applyFeatureValue(f);
        appendLog("Select: " + getFeatureTitle(f) + " = " + getOptionText(f));
        requestFrame();
    }

    /**
     * Toggles a switch Feature and triggers side effects.
     *
     * All switch state changes should pass through this function so animation,
     * logging, ArrayList refresh and feature-hint behavior remain consistent.
     */
    private void toggleSwitch(final Feature f) {
        f.enabled = !f.enabled;
        applyFeatureValue(f);
        markArrayListDirty();
        cancel(f.animator);
        f.animator = ValueAnimator.ofFloat(f.anim, f.enabled ? 1f : 0f);
        f.animator.setDuration(360);
        f.animator.setInterpolator(ease);
        f.animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                f.anim = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        f.animator.start();
        appendLog("Switch: " + getFeatureTitle(f) + " -> " + (f.enabled ? "ON" : "OFF"));
        if (switchHintEnabled && shouldShowSwitchHintFor(f)) showHint(getFeatureTitle(f), f.enabled);
    }

    private boolean shouldShowSwitchHintFor(Feature f) {
        if (f == null) return false;
        if (!f.isSettingOnlyForNoToast) return true;
        return hintShowDebugFeatures && f.role != Role.HINT_DEBUG_TOASTS;
    }

    private void updateSlider(final Feature f, float x, boolean immediate) {
        float v = (x - f.controlRect.left) / Math.max(1f, f.controlRect.width());
        if (v < 0f) v = 0f;
        if (v > 1f) v = 1f;
        f.value = v;
        applyFeatureValue(f);
        if (immediate) {
            f.displayValue = v;
            rebuildLayoutCache();
            requestFrame();
            return;
        }
        cancel(sliderAnimator);
        sliderAnimator = ValueAnimator.ofFloat(f.displayValue, v);
        sliderAnimator.setDuration(300);
        sliderAnimator.setInterpolator(ease);
        sliderAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                f.displayValue = (Float) animation.getAnimatedValue();
                applyFeatureValue(f);
                rebuildLayoutCache();
                requestFrame();
            }
        });
        sliderAnimator.start();
    }

    private void applyFeatureValue(Feature f) {
        if (f.role == Role.CHINESE) chineseMode = f.enabled;
        else if (f.role == Role.SWITCH_HINT) switchHintEnabled = f.enabled;
        else if (f.role == Role.HINT_STYLE) {
            hintStyle = f.optionIndex;
            if (hintPositionReady) clampHint();
        }
        else if (f.role == Role.HINT_OPACITY) hintOpacity = 0.18f + f.displayValue * 0.82f;
        else if (f.role == Role.HINT_DURATION) hintDurationMs = 10L + (long) (f.displayValue * 4990L);
        else if (f.role == Role.HINT_POSITION) {
            hintPositionEdit = f.enabled;
            hintToasts.clear();
            if (hintPositionEdit) {
                if (!hintPositionReady) { setHintDefaultPosition(); hintPositionReady = true; }
                hintToasts.add(new HintToast(chineseMode ? "提示位置调试" : "Hint position preview", true, SystemClock.uptimeMillis()));
                hintActive = true;
            } else {
                hintActive = false;
                draggingHint = false;
            }
        }
        else if (f.role == Role.HINT_SIZE) hintSize = 0.72f + f.displayValue * 0.78f;
        else if (f.role == Role.HINT_DEBUG_TOASTS) hintShowDebugFeatures = f.enabled;
        else if (f.role == Role.HINT_GLOW_ENABLED) hintGlowEnabled = f.enabled;
        else if (f.role == Role.HINT_GLOW_STRENGTH) hintGlowStrength = f.displayValue;
        else if (f.role == Role.HINT_GLOW_COLOR) {
            hintGlowColor = f.color;
            hintGlowGradient = f.colorGradient;
            hintGlowColors = copyColors(f.gradientColors);
            hintGlowGradientSpeed = f.gradientSpeed;
            hintGlowGradientStyle = f.gradientStyle;
            hintGlowGradientDelay = f.gradientDelay;
        }
        else if (f.role == Role.SCROLL_SPEED) scrollSpeed = 0.45f + f.displayValue * 2.55f;
        else if (f.role == Role.SCROLL_DAMPING) scrollDamping = 0.30f + f.displayValue * 0.65f;
        else if (f.role == Role.SCROLLBAR_OPACITY) scrollBarOpacity = 0.18f + f.displayValue * 0.82f;
        else if (f.role == Role.SCROLLBAR_WIDTH) scrollBarWidth = 0.15f + f.displayValue * 1.35f;
        else if (f.role == Role.BALL_SIZE) ballSizeFactor = f.displayValue;
        else if (f.role == Role.BALL_OPACITY) ballOpacity = 0.24f + f.displayValue * 0.76f;
        else if (f.role == Role.BALL_SNAP) ballSnapEdge = f.enabled;
        else if (f.role == Role.SHORTCUT_ENABLE && f.shortcutTarget != null) {
            f.shortcutTarget.shortcutEnabled = f.enabled;
            ensureShortcutPosition(f.shortcutTarget);
        }
        else if (f.role == Role.SHORTCUT_BG_OPACITY) shortcutBgOpacity = 0.08f + f.displayValue * 0.92f;
        else if (f.role == Role.SHORTCUT_BORDER_OPACITY) shortcutBorderOpacity = 0.08f + f.displayValue * 0.92f;
        else if (f.role == Role.SHORTCUT_SHAPE) shortcutShape = f.optionIndex;
        else if (f.role == Role.SHORTCUT_ON_TEXT_COLOR) shortcutOnTextColor = f.color;
        else if (f.role == Role.SHORTCUT_ON_BG_COLOR) shortcutOnBgColor = f.color;
        else if (f.role == Role.SHORTCUT_OFF_TEXT_COLOR) shortcutOffTextColor = f.color;
        else if (f.role == Role.SHORTCUT_OFF_BG_COLOR) shortcutOffBgColor = f.color;
        else if (f.role == Role.SHORTCUT_BORDER_COLOR) {
            shortcutBorderColor = f.color;
            shortcutBorderGradient = f.colorGradient;
            shortcutBorderColors = copyColors(f.gradientColors);
            shortcutBorderGradientSpeed = f.gradientSpeed;
            shortcutBorderGradientStyle = f.gradientStyle;
            shortcutBorderGradientDelay = f.gradientDelay;
        }
        else if (f.role == Role.SHORTCUT_BG_SIZE) shortcutSizeFactor = 0.60f + f.displayValue * 0.80f;
        else if (f.role == Role.SHORTCUT_BORDER_SIZE) shortcutBorderSizeFactor = 0.25f + f.displayValue * 1.50f;
        else if (f.role == Role.SHORTCUT_FONT_SIZE) shortcutTextSizeFactor = 0.65f + f.displayValue * 0.95f;
        else if (f.role == Role.SHORTCUT_GLOW_ENABLED) shortcutGlowEnabled = f.enabled;
        else if (f.role == Role.SHORTCUT_GLOW_STRENGTH) shortcutGlowStrength = f.displayValue;
        else if (f.role == Role.SHORTCUT_GLOW_COLOR) {
            shortcutGlowColor = f.color;
            shortcutGlowGradient = f.colorGradient;
            shortcutGlowColors = copyColors(f.gradientColors);
            shortcutGlowGradientSpeed = f.gradientSpeed;
            shortcutGlowGradientStyle = f.gradientStyle;
            shortcutGlowGradientDelay = f.gradientDelay;
        }
        else if (f.role == Role.ANIM_ENABLED) animationsEnabled = f.enabled;
        else if (f.role == Role.ANIM_BALL_TRANSITION) ballTransitionMode = f.optionIndex;
        else if (f.role == Role.LOG_WINDOW) {
            logWindowEnabled = f.enabled;
            if (logWindowEnabled) {
                ensureLogPosition();
                appendLog("Runtime log opened");
            } else {
                logDragging = false;
                logBodyScrolling = false;
                lastRealtimeLogMs = 0L;
            }
        }
        else if (f.role == Role.MUSIC_WINDOW) {
            musicWindowEnabled = f.enabled;
            if (musicWindowEnabled && !musicLoading && "Ready".equals(musicStatus)) performMusicSearch();
            if (!musicWindowEnabled) {
                deactivateMusicSearch();
                deactivateMusicNameInput();
            }
        }
        else if (f.role == Role.ARRAYLIST_WINDOW) arrayListEnabled = f.enabled;
        else if (f.role == Role.ARRAYLIST_BAR_LENGTH) arrayListBarLengthFactor = 0.45f + f.displayValue * 1.25f;
        else if (f.role == Role.ARRAYLIST_BAR_WIDTH) arrayListBarWidthFactor = 0.35f + f.displayValue * 2.10f;
        else if (f.role == Role.ARRAYLIST_BAR_COLOR) {
            arrayListBarColor = f.color;
            arrayListBarGradient = f.colorGradient;
            arrayListBarColors = copyColors(f.gradientColors);
            arrayListBarGradientSpeed = f.gradientSpeed;
            arrayListBarGradientStyle = f.gradientStyle;
            arrayListBarGradientDelay = f.gradientDelay;
        }
        else if (f.role == Role.ARRAYLIST_TEXT_SIZE) arrayListTextSizeFactor = 0.65f + f.displayValue * 1.05f;
        else if (f.role == Role.ARRAYLIST_TEXT_COLOR) {
            arrayListTextColor = f.color;
            arrayListTextGradient = f.colorGradient;
            arrayListTextColors = copyColors(f.gradientColors);
            arrayListTextGradientSpeed = f.gradientSpeed;
            arrayListTextGradientStyle = f.gradientStyle;
            arrayListTextGradientDelay = f.gradientDelay;
        }
        else if (f.role == Role.ARRAYLIST_GLOW_ENABLED) arrayListGlowEnabled = f.enabled;
        else if (f.role == Role.ARRAYLIST_GLOW_STRENGTH) arrayListGlowStrength = f.displayValue;
        else if (f.role == Role.ARRAYLIST_POSITION) arrayListPositionEdit = f.enabled;
        else if (f.role == Role.ARRAYLIST_SHOW_DEBUG) arrayListShowDebugSettings = f.enabled;
        else if (f.role == Role.GLOBAL_RESOLUTION) {
            globalResolutionScale = 0.72f + f.displayValue * 0.56f;
            uiCompactScale = globalResolutionScale;
            rebuildLayoutCache();
        }
        else if (f.role == Role.GLOBAL_PERFORMANCE) {
            performanceQuality = 0.25f + f.displayValue * 0.75f;
            glowMaskCache.clear();
        }
        else if (f.role == Role.GLOBAL_OPACITY) globalOpacityScale = 0.18f + f.displayValue * 0.82f;
        else if (f.role == Role.GLOBAL_CORNER) globalCornerScale = 0.35f + f.displayValue * 1.75f;
        else if (f.role == Role.GLOBAL_STROKE) globalStrokeScale = 0.25f + f.displayValue * 2.30f;
        else if (f.role == Role.GLOBAL_GLOW) globalGlowScale = 0.20f + f.displayValue * 2.20f;
        else if (f.role == Role.GLOBAL_ANIM_SPEED) globalAnimSpeedScale = 0.35f + f.displayValue * 1.90f;
        else if (f.role == Role.GLOBAL_TEXT_SCALE) globalTextScale = 0.70f + f.displayValue * 0.70f;
        else if (f.role == Role.GLOBAL_GLASS) globalGlassStrength = 0.20f + f.displayValue * 1.60f;
        else if (f.role == Role.GLOBAL_DIM) globalBackgroundDim = f.displayValue;
        else if (f.role == Role.GLOBAL_TOUCH_FEEDBACK) globalTouchFeedback = 0.30f + f.displayValue * 1.60f;
        else if (f.role == Role.PANEL_WIDTH) { panelWidthScale = 0.72f + f.displayValue * 0.56f; rebuildLayoutCache(); }
        else if (f.role == Role.PANEL_HEIGHT) { panelHeightScale = 0.72f + f.displayValue * 0.56f; rebuildLayoutCache(); }
        else if (f.role == Role.PANEL_BG_OPACITY) panelBgOpacityScale = 0.20f + f.displayValue * 0.80f;
        else if (f.role == Role.PANEL_CORNER) panelCornerScale = 0.35f + f.displayValue * 1.70f;
        else if (f.role == Role.PANEL_STROKE) panelStrokeScale = 0.25f + f.displayValue * 2.20f;
        else if (f.role == Role.PANEL_PADDING) { panelPaddingScale = 0.72f + f.displayValue * 0.72f; rebuildLayoutCache(); }
        else if (f.role == Role.PANEL_GLOW_ENABLED) panelGlowEnabled = f.enabled;
        else if (f.role == Role.PANEL_GLOW) panelGlowStrength = f.displayValue;
        else if (f.role == Role.PANEL_TITLE_SIZE) panelTitleScale = 0.70f + f.displayValue * 0.75f;
        else if (f.role == Role.PANEL_CONTENT_SIZE) panelContentTextScale = 0.70f + f.displayValue * 0.75f;
        else if (f.role == Role.PANEL_EDGE_SNAP) panelEdgeSnap = f.enabled;
        else if (f.role == Role.SECTION_SIZE) { sectionSizeScale = 0.75f + f.displayValue * 0.70f; rebuildLayoutCache(); }
        else if (f.role == Role.SECTION_SPACING) { sectionSpacingScale = 0.50f + f.displayValue * 1.50f; rebuildLayoutCache(); }
        else if (f.role == Role.SECTION_CORNER) sectionCornerScale = 0.35f + f.displayValue * 1.70f;
        else if (f.role == Role.SECTION_TEXT) sectionTextScale = 0.70f + f.displayValue * 0.75f;
        else if (f.role == Role.SECTION_GLOW_ENABLED) sectionGlowEnabled = f.enabled;
        else if (f.role == Role.SECTION_GLOW) sectionGlowStrength = f.displayValue;
        else if (f.role == Role.FEATURE_HEIGHT) { featureHeightScale = 0.70f + f.displayValue * 0.85f; rebuildLayoutCache(); }
        else if (f.role == Role.FEATURE_GAP) { featureGapScale = 0.45f + f.displayValue * 1.70f; rebuildLayoutCache(); }
        else if (f.role == Role.FEATURE_CORNER) featureCornerScale = 0.35f + f.displayValue * 1.70f;
        else if (f.role == Role.FEATURE_TEXT) featureTextScale = 0.70f + f.displayValue * 0.75f;
        else if (f.role == Role.FEATURE_STROKE) featureStrokeScale = 0.25f + f.displayValue * 2.20f;
        else if (f.role == Role.FEATURE_GLOW_ENABLED) featureGlowEnabled = f.enabled;
        else if (f.role == Role.FEATURE_GLOW) featureGlowStrength = f.displayValue;
        else if (f.role == Role.FEATURE_PRESS) featurePressScale = 0.30f + f.displayValue * 1.70f;
        else if (f.role == Role.FEATURE_ICONS) featureIconsEnabled = f.enabled;
        else if (f.role == Role.FEATURE_HAPTIC) featureHapticEnabled = f.enabled;
        else if (f.role == Role.LAYOUT_LEFT_WIDTH) { layoutLeftWidthScale = 0.72f + f.displayValue * 0.72f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_TOP_HEIGHT) { layoutTopHeightScale = 0.75f + f.displayValue * 0.70f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_ROW_GAP) { layoutRowGapScale = 0.55f + f.displayValue * 1.45f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_CONTROL_WIDTH) { layoutControlWidthScale = 0.70f + f.displayValue * 0.95f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_SLIDER_HEIGHT) { layoutSliderHeightScale = 0.65f + f.displayValue * 1.15f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_SAFE_INSET) { layoutSafeInsetScale = 0.60f + f.displayValue * 1.30f; rebuildLayoutCache(); }
        else if (f.role == Role.LAYOUT_SCROLLBAR_VISIBLE) layoutScrollBarVisible = f.enabled;
        else if (f.role == Role.THEME_RGB_DIRECTION) themeRgbDirection = f.optionIndex;
        else if (f.role == Role.THEME_IOS_OPACITY) themeIosGlassOpacity = 0.35f + f.displayValue * 1.10f;
        else if (f.role == Role.THEME_IOS_HIGHLIGHT) themeIosHighlight = 0.20f + f.displayValue * 1.60f;
        else if (f.role == Role.THEME_NOISE) themeNoiseStrength = f.displayValue;
        else if (f.role == Role.LOG_TEXT_SIZE) logWindowTextScale = 0.70f + f.displayValue * 0.90f;
        else if (f.role == Role.LOG_OPACITY) logWindowOpacity = 0.20f + f.displayValue * 0.80f;
        else if (f.role == Role.LOG_AUTO_SCROLL) logAutoScroll = f.enabled;
        else if (f.role == Role.LOG_RECORD_FPS) logRecordFps = f.enabled;
        else if (f.role == Role.LOG_RECORD_TOUCH) logRecordTouch = f.enabled;
        else if (f.role == Role.MUSIC_SCALE) musicWindowScale = 0.75f + f.displayValue * 0.70f;
        else if (f.role == Role.MUSIC_LYRIC_SCALE) musicLyricScale = 0.70f + f.displayValue * 0.90f;
        else if (f.role == Role.MUSIC_PROGRESS_HEIGHT) musicProgressHeightScale = 0.55f + f.displayValue * 1.55f;
        else if (f.role == Role.MUSIC_DEFAULT_PANEL) {
            musicDefaultPanel = clampInt(f.optionIndex, 0, 1);
            // Build fix: the old mega-debug patch referenced a removed field
            // musicWindowVisible.  The real switch state is musicWindowEnabled.
            // Only apply the default panel immediately when the music window is hidden,
            // otherwise changing the setting would unexpectedly jump the visible panel.
            if (!musicWindowEnabled) musicPanelMode = musicDefaultPanel;
        }
        normalizeDebugScales();
        markArrayListDirty();
        clampHint();
        clampBall();
    }

    private int clampInt(int v, int min, int max) {
        return v < min ? min : (v > max ? max : v);
    }

    private float clampFloat(float v, float min, float max) {
        if (Float.isNaN(v) || Float.isInfinite(v)) return min;
        return v < min ? min : (v > max ? max : v);
    }

    private void normalizeDebugScales() {
        // Centralized conflict guard for the large debugging system.
        // It prevents global / panel / layout multipliers from stacking into
        // unreadable or unclickable controls when several debug groups are tuned together.
        globalResolutionScale = clampFloat(globalResolutionScale, 0.55f, 1.45f);
        uiCompactScale = clampFloat(uiCompactScale, 0.55f, 1.45f);
        performanceQuality = clampFloat(performanceQuality, 0.15f, 1.0f);
        globalOpacityScale = clampFloat(globalOpacityScale, 0.10f, 1.0f);
        globalCornerScale = clampFloat(globalCornerScale, 0.20f, 2.40f);
        globalStrokeScale = clampFloat(globalStrokeScale, 0.15f, 2.80f);
        globalGlowScale = clampFloat(globalGlowScale, 0.0f, 2.80f);
        globalTextScale = clampFloat(globalTextScale, 0.55f, 1.80f);

        panelWidthScale = clampFloat(panelWidthScale, 0.55f, 1.60f);
        panelHeightScale = clampFloat(panelHeightScale, 0.55f, 1.60f);
        panelPaddingScale = clampFloat(panelPaddingScale, 0.45f, 1.80f);
        sectionSizeScale = clampFloat(sectionSizeScale, 0.55f, 1.80f);
        featureHeightScale = clampFloat(featureHeightScale, 0.55f, 1.80f);
        featureGapScale = clampFloat(featureGapScale, 0.30f, 2.20f);
        layoutLeftWidthScale = clampFloat(layoutLeftWidthScale, 0.55f, 1.65f);
        layoutControlWidthScale = clampFloat(layoutControlWidthScale, 0.45f, 1.95f);
        layoutSliderHeightScale = clampFloat(layoutSliderHeightScale, 0.45f, 2.00f);

        shortcutTextSizeFactor = clampFloat(shortcutTextSizeFactor, 0.50f, 2.10f);
        arrayListTextSizeFactor = clampFloat(arrayListTextSizeFactor, 0.50f, 2.10f);
        arrayListBarLengthFactor = clampFloat(arrayListBarLengthFactor, 0.35f, 2.20f);
        arrayListBarWidthFactor = clampFloat(arrayListBarWidthFactor, 0.25f, 3.00f);
        musicWindowScale = clampFloat(musicWindowScale, 0.55f, 1.80f);
    }

    private void resetCustomDebugDefaults() {
        globalOpacityScale = 1.0f; globalCornerScale = 1.0f; globalStrokeScale = 1.0f; globalGlowScale = 1.0f;
        globalAnimSpeedScale = 1.0f; globalTextScale = 1.0f; globalGlassStrength = 1.0f; globalBackgroundDim = 0.0f;
        panelWidthScale = panelHeightScale = panelBgOpacityScale = panelCornerScale = panelStrokeScale = panelPaddingScale = 1.0f;
        panelGlowEnabled = true; panelGlowStrength = 0.0f; panelTitleScale = 1.0f; panelContentTextScale = 1.0f; panelEdgeSnap = false;
        sectionSizeScale = sectionSpacingScale = sectionCornerScale = sectionTextScale = 1.0f; sectionGlowEnabled = true; sectionGlowStrength = 0.0f;
        featureHeightScale = featureGapScale = featureCornerScale = featureTextScale = featureStrokeScale = featurePressScale = 1.0f;
        featureGlowEnabled = true; featureGlowStrength = 0.0f; featureIconsEnabled = false; featureHapticEnabled = false;
        layoutLeftWidthScale = layoutTopHeightScale = layoutRowGapScale = layoutControlWidthScale = layoutSliderHeightScale = layoutSafeInsetScale = 1.0f;
        layoutScrollBarVisible = true;
        appendLog("Custom debug defaults restored");
    }

    private void randomizeRgbTheme() {
        int a = 0xFF000000 | (int)(Math.random() * 0x00FFFFFF);
        int b = 0xFF000000 | (int)(Math.random() * 0x00FFFFFF);
        int c = 0xFF000000 | (int)(Math.random() * 0x00FFFFFF);
        arrayListTextColors = new int[]{a, b, c, a};
        arrayListBarColors = new int[]{c, a, b, c};
        arrayListTextGradient = true;
        arrayListBarGradient = true;
        markArrayListDirty();
        appendLog("Random RGB theme generated");
    }

    private void animatePress(final Feature f, float target) {
        cancel(pressAnimator);
        pressAnimator = ValueAnimator.ofFloat(f.press, target);
        pressAnimator.setDuration(target > 0f ? 110 : 210);
        pressAnimator.setInterpolator(ease);
        pressAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                f.press = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        pressAnimator.start();
    }

    private void resizePanelTo(float x, float y) {
        float dx = x - resizeDownX;
        float dy = y - resizeDownY;
        float l = resizeStartL;
        float t = resizeStartT;
        float r = resizeStartR;
        float b = resizeStartB;
        if ((activeResizeMode & RESIZE_LEFT) != 0) l += dx;
        if ((activeResizeMode & RESIZE_RIGHT) != 0) r += dx;
        if ((activeResizeMode & RESIZE_TOP) != 0) t += dy;
        if ((activeResizeMode & RESIZE_BOTTOM) != 0) b += dy;
        float minW = getWidth() * 0.58f;
        float minH = getHeight() * 0.58f;
        if (r - l < minW) {
            if ((activeResizeMode & RESIZE_LEFT) != 0) l = r - minW; else r = l + minW;
        }
        if (b - t < minH) {
            if ((activeResizeMode & RESIZE_TOP) != 0) t = b - minH; else b = t + minH;
        }
        float margin = dpRaw(8);
        if (l < margin) l = margin;
        if (t < margin) t = margin;
        if (r > getWidth() - margin) r = getWidth() - margin;
        if (b > getHeight() - margin) b = getHeight() - margin;
        panelRect.set(l, t, r, b);
        savePanelBounds();
        rebuildLayoutCache();
        requestFrame();
    }

    private int hitResizeBorder(float x, float y) {
        float zone = Math.max(dpRaw(16), dp(14));
        if (x < panelRect.left - zone || x > panelRect.right + zone || y < panelRect.top - zone || y > panelRect.bottom + zone) return 0;
        int mode = 0;
        if (Math.abs(x - panelRect.left) <= zone) mode |= RESIZE_LEFT;
        if (Math.abs(x - panelRect.right) <= zone) mode |= RESIZE_RIGHT;
        if (Math.abs(y - panelRect.top) <= zone) mode |= RESIZE_TOP;
        if (Math.abs(y - panelRect.bottom) <= zone) mode |= RESIZE_BOTTOM;
        return mode;
    }

    private void constrainPanelRect() {
        float margin = dpRaw(8);
        float minW = Math.max(560f, getWidth() * 0.58f);
        float minH = Math.max(310f, getHeight() * 0.58f);
        if (panelRect.width() < minW) panelRect.right = panelRect.left + minW;
        if (panelRect.height() < minH) panelRect.bottom = panelRect.top + minH;
        if (panelRect.left < margin) panelRect.offset(margin - panelRect.left, 0);
        if (panelRect.top < margin) panelRect.offset(0, margin - panelRect.top);
        if (panelRect.right > getWidth() - margin) panelRect.offset(getWidth() - margin - panelRect.right, 0);
        if (panelRect.bottom > getHeight() - margin) panelRect.offset(0, getHeight() - margin - panelRect.bottom);
        if (panelRect.left < margin) panelRect.left = margin;
        if (panelRect.top < margin) panelRect.top = margin;
        if (panelRect.right > getWidth() - margin) panelRect.right = getWidth() - margin;
        if (panelRect.bottom > getHeight() - margin) panelRect.bottom = getHeight() - margin;
    }

    private boolean isEmptyPanelDragArea(float x, float y) {
        if (hitResizeBorder(x, y) != 0) return false;
        if (closeRect.contains(x, y) || searchRect.contains(x, y) || badgeRect.contains(x, y)) return false;
        for (int i = 0; i < SECTION_COUNT; i++) if (sectionRects[i].contains(x, y)) return false;
        if (!welcomeVisible && featureListRect.contains(x, y)) return false;
        if (welcomeVisible && welcomeCardRect.contains(x, y)) return false;
        if (themeDropdownOpen && themePopupRect.contains(x, y)) return false;
        return true;
    }

    private Feature findMainFeatureAt(float x, float y) {
        Section section = sections[selectedSection];
        for (int i = 0; i < section.features.length; i++) if (section.features[i].mainRect.contains(x, y)) return section.features[i];
        return null;
    }

    private Feature findSliderAt(float x, float y) {
        Section section = sections[selectedSection];
        for (int i = 0; i < section.features.length; i++) {
            Feature f = section.features[i];
            if (f.type == CONTROL_SLIDER && hitExpanded(f.controlRect, x, y, dp(18))) return f;
            if (f.settings != null && f.debugProgress > 0.001f) {
                for (int s = 0; s < f.settings.length; s++) {
                    Feature setting = f.settings[s];
                    if (setting.type == CONTROL_SLIDER && hitExpanded(setting.controlRect, x, y, dp(18))) return setting;
                }
            }
        }
        return null;
    }

    private boolean hitExpanded(RectF r, float x, float y, float pad) {
        return x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;
    }

    private int indexOfFeature(Feature f) {
        Section section = sections[selectedSection];
        for (int i = 0; i < section.features.length; i++) if (section.features[i] == f) return i;
        return -1;
    }

    private int hitThemeOption(float x, float y) {
        if (themeDropdownProgress < 0.5f) return -1;
        if (!themePopupRect.contains(x, y)) return -1;
        float itemH = dp(38);
        float gap = dp(5);
        for (int i = 0; i < themes.length; i++) {
            float top = themePopupRect.top + dp(10) + i * (itemH + gap);
            RectF row = new RectF(themePopupRect.left + dp(8), top, themePopupRect.right - dp(8), top + itemH);
            if (row.contains(x, y)) return i;
        }
        return -1;
    }

    private boolean isThemeLocked() {
        return themeDropdownOpen || themeDropdownProgress > 0.001f;
    }

    private Feature getThemeFeature() {
        for (int si = 0; si < sections.length; si++) {
            Section sec = sections[si];
            if (sec == null || sec.features == null) continue;
            Feature found = findFeatureByRole(sec.features, Role.THEME);
            if (found != null) return found;
        }
        return null;
    }

    private Feature findFeatureByRole(Feature[] list, int role) {
        if (list == null) return null;
        for (int i = 0; i < list.length; i++) {
            Feature f = list[i];
            if (f == null) continue;
            if (f.role == role) return f;
            if (f.settings != null) {
                Feature child = findFeatureByRole(f.settings, role);
                if (child != null) return child;
            }
        }
        return null;
    }

    /**
     * Adds a feature on/off hint toast.
     * The hint renderer supports both default style and style 2; debug options
     * can decide whether debug-only features are allowed to create hints.
     */
    private void showHint(String text, boolean enabled) {
        if (hintPositionEdit) return;
        if (text == null) text = "";
        long now = SystemClock.uptimeMillis();
        hintText = text;
        hintStateEnabled = enabled;
        hintStartMs = now;
        hintActive = true;
        if (!hintPositionReady) setHintDefaultPosition();

        // Add a new prompt instead of replacing the current one.
        // Existing prompts keep their remaining time and the new prompt is drawn above them.
        // No count cap is applied; expired prompts are cleaned in drawHintToast().
        hintToasts.add(new HintToast(text, enabled, now));
        clampHint();
        requestFrame();
    }

    private boolean hitHint(float x, float y) {
        if (hintToasts.size() == 0) return false;
        float w = getHintToastWidth();
        float h = getHintToastHeight();
        float gap = getHintToastGap();
        int count = Math.max(1, hintToasts.size());
        float top = hintY - (count - 1) * (h + gap);
        return x >= hintX && x <= hintX + w && y >= top && y <= hintY + h;
    }

    private float getHintToastWidth() {
        return hintStyle == 1 ? dp(218 * hintSize) : dp(260 * hintSize);
    }

    private float getHintToastHeight() {
        return hintStyle == 1 ? dp(42 * hintSize) : dp(78 * hintSize);
    }

    private float getHintToastGap() {
        return hintStyle == 1 ? dp(7 * hintSize) : dp(10 * hintSize);
    }

    private void setHintDefaultPosition() {
        float w = getHintToastWidth();
        float h = getHintToastHeight();
        hintX = getWidth() - w - dpRaw(26);
        hintY = getHeight() - h - dpRaw(28);
        hintPositionReady = true;
        clampHint();
    }

    private void clampHint() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float w = getHintToastWidth();
        float h = getHintToastHeight();
        float gap = getHintToastGap();
        float m = dpRaw(8);
        int count = Math.max(1, hintToasts.size());
        float stackTopMargin = m + (count - 1) * (h + gap);
        if (hintX < m) hintX = m;
        if (hintY < stackTopMargin) hintY = stackTopMargin;
        if (hintX > getWidth() - w - m) hintX = getWidth() - w - m;
        if (hintY > getHeight() - h - m) hintY = getHeight() - h - m;
    }


    private boolean hitBall(float x, float y) {
        float cx = ballX + ballSize / 2f;
        float cy = ballY + ballSize / 2f;
        float r = ballSize * 0.55f;
        return dist(x, y, cx, cy) <= r;
    }

    private void clampBall() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float m = dpRaw(8);
        if (ballX < m) ballX = m;
        if (ballY < m) ballY = m;
        if (ballX > getWidth() - ballSize - m) ballX = getWidth() - ballSize - m;
        if (ballY > getHeight() - ballSize - m) ballY = getHeight() - ballSize - m;
    }

    private void animateBallTap() {
        cancel(ballScaleAnimator);
        ballScaleAnimator = ValueAnimator.ofFloat(1f, 0.92f, 1f);
        ballScaleAnimator.setDuration(240);
        ballScaleAnimator.setInterpolator(ease);
        ballScaleAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ballScale = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        ballScaleAnimator.start();
    }

    private void animateBallScale(float target) {
        cancel(ballScaleAnimator);
        ballScaleAnimator = ValueAnimator.ofFloat(ballScale, target);
        ballScaleAnimator.setDuration(220);
        ballScaleAnimator.setInterpolator(ease);
        ballScaleAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ballScale = (Float) animation.getAnimatedValue();
                requestFrame();
            }
        });
        ballScaleAnimator.start();
    }

    private void snapBallToEdge() {
        cancel(ballSnapAnimator);
        final float from = ballX;
        final float target = ballX + ballSize / 2f < getWidth() / 2f ? dpRaw(14) : getWidth() - ballSize - dpRaw(14);
        ballSnapAnimator = ValueAnimator.ofFloat(from, target);
        ballSnapAnimator.setDuration(360);
        ballSnapAnimator.setInterpolator(ease);
        ballSnapAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ballX = (Float) animation.getAnimatedValue();
                clampBall();
                requestFrame();
            }
        });
        ballSnapAnimator.start();
    }

    private void clampScroll() {
        if (scrollY < 0f) scrollY = 0f;
        if (scrollY > maxScrollY) scrollY = maxScrollY;
        if (selectedSection >= 0 && selectedSection < sectionScrollPositions.length) sectionScrollPositions[selectedSection] = scrollY;
    }

    private void showScrollBar() {
        scrollBarVisibleUntil = SystemClock.uptimeMillis() + 900L;
    }

    private void updateFps() {
        long now = System.nanoTime();
        if (fpsLastNs == 0L) {
            fpsLastNs = now;
            fpsFrames = 0;
            return;
        }
        fpsFrames++;
        long d = now - fpsLastNs;
        if (d >= 1000000000L) {
            currentFps = (int) ((fpsFrames * 1000000000L) / d);
            fpsFrames = 0;
            fpsLastNs = now;
        }
    }

    private String getSectionLabel(int i) {
        return chineseMode ? sectionNamesCn[i] : sectionNames[i];
    }

    private String getFeatureName(Feature f) {
        return chineseMode && f.nameCn != null ? f.nameCn : f.name;
    }

    private String getFeatureTitle(Feature f) {
        return chineseMode && f.titleCn != null ? f.titleCn : f.title;
    }

    private String getOptionText(Feature f) {
        if (f.options == null || f.options.length == 0) return "";
        if (chineseMode && f.optionsCn != null && f.optionIndex < f.optionsCn.length) return f.optionsCn[f.optionIndex];
        return f.options[f.optionIndex];
    }

    private String getFeatureHint(Feature f) {
        if (f.type == CONTROL_NONE) return chineseMode ? "无功能" : "No feature";
        if (f.role == Role.THEME) return chineseMode ? "选择默认、iOS 毛玻璃或 RGB 炫彩主题" : "Choose Default, iOS glass or RGB colorful theme";
        if (f.type == CONTROL_GROUP) return f.debugOpen ? (chineseMode ? "调试项已展开" : "Debug items expanded") : (chineseMode ? "点击文字展开底部调试项" : "Tap title to expand debug items");
        if (f.role == Role.SWITCH_HINT) return f.debugOpen ? (chineseMode ? "开关在顶部，调试项展开在下方" : "Top switch, debug items below") : (chineseMode ? "控制功能开启/关闭提示" : "Control feature on/off prompts");
        if (f.role == Role.HINT_STYLE) return chineseMode ? "默认样式或右下角 2 功能提示" : "Default style or 2 right-bottom switch prompt";
        if (f.role == Role.HINT_DEBUG_TOASTS) return chineseMode ? "开启后调试项开关也会弹出功能提示" : "Show switch hints for debug setting toggles too";
        if (f.role == Role.CHINESE) return chineseMode ? "切换中英文界面文字" : "Toggle Chinese / English UI labels";
        if (f.role == Role.MUSIC_WINDOW) return chineseMode ? "打开本地音乐与网易云悬浮面板" : "Open local music and Netease floating panel";
        if (f.role == Role.LOG_WINDOW) return chineseMode ? "打开独立日志悬浮窗，窗口内有清除/导出按钮" : "Open a separate log window with Clear/Export buttons inside";
        if (f.role == Role.ARRAYLIST_WINDOW) return chineseMode ? "显示类似客户端 ArrayList 的已开启功能列表" : "Show enabled features in a client-style ArrayList";
        if (f.role == Role.ARRAYLIST_POSITION) return chineseMode ? "开启后可拖动功能列表位置" : "Enable to drag the ArrayList position";
        if (f.role == Role.ARRAYLIST_SHOW_DEBUG) return chineseMode ? "显示已开启的调试设置项" : "Include enabled debug setting switches";
        if (f.role == Role.LOG_CLEAR) return chineseMode ? "清空当前记录的实时日志" : "Clear current runtime logs";
        if (f.role == Role.LOG_EXPORT) return chineseMode ? "调用文件管理器选择导出路径" : "Use file manager to choose export path";
        if (f.role == Role.SHORTCUT_GROUP) return chineseMode ? "调整悬浮快捷键大小、颜色、辉光和描边" : "Tune shortcut size, color, glow and border";
        if (f.role == Role.FONT_GROUP) return fontStatus;
        if (f.role == Role.FONT_IMPORT) return chineseMode ? "从文件管理器选择 .ttf/.otf" : "Pick .ttf/.otf from file manager";
        if (f.role == Role.FONT_RESET) return chineseMode ? "恢复 Android 默认字体" : "Restore Android default font";
        if (f.role == Role.SHORTCUT_ENABLE) return chineseMode ? "显示/隐藏这个功能的悬浮快捷键" : "Show / hide this feature shortcut";
        if (f.role == Role.ANIM_ENABLED) return chineseMode ? "关闭后禁止所有 UI 动画" : "Disable to stop all UI animations";
        if (f.role == Role.GLOBAL_GROUP) return chineseMode ? "全局透明度、圆角、描边、辉光、动画和性能" : "Global opacity, corners, strokes, glow, animation and performance";
        if (f.role == Role.GUI_GROUP) return chineseMode ? "主面板、板块和功能项的统一 UI 设置" : "Unified UI settings for panel, sections and features";
        if (f.role == Role.PANEL_GROUP) return chineseMode ? "面板大小、背景、圆角、描边、辉光和文字" : "Panel size, background, corners, stroke, glow and text";
        if (f.role == Role.SECTION_GROUP) return chineseMode ? "左侧板块大小、间距、圆角、文字和高亮" : "Sidebar section size, spacing, corners, text and glow";
        if (f.role == Role.FEATURE_GROUP) return chineseMode ? "功能卡片高度、间距、圆角、文字、描边和反馈" : "Feature card height, gap, corners, text, stroke and feedback";
        if (f.role == Role.LAYOUT_GROUP) return chineseMode ? "左栏、顶部、控件宽度、滑条和安全区布局" : "Left bar, top height, controls, sliders and safe inset";
        if (f.role == Role.THEME_GROUP) return chineseMode ? "RGB 方向、iOS 玻璃透明度、高光和噪点" : "RGB direction, iOS glass opacity, highlight and noise";
        if (f.role == Role.LOG_GROUP) return chineseMode ? "日志窗口文字、透明度、自动滚动和记录项" : "Log text, opacity, auto scroll and record filters";
        if (f.role == Role.MUSIC_GROUP) return chineseMode ? "音乐窗口、歌词、进度条和默认面板" : "Music window, lyric, progress bar and default panel";
        if (f.role == Role.PICKER_GROUP) return chineseMode ? "说明：所有选色界面都支持渐变速度/延迟/经典模式" : "Info: all pickers support gradient speed/delay/classic mode";
        if (f.role == Role.CONFIG_GROUP) return chineseMode ? "保存、加载、恢复默认与随机主题" : "Save, load, restore defaults and random themes";
        if (f.role == Role.GLOBAL_RESOLUTION) return chineseMode ? "整体 UI 绘制缩放/分辨率" : "Global UI rendering scale/resolution";
        if (f.role == Role.GLOBAL_PERFORMANCE) return chineseMode ? "越高显示效果越好，越低显示效果越差" : "Higher = better visuals, lower = better performance";
        if (f.role == Role.ANIM_BALL_TRANSITION) return chineseMode ? "选择悬浮球打开/关闭 UI 的动画方式" : "Choose floating-ball open/close transition";
        if (f.type == CONTROL_SWITCH) return chineseMode ? "测试用开关，没有任何实际效果" : "Test switch only, no real effect";
        return chineseMode ? "调试功能" : "Debug feature";
    }

    private String getValueText(Feature f) {
        if (f.role == Role.HINT_DURATION) return formatHintDuration();
        if (f.role == Role.HINT_OPACITY) return percent(hintOpacity);
        if (f.role == Role.HINT_SIZE) return percent(hintSize);
        if (f.role == Role.HINT_GLOW_STRENGTH) return percent(hintGlowStrength);
        if (f.role == Role.SCROLL_SPEED) return String.valueOf((int) (scrollSpeed * 100)) + "%";
        if (f.role == Role.SCROLL_DAMPING) return String.valueOf((int) (scrollDamping * 100)) + "%";
        if (f.role == Role.SCROLLBAR_OPACITY) return percent(scrollBarOpacity);
        if (f.role == Role.SCROLLBAR_WIDTH) return String.valueOf((int) (scrollBarWidth * 100)) + "%";
        if (f.role == Role.BALL_SIZE) return String.valueOf((int) ((0.72f + ballSizeFactor * 0.72f) * 100)) + "%";
        if (f.role == Role.BALL_OPACITY) return percent(ballOpacity);
        if (f.role == Role.ANIM_PANEL) return getPanelDuration() + "ms";
        if (f.role == Role.ANIM_SECTION) return getSectionDuration() + "ms";
        if (f.role == Role.ANIM_DEBUG) return getDebugDuration() + "ms";
        if (f.role == Role.SHORTCUT_BG_OPACITY) return percent(shortcutBgOpacity);
        if (f.role == Role.SHORTCUT_BORDER_OPACITY) return percent(shortcutBorderOpacity);
        if (f.role == Role.SHORTCUT_BG_SIZE) return String.valueOf((int) (shortcutSizeFactor * 100)) + "%";
        if (f.role == Role.SHORTCUT_BORDER_SIZE) return String.valueOf((int) (shortcutBorderSizeFactor * 100)) + "%";
        if (f.role == Role.SHORTCUT_FONT_SIZE) return String.valueOf((int) (shortcutTextSizeFactor * 100)) + "%";
        if (f.role == Role.SHORTCUT_GLOW_STRENGTH) return percent(shortcutGlowStrength);
        if (f.role == Role.ARRAYLIST_BAR_LENGTH) return String.valueOf((int) (arrayListBarLengthFactor * 100)) + "%";
        if (f.role == Role.ARRAYLIST_BAR_WIDTH) return String.valueOf((int) (arrayListBarWidthFactor * 100)) + "%";
        if (f.role == Role.ARRAYLIST_TEXT_SIZE) return String.valueOf((int) (arrayListTextSizeFactor * 100)) + "%";
        if (f.role == Role.ARRAYLIST_GLOW_STRENGTH) return percent(arrayListGlowStrength);
        if (f.role == Role.GLOBAL_RESOLUTION) return String.valueOf((int)(globalResolutionScale * 100)) + "%";
        if (f.role == Role.GLOBAL_PERFORMANCE) return percent(performanceQuality);
        if (f.type == CONTROL_SLIDER) return String.valueOf((int)(f.displayValue * 100)) + "%";
        return "";
    }

    private String formatHintDuration() {
        long ms = hintDurationMs;
        if (ms < 10L) ms = 10L;
        if (ms > 5000L) ms = 5000L;
        long centi = (ms + 5L) / 10L;
        long whole = centi / 100L;
        long frac = centi % 100L;
        return whole + "." + (frac < 10 ? "0" : "") + frac + (chineseMode ? "秒" : "s");
    }

    private String percent(float v) {
        return String.valueOf((int) (v * 100)) + "%";
    }

    private int getColorFeatureValue(Feature f) {
        if (f == null) return 0xFFFFFFFF;
        if (f.role == Role.SHORTCUT_ON_TEXT_COLOR) return shortcutOnTextColor;
        if (f.role == Role.SHORTCUT_ON_BG_COLOR) return shortcutOnBgColor;
        if (f.role == Role.SHORTCUT_OFF_TEXT_COLOR) return shortcutOffTextColor;
        if (f.role == Role.SHORTCUT_OFF_BG_COLOR) return shortcutOffBgColor;
        if (f.role == Role.SHORTCUT_BORDER_COLOR) return shortcutBorderColor;
        if (f.role == Role.SHORTCUT_GLOW_COLOR) return shortcutGlowColor;
        if (f.role == Role.HINT_GLOW_COLOR) return hintGlowColor;
        if (f.role == Role.ARRAYLIST_BAR_COLOR) return arrayListBarColor;
        if (f.role == Role.ARRAYLIST_TEXT_COLOR) return arrayListTextColor;
        return f.color;
    }

    private String colorLabel(Feature f) {
        if (isColorFeatureGradient(f)) return chineseMode ? "渐变" : "Gradient";
        int c = getColorFeatureValue(f);
        int r = (c >> 16) & 255;
        int g = (c >> 8) & 255;
        int b = c & 255;
        return r + "," + g + "," + b;
    }

    private int contrastTextColor(int color) {
        int r = (color >> 16) & 255;
        int g = (color >> 8) & 255;
        int b = color & 255;
        int y = (r * 299 + g * 587 + b * 114) / 1000;
        return y > 156 ? 0xFF111827 : 0xFFFFFFFF;
    }

    private int argb(int a, int r, int g, int b) {
        if (a < 0) a = 0; if (a > 255) a = 255;
        if (r < 0) r = 0; if (r > 255) r = 255;
        if (g < 0) g = 0; if (g > 255) g = 255;
        if (b < 0) b = 0; if (b > 255) b = 255;
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private long getPanelDuration() {
        if (!animationsEnabled) return 1L;
        Feature f = findRole(Role.ANIM_PANEL);
        float v = f == null ? 0.5f : f.displayValue;
        return Math.max(1L, (long)((220L + (long) (v * 620L)) / globalAnimSpeedScale));
    }

    private long getTransitionDuration() {
        long d = getPanelDuration() + 120L;
        if (d < 420L) d = 420L;
        if (d > 900L) d = 900L;
        return d;
    }

    private boolean isParticleTransition() {
        if (!animationsEnabled) return false;
        Feature f = findRole(Role.ANIM_BALL_TRANSITION);
        return f == null || f.optionIndex == 0;
    }

    private long getSectionDuration() {
        if (!animationsEnabled) return 1L;
        Feature f = findRole(Role.ANIM_SECTION);
        float v = f == null ? 0.5f : f.displayValue;
        return Math.max(1L, (long)((220L + (long) (v * 620L)) / globalAnimSpeedScale));
    }

    private long getDebugDuration() {
        if (!animationsEnabled) return 1L;
        Feature f = findRole(Role.ANIM_DEBUG);
        float v = f == null ? 0.5f : f.displayValue;
        return Math.max(1L, (long)((180L + (long) (v * 620L)) / globalAnimSpeedScale));
    }

    private Feature findRole(int role) {
        Section s = sections[4];
        for (int i = 0; i < s.features.length; i++) {
            Feature f = s.features[i];
            if (f.role == role) return f;
            if (f.settings != null) for (int j = 0; j < f.settings.length; j++) if (f.settings[j].role == role) return f.settings[j];
        }
        return null;
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private void loadPersistentState() {
        try {
            SharedPreferences sp = prefs();
            themeIndex = sp.getInt("theme_index", themeIndex);
            musicPanelMode = sp.getInt("music_panel_mode", musicPanelMode);
            savedPanelL = sp.getFloat("panel_l", -1f);
            savedPanelT = sp.getFloat("panel_t", -1f);
            savedPanelR = sp.getFloat("panel_r", -1f);
            savedPanelB = sp.getFloat("panel_b", -1f);
            savedPanelBoundsLoaded = savedPanelL >= 0f && savedPanelT >= 0f && savedPanelR > savedPanelL && savedPanelB > savedPanelT;
            Feature theme = getThemeFeature();
            if (theme != null && themeIndex >= 0 && themeIndex < themes.length) theme.optionIndex = themeIndex;
        } catch (Exception ignored) { }
    }

    private void savePanelBounds() {
        if (getWidth() <= 0 || getHeight() <= 0 || panelRect.isEmpty()) return;
        try {
            prefs().edit()
                    .putFloat("panel_l", panelRect.left / getWidth())
                    .putFloat("panel_t", panelRect.top / getHeight())
                    .putFloat("panel_r", panelRect.right / getWidth())
                    .putFloat("panel_b", panelRect.bottom / getHeight())
                    .apply();
        } catch (Exception ignored) { }
    }

    private void loadLocalPlaylist() {
        localPlaylist.clear();
        try {
            String raw = prefs().getString("local_playlist", "[]");
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String name = o.optString("name", "Local Music");
                String music = o.optString("music", "");
                String lrc = o.optString("lrc", "");
                if (music.length() > 0) localPlaylist.add(new LocalSong(name, music, lrc));
            }
        } catch (Exception ignored) { }
    }

    private void saveLocalPlaylist() {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < localPlaylist.size(); i++) {
                LocalSong song = localPlaylist.get(i);
                JSONObject o = new JSONObject();
                o.put("name", song.name);
                o.put("music", song.musicUri);
                o.put("lrc", song.lrcUri);
                arr.put(o);
            }
            prefs().edit().putString("local_playlist", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private boolean isGlassTheme() { return themeIndex == 1; }

    private boolean isRgbTheme() { return themeIndex == 2; }

    private int[] rgbThemeColors() {
        return new int[]{0xFFFF2BD6, 0xFF7C3AED, 0xFF06B6D4, 0xFF22C55E, 0xFFFACC15, 0xFFFF2BD6};
    }

    private ThemePalette theme() {
        if (themeIndex < 0 || themeIndex >= themes.length) themeIndex = 0;
        return themes[themeIndex];
    }

    @Override
    protected void onDetachedFromWindow() {
        stopMusicPlayback(true);
        frameScheduled = false;
        delayedFrameScheduled = false;
        removeCallbacks(delayedFrameRunnable);
        super.onDetachedFromWindow();
    }

    private void requestFrame() {
        if (frameScheduled) return;
        if (delayedFrameScheduled) {
            delayedFrameScheduled = false;
            removeCallbacks(delayedFrameRunnable);
        }
        frameScheduled = true;
        lastFastFrameRequestMs = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    private void requestFrameDelayed(long delayMs) {
        if (frameScheduled || delayedFrameScheduled || !isShown()) return;
        delayedFrameScheduled = true;
        postDelayed(delayedFrameRunnable, Math.max(16L, delayMs));
    }

    private boolean isHotInteractionFrame() {
        return transitionActive || resizingPanel || draggingPanel || draggingSlider || draggingHint ||
                ballDragging || shortcutDragging || arrayListDragging || logDragging || logBodyScrolling ||
                colorPickerOpen || arrayListAnimating;
    }

    private boolean shouldDrawExpensiveEffects(long nowMs) {
        if (!fpsBoostMode) return true;
        if (resizingPanel || draggingPanel || draggingSlider || draggingHint || ballDragging || shortcutDragging || arrayListDragging || logDragging || logBodyScrolling) return false;
        if (nowMs - lastExpensiveEffectMs >= EXPENSIVE_EFFECT_INTERVAL_MS) {
            lastExpensiveEffectMs = nowMs;
            return true;
        }
        return false;
    }

    private boolean shouldKeepFastRenderLoop() {
        if (!isShown()) return false;
        if (transitionActive || resizingPanel || draggingPanel || draggingSlider || draggingHint || ballDragging || shortcutDragging || arrayListDragging || arrayListAnimating || logDragging || logBodyScrolling) return true;
        if (themeDropdownOpen || themeDropdownProgress > 0.001f) return true;
        if (musicLoading || lyricAnimFromIndex >= 0) return true;
        if (hintToasts.size() > 0 || hintActive) return true;
        return hasRunningAnimators();
    }

    private long nextSlowFrameDelayMs() {
        if (!isShown()) return 0L;
        if (arrayListAnimating) return 33L;
        if (colorPickerOpen) return 50L;
        if (arrayListEnabled && (arrayListTextGradient || arrayListBarGradient)) return performanceQuality > 0.55f ? 50L : 90L;
        if (hasVisibleAnimatedShortcut() || isRgbTheme()) return fpsBoostMode ? (long)(180L - performanceQuality * 80L) : 84L;
        if (lyricOverlayEnabled && musicPlaying) return fpsBoostMode ? 160L : 120L;
        if (musicWindowEnabled && musicPlaying) return 300L;
        if (logWindowEnabled) return 1000L;
        return 0L;
    }

    private boolean hasVisibleAnimatedShortcut() {
        if (!(shortcutBorderGradient || shortcutGlowGradient)) return false;
        for (int i = 0; i < sections.length; i++) {
            Section sec = sections[i];
            if (sec == null || sec.features == null) continue;
            for (int j = 0; j < sec.features.length; j++) {
                Feature f = sec.features[j];
                if (f != null && f.shortcutEnabled && f.type == CONTROL_SWITCH) return true;
            }
        }
        return false;
    }

    private boolean hasRunningAnimators() {
        if (isAnimatorRunning(panelAnimator) || isAnimatorRunning(sectionAnimator) || isAnimatorRunning(contentAnimator) ||
                isAnimatorRunning(pressAnimator) || isAnimatorRunning(sliderAnimator) || isAnimatorRunning(themeAnimator) ||
                isAnimatorRunning(ballScaleAnimator) || isAnimatorRunning(ballSnapAnimator) || isAnimatorRunning(transitionAnimator)) return true;
        for (int i = 0; i < sections.length; i++) {
            Section sec = sections[i];
            if (sec == null || sec.features == null) continue;
            for (int j = 0; j < sec.features.length; j++) {
                Feature f = sec.features[j];
                if (f == null) continue;
                if (isAnimatorRunning(f.animator) || isAnimatorRunning(f.debugAnimator)) return true;
                if (f.settings != null) {
                    for (int k = 0; k < f.settings.length; k++) {
                        Feature s = f.settings[k];
                        if (s != null && (isAnimatorRunning(s.animator) || isAnimatorRunning(s.debugAnimator))) return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isAnimatorRunning(ValueAnimator a) {
        return a != null && a.isRunning();
    }

    private void drawText(Canvas canvas, String text, float x, float baseline, Paint p) {
        if (text == null) text = "";
        Shader old = p.getShader();
        if (themeTextGradientEnabled && isRgbTheme() && p == textPaint && text.length() > 0 && expensiveEffectsAllowed && !hotInteractionFrame) {
            float w = Math.max(1f, p.measureText(text));
            p.setShader(new LinearGradient(x, baseline - p.getTextSize(), x + w, baseline, rgbThemeColors(), null, Shader.TileMode.CLAMP));
        }
        canvas.drawText(text, x, baseline, p);
        p.setShader(old);
    }

    private void drawCenteredText(Canvas canvas, String text, RectF bounds, Paint p) {
        if (text == null) text = "";
        Paint.FontMetrics fm = p.getFontMetrics();
        float x = bounds.centerX() - p.measureText(text) / 2f;
        float y = bounds.centerY() - (fm.ascent + fm.descent) / 2f;
        Shader old = p.getShader();
        if (themeTextGradientEnabled && isRgbTheme() && p == textPaint && text.length() > 0 && expensiveEffectsAllowed && !hotInteractionFrame) {
            p.setShader(new LinearGradient(bounds.left, bounds.top, bounds.right, bounds.bottom, rgbThemeColors(), null, Shader.TileMode.CLAMP));
        }
        canvas.drawText(text, x, y, p);
        p.setShader(old);
    }

    private int dp(float value) {
        return (int) (value * uiScale * uiCompactScale + 0.5f);
    }

    private int dpRaw(float value) {
        float scale = Math.min(getWidth() / 1280f, getHeight() / 720f);
        if (scale < 0.55f) scale = 0.55f;
        if (scale > 1.65f) scale = 1.65f;
        return (int) (value * scale * uiCompactScale + 0.5f);
    }

    private float easeValue(float x) {
        if (x < 0f) x = 0f;
        if (x > 1f) x = 1f;
        return 1f - (float) Math.pow(1f - x, 3f);
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private float clamp01(float v) {
        if (v < 0f) return 0f;
        if (v > 1f) return 1f;
        return v;
    }

    private float clamp(float v, float min, float max) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    private float naturalEase(float x) {
        x = clamp01(x);
        // Smootherstep gives an acceleration/deceleration curve instead of linear speed.
        return x * x * x * (x * (x * 6f - 15f) + 10f);
    }

    private float cubic(float a, float b, float c, float d, float t) {
        t = clamp01(t);
        float u = 1f - t;
        return u * u * u * a + 3f * u * u * t * b + 3f * u * t * t * c + t * t * t * d;
    }

    private float stagger(float progress, int index, float delay) {
        float d = index * delay;
        float avail = 1f - d;
        if (avail <= 0f) return 1f;
        float t = (progress - d) / avail;
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        return easeValue(t);
    }

    private int multiplyAlpha(int a, int b) {
        return clampAlpha(a * b / 255);
    }

    private int clampAlpha(int a) {
        if (a < 0) return 0;
        if (a > 255) return 255;
        return a;
    }

    private int applyAlpha(int color, int alpha) {
        alpha = clampAlpha(alpha);
        int base = (color >>> 24) & 0xff;
        int out = base * alpha / 255;
        return (color & 0x00FFFFFF) | (out << 24);
    }

    private int blend(int c1, int c2, float k) {
        if (k < 0f) k = 0f;
        if (k > 1f) k = 1f;
        int a1 = (c1 >> 24) & 255, r1 = (c1 >> 16) & 255, g1 = (c1 >> 8) & 255, b1 = c1 & 255;
        int a2 = (c2 >> 24) & 255, r2 = (c2 >> 16) & 255, g2 = (c2 >> 8) & 255, b2 = c2 & 255;
        int a = (int) lerp(a1, a2, k);
        int r = (int) lerp(r1, r2, k);
        int g = (int) lerp(g1, g2, k);
        int b = (int) lerp(b1, b2, k);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private float dist(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private void cancel(ValueAnimator a) {
        if (a != null) a.cancel();
    }

    private static class Particle {
        float sx, sy, mx, my, ex, ey;
        float c1x, c1y, c2x, c2y;
        float wobbleX, wobbleY;
        float size, delay, endProgress;
        int color;
    }

    private static class Section {
        Feature[] features;
        Section(Feature[] features) { this.features = features; }
    }

    private static class ThemePalette {
        String name, nameCn;
        int panelBg, pageBg, softBg, activeSoft, stroke, textDark, textMid, textLight, accent;
        ThemePalette(String name, String nameCn, int panelBg, int pageBg, int softBg, int stroke, int textDark, int textMid, int textLight, int accent) {
            this.name = name;
            this.nameCn = nameCn;
            this.panelBg = panelBg;
            this.pageBg = pageBg;
            this.softBg = softBg;
            this.activeSoft = softBg;
            this.stroke = stroke;
            this.textDark = textDark;
            this.textMid = textMid;
            this.textLight = textLight;
            this.accent = accent;
        }
    }

    private static class LocalSong {
        String name;
        String musicUri;
        String lrcUri;
        LocalSong(String name, String musicUri, String lrcUri) {
            this.name = name == null ? "Local Music" : name;
            this.musicUri = musicUri == null ? "" : musicUri;
            this.lrcUri = lrcUri == null ? "" : lrcUri;
        }
    }

    private static class MusicSong {
        long id;
        String name;
        String artist;
        long duration;

        MusicSong(long id, String name, String artist, long duration) {
            this.id = id;
            this.name = name == null ? "Unknown" : name;
            this.artist = artist == null ? "Netease" : artist;
            this.duration = duration;
        }
    }

    private static class LrcLine {
        long timeMs;
        String text;

        LrcLine(long timeMs, String text) {
            this.timeMs = timeMs;
            this.text = text == null ? "" : text;
        }
    }

    private static class HintToast {
        String text;
        boolean enabled;
        long startMs;

        HintToast(String text, boolean enabled, long startMs) {
            this.text = text == null ? "" : text;
            this.enabled = enabled;
            this.startMs = startMs;
        }
    }

    private static class ArrayListAnim {
        String label = "";
        float width = -1f;
        float progress = 0f;
        boolean active = false;
        int orderHint = 0;
    }

    private static class Role {
        static final int NONE = 0;
        static final int CHINESE = 1;
        static final int THEME = 2;
        static final int SWITCH_HINT = 3;
        static final int HINT_STYLE = 4;
        static final int HINT_OPACITY = 5;
        static final int HINT_DURATION = 6;
        static final int HINT_POSITION = 7;
        static final int HINT_SIZE = 8;
        static final int SCROLL_GROUP = 9;
        static final int SCROLL_SPEED = 10;
        static final int SCROLL_DAMPING = 11;
        static final int SCROLLBAR_OPACITY = 12;
        static final int SCROLLBAR_WIDTH = 13;
        static final int BALL_GROUP = 14;
        static final int BALL_SIZE = 15;
        static final int BALL_OPACITY = 16;
        static final int BALL_SNAP = 17;
        static final int ANIMATION_GROUP = 18;
        static final int ANIM_PANEL = 19;
        static final int ANIM_SECTION = 20;
        static final int ANIM_DEBUG = 21;
        static final int MUSIC_WINDOW = 22;
        static final int GLASS_EFFECT = 23;
        static final int ANIM_BALL_TRANSITION = 24;
        static final int SHORTCUT_GROUP = 25;
        static final int SHORTCUT_ENABLE = 26;
        static final int SHORTCUT_BG_OPACITY = 27;
        static final int SHORTCUT_BORDER_OPACITY = 28;
        static final int SHORTCUT_SHAPE = 29;
        static final int SHORTCUT_ON_TEXT_COLOR = 30;
        static final int SHORTCUT_ON_BG_COLOR = 31;
        static final int SHORTCUT_OFF_TEXT_COLOR = 32;
        static final int SHORTCUT_OFF_BG_COLOR = 33;
        static final int SHORTCUT_BORDER_COLOR = 34;
        static final int SHORTCUT_BG_SIZE = 36;
        static final int SHORTCUT_BORDER_SIZE = 37;
        static final int FONT_GROUP = 38;
        static final int FONT_IMPORT = 39;
        static final int FONT_RESET = 40;
        static final int HINT_GLOW_STRENGTH = 41;
        static final int HINT_GLOW_COLOR = 42;
        static final int SHORTCUT_GLOW_STRENGTH = 43;
        static final int SHORTCUT_GLOW_COLOR = 44;
        static final int LOG_WINDOW = 45;
        static final int LOG_CLEAR = 46;
        static final int LOG_EXPORT = 47;
        static final int SHORTCUT_FONT_SIZE = 48;
        static final int ARRAYLIST_WINDOW = 49;
        static final int ARRAYLIST_BAR_LENGTH = 50;
        static final int ARRAYLIST_BAR_WIDTH = 51;
        static final int ARRAYLIST_BAR_COLOR = 52;
        static final int ARRAYLIST_TEXT_SIZE = 53;
        static final int ARRAYLIST_TEXT_COLOR = 54;
        static final int ARRAYLIST_GLOW_STRENGTH = 55;
        static final int ARRAYLIST_POSITION = 56;
        static final int ARRAYLIST_SHOW_DEBUG = 57;
        static final int ANIM_ENABLED = 58;
        static final int GLOBAL_GROUP = 59;
        static final int GLOBAL_RESOLUTION = 60;
        static final int GLOBAL_PERFORMANCE = 61;
        static final int GLOBAL_OPACITY = 62;
        static final int GLOBAL_CORNER = 63;
        static final int GLOBAL_STROKE = 64;
        static final int GLOBAL_GLOW = 65;
        static final int GLOBAL_ANIM_SPEED = 66;
        static final int GLOBAL_TEXT_SCALE = 67;
        static final int GLOBAL_GLASS = 68;
        static final int GLOBAL_DIM = 69;
        static final int GLOBAL_TOUCH_FEEDBACK = 70;
        static final int PANEL_GROUP = 71;
        static final int PANEL_WIDTH = 72;
        static final int PANEL_HEIGHT = 73;
        static final int PANEL_BG_OPACITY = 74;
        static final int PANEL_CORNER = 75;
        static final int PANEL_STROKE = 76;
        static final int PANEL_PADDING = 77;
        static final int PANEL_GLOW = 78;
        static final int PANEL_TITLE_SIZE = 79;
        static final int PANEL_CONTENT_SIZE = 80;
        static final int PANEL_EDGE_SNAP = 81;
        static final int SECTION_GROUP = 82;
        static final int SECTION_SIZE = 83;
        static final int SECTION_SPACING = 84;
        static final int SECTION_CORNER = 85;
        static final int SECTION_TEXT = 86;
        static final int SECTION_GLOW = 87;
        static final int FEATURE_GROUP = 88;
        static final int FEATURE_HEIGHT = 89;
        static final int FEATURE_GAP = 90;
        static final int FEATURE_CORNER = 91;
        static final int FEATURE_TEXT = 92;
        static final int FEATURE_STROKE = 93;
        static final int FEATURE_GLOW = 94;
        static final int FEATURE_PRESS = 95;
        static final int FEATURE_ICONS = 96;
        static final int FEATURE_HAPTIC = 97;
        static final int LAYOUT_GROUP = 98;
        static final int LAYOUT_LEFT_WIDTH = 99;
        static final int LAYOUT_TOP_HEIGHT = 100;
        static final int LAYOUT_ROW_GAP = 101;
        static final int LAYOUT_CONTROL_WIDTH = 102;
        static final int LAYOUT_SLIDER_HEIGHT = 103;
        static final int LAYOUT_SAFE_INSET = 104;
        static final int LAYOUT_SCROLLBAR_VISIBLE = 105;
        static final int THEME_GROUP = 106;
        static final int THEME_RGB_DIRECTION = 107;
        static final int THEME_IOS_OPACITY = 108;
        static final int THEME_IOS_HIGHLIGHT = 109;
        static final int THEME_NOISE = 110;
        static final int LOG_GROUP = 111;
        static final int LOG_TEXT_SIZE = 112;
        static final int LOG_OPACITY = 113;
        static final int LOG_AUTO_SCROLL = 114;
        static final int LOG_RECORD_FPS = 115;
        static final int LOG_RECORD_TOUCH = 116;
        static final int MUSIC_GROUP = 117;
        static final int MUSIC_SCALE = 118;
        static final int MUSIC_LYRIC_SCALE = 119;
        static final int MUSIC_PROGRESS_HEIGHT = 120;
        static final int MUSIC_DEFAULT_PANEL = 121;
        static final int PICKER_GROUP = 122;
        static final int CONFIG_GROUP = 123;
        static final int CONFIG_SAVE = 124;
        static final int CONFIG_LOAD = 125;
        static final int CONFIG_RESTORE = 126;
        static final int CONFIG_RANDOM_THEME = 127;
        static final int HINT_GLOW_ENABLED = 128;
        static final int SHORTCUT_GLOW_ENABLED = 129;
        static final int ARRAYLIST_GLOW_ENABLED = 130;
        static final int PANEL_GLOW_ENABLED = 131;
        static final int SECTION_GLOW_ENABLED = 132;
        static final int FEATURE_GLOW_ENABLED = 133;
        static final int GUI_GROUP = 134;
        static final int HINT_DEBUG_TOASTS = 135;
    }

    /**
     * Data model for one row or one logical feature.
     *
     * A Feature may be a normal switch, a select button, a slider, a color
     * picker entry, an action button or a group header. This compact model is
     * easier to serialize and simpler for AIDE Pro than a deep widget hierarchy.
     */
    private static class Feature {
        String name, title, nameCn, titleCn;
        String[] options, optionsCn;
        int optionIndex;
        int type;
        int role = Role.NONE;
        boolean enabled;
        float anim;
        float value;
        float displayValue;
        float press;
        boolean debuggable;
        boolean debugOpen;
        float debugProgress;
        boolean isSettingOnlyForNoToast;
        boolean shortcutEnabled;
        boolean shortcutPositionReady;
        float shortcutX, shortcutY;
        float shortcutPress;
        int color = 0xFFFFFFFF;
        boolean colorGradient;
        int[] gradientColors;
        float gradientSpeed = 1.0f;
        int gradientStyle = 0; // 0 = mixed gradient, 1 = classic single-color cycle
        float gradientDelay = 1.0f; // 0..1, maps to gradient frame delay
        Feature shortcutTarget;
        Feature[] settings;
        RectF cardRect = new RectF();
        RectF mainRect = new RectF();
        RectF controlRect = new RectF();
        RectF shortcutRect = new RectF();
        ValueAnimator animator;
        ValueAnimator debugAnimator;

        static Feature none(String name, String title, String nameCn, String titleCn) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.type = CONTROL_NONE;
            return f;
        }

        static Feature switcher(String name, String title, boolean enabled) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.type = CONTROL_SWITCH;
            f.enabled = enabled;
            f.anim = enabled ? 1f : 0f;
            return f;
        }

        static Feature switcher(String name, String title, boolean enabled, String nameCn, String titleCn, int role) {
            Feature f = switcher(name, title, enabled);
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.role = role;
            return f;
        }

        static Feature select(String name, String title, String[] options, int selected) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.type = CONTROL_SELECT;
            f.options = options;
            f.optionIndex = selected;
            return f;
        }

        static Feature group(String name, String title, String nameCn, String titleCn, int role) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.type = CONTROL_GROUP;
            f.role = role;
            f.debuggable = true;
            return f;
        }

        static Feature slider(String name, String title, String nameCn, String titleCn, int role, float value) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.type = CONTROL_SLIDER;
            f.role = role;
            f.value = value;
            f.displayValue = value;
            f.isSettingOnlyForNoToast = true;
            return f;
        }

        static Feature action(String name, String title, String nameCn, String titleCn, int role) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.type = CONTROL_ACTION;
            f.role = role;
            f.isSettingOnlyForNoToast = true;
            return f;
        }

        static Feature color(String name, String title, String nameCn, String titleCn, int role, int color) {
            Feature f = new Feature();
            f.name = name;
            f.title = title;
            f.nameCn = nameCn;
            f.titleCn = titleCn;
            f.type = CONTROL_COLOR;
            f.role = role;
            f.color = color;
            f.gradientColors = new int[]{color, color};
            f.gradientSpeed = 1.0f;
            f.gradientStyle = 0;
            f.gradientDelay = 1.0f;
            f.isSettingOnlyForNoToast = true;
            return f;
        }
    }
}
