package com.bacon.linuxui;

/**
 * Optional native helper used by the Java UI.
 *
 * Open-source note: this class is optional. If the native library is not built,
 * every method falls back to pure Java math so the project still runs.
 *
 * The UI remains safe when the .so is missing: Java fallback math is used.
 * When AIDE Pro + NDK builds liblinux_ui_opt.so, hot animation math and
 * frame-delta smoothing run in C++ to reduce Java-side work during redraws.
 */
public final class NativeUiOptimizer {
    private static volatile boolean loaded;
    private static volatile boolean attempted;

    private NativeUiOptimizer() { }

    public static void preload() {
        if (attempted) return;
        attempted = true;
        try {
            System.loadLibrary("linux_ui_opt");
            loaded = true;
        } catch (Throwable ignored) {
            loaded = false;
        }
    }

    public static boolean isLoaded() {
        preload();
        return loaded;
    }

    public static float gradientPhase(long nowMs, float speed, float boost) {
        preload();
        if (boost < 0.1f) boost = 0.1f;
        if (loaded) {
            try {
                return nativeGradientPhase(nowMs, speed, boost);
            } catch (Throwable ignored) {
                loaded = false;
            }
        }
        return (nowMs % 100000L) * (0.00008f + speed * 0.00016f) * boost;
    }

    public static float frameDeltaSeconds(long lastNs, long nowNs) {
        preload();
        if (loaded) {
            try {
                return nativeFrameDeltaSeconds(lastNs, nowNs);
            } catch (Throwable ignored) {
                loaded = false;
            }
        }
        if (lastNs <= 0L || nowNs <= lastNs) return 1f / 60f;
        float dt = (nowNs - lastNs) / 1000000000f;
        if (dt < 1f / 240f) dt = 1f / 240f;
        if (dt > 1f / 20f) dt = 1f / 20f;
        return dt;
    }

    public static float smooth01(float v) {
        preload();
        if (loaded) {
            try {
                return nativeSmooth01(v);
            } catch (Throwable ignored) {
                loaded = false;
            }
        }
        if (v < 0f) v = 0f;
        if (v > 1f) v = 1f;
        return v * v * (3f - 2f * v);
    }

    private static native float nativeGradientPhase(long nowMs, float speed, float boost);
    private static native float nativeFrameDeltaSeconds(long lastNs, long nowNs);
    private static native float nativeSmooth01(float value);
}
