# Linux UI Test 帮助文档

作者：bacon and ChatGPT5.5 Thinking

这是一个用于 AIDE Pro 构建的普通 Android 横屏 UI 测试项目。

## 构建方式

1. 在 AIDE Pro 中打开 `module` 目录。
2. 确认已配置 Android SDK。
3. 如需构建 native 优化层，请配置 NDK r24 / `24.0.8215888`。
4. 点击 Build / Run 构建安装。

## 主要功能

- 横屏 Canvas 自绘 UI 测试面板。
- 默认 / iOS / RGB 主题。
- `ui设置` 与全局调试。
- 功能开关提示，可切换默认样式和样式 `2`。
- 悬浮快捷键调试。
- 功能列表 ArrayList 调试。
- 字体导入与恢复默认字体。
- 本地音乐、LRC 歌词、纯歌词显示。
- 实时日志悬浮窗、清除与导出。
- 配置保存、加载、恢复默认。

## 本次开源清理修改事项

- 保留普通 APK 启动方式：`MainActivity` 作为唯一启动入口。
- 保留 Java + 可选 C++ 性能辅助结构。
- 扩展源码注释，方便二次开发者理解绘制、触摸、调试项和性能策略。
- 保留 `module/src/main/jni/` 中的可选 native 优化层。

## 目录结构

```text
module/
├── HELP.md
├── build.gradle
└── src/main/
    ├── AndroidManifest.xml
    ├── assets/GGB/              # 音乐窗口素材
    ├── java/com/bacon/linuxui/   # 主 Java 源码
    ├── jni/                      # 可选 C++ 优化层
    └── res/values/               # 主题样式
```

## 二次开发建议

### 修改 UI 文本

大部分界面文本在 `LinuxFloatingUiView.java` 中创建 `Feature` 时定义。建议搜索中文标题或英文标题后再修改。

### 新增调试项

推荐流程：

1. 在 `Role` 常量区新增一个唯一 ID。
2. 在对应功能组里新增 `Feature.slider / Feature.switcher / Feature.select / Feature.color / Feature.action`。
3. 在统一的角色处理逻辑里应用数值。
4. 需要保存时同步写入 SharedPreferences。

### 性能注意事项

- 不要在 `onDraw()` 或频繁绘制函数里反复 `new Paint()`、`new RectF()`、`new StringBuilder()`。
- 尽量复用已有 `Paint`、`RectF` 和缓存数组。
- 只有动画、拖动、渐变、音乐歌词等动态内容需要持续刷新。
- 静态状态下应尽量减少 `invalidate()`。

### 修改主题

主题相关逻辑集中在颜色、背景、描边、玻璃效果和 RGB 渐变函数附近。建议保持：

- 主 UI 主题颜色不强制影响快捷键文字颜色。
- 功能提示颜色使用自己的调试配置。
- 功能列表 ArrayList 使用自己的文字/边条/辉光配置。

## 注意事项

- 本项目是普通 Android APK 测试版，不- 若 AIDE Pro 构建失败，请优先检查报错文件和行号。
- 修改大量 UI 调试项后，建议使用“恢复默认”确认布局没有被极端参数破坏。